function result = Start_SteadyModelUQ_09_PosteriorDiagnostics(userCfg)
%START_STEADYMODELUQ_09_POSTERIORDIAGNOSTICS 节点、曲线和工程补偿诊断。

if nargin < 1, userCfg = struct(); end
timer = tic;
manifest = sht_steady_model_uq_io('resolve',userCfg);
step1 = sht_steady_model_uq_io('loadstep',manifest,1);
step5 = sht_steady_model_uq_io('loadstep',manifest,5);
step8 = sht_steady_model_uq_io('loadstep',manifest,8);
if ~step8.passed
    error('SHT:SteadyUQ:PosteriorNotFormal', ...
        '步骤8尚未形成通过采样质量门限的正式后验。');
end
contract = step1.contract;
formal = step8.formal;
theta = formal.theta;
weights = formal.weights(:)/sum(formal.weights);

summaryTable = sht_steady_model_uq_sampler('summary',theta,weights,contract);
[q025Mcse,q975Mcse] = local_endpoint_mcse(theta,weights, ...
    formal.diagnostic.effectiveSampleSize,contract.config.randomSeed+9001);
summaryTable.q025_mcse = q025Mcse;
summaryTable.q975_mcse = q975Mcse;
summaryTable.maximum_endpoint_mcse_fraction = max(q025Mcse,q975Mcse)./ ...
    max(summaryTable.credible_width,eps);

posteriorMean = theta*weights;
centered = theta-posteriorMean;
posteriorCovariance = centered*(centered.*weights.').';
posteriorStd = sqrt(max(diag(posteriorCovariance),0));
posteriorCorrelation = posteriorCovariance./max(posteriorStd*posteriorStd.',eps);
modeTable = local_mode_table(theta,weights,formal.diagnostic,contract);
nodeTable = local_node_table(contract,summaryTable);
fixedAnchorTable = local_fixed_anchor_table(contract);

engineeringCompensation = sht_steady_model_uq_engineering_compensation( ...
    contract,formal,step5.likelihood,step5.differenceStep,posteriorCorrelation);
identifiabilityTable = local_identifiability_table( ...
    contract,step5,summaryTable,engineeringCompensation);
likelihoodCalibration = local_likelihood_calibration( ...
    formal,weights,step5,contract);

maximumEndpointFraction = max(summaryTable.maximum_endpoint_mcse_fraction);
endpointMcsePassed = maximumEndpointFraction <= 0.15;
effectiveSampleSizePassed = formal.diagnostic.effectiveSampleSize >= ...
    step8.acceptanceCriteria.minimumEss;
% 某条工程幅值路径越界或DLL无效只表示该方向未证明补偿，不影响已经
% 获得的后验样本。这里仅要求补偿诊断程序完成并形成有限结果表。
engineeringCompensationPassed = ...
    height(engineeringCompensation.directionTable) == ...
        engineeringCompensation.testedDirectionCount && ...
    all(isfinite(engineeringCompensation.directionTable.direction_rank));
likelihoodCalibrationPassed = likelihoodCalibration.passed;
passed = endpointMcsePassed && effectiveSampleSizePassed && ...
    engineeringCompensationPassed && likelihoodCalibrationPassed;
acceptance = struct('maximumEndpointMcseFraction',maximumEndpointFraction, ...
    'maximumEndpointMcseFractionLimit',0.15, ...
    'endpointMcsePassed',endpointMcsePassed, ...
    'effectiveSampleSize',formal.diagnostic.effectiveSampleSize, ...
    'minimumEffectiveSampleSize',step8.acceptanceCriteria.minimumEss, ...
    'effectiveSampleSizePassed',effectiveSampleSizePassed, ...
    'engineeringCompensationDiagnosticCompleted',engineeringCompensationPassed, ...
    'engineeringCompensationPathValidityPassed',engineeringCompensationPassed, ...
    'likelihoodCalibrationPassed',likelihoodCalibrationPassed, ...
    'passed',passed);
result = struct('summaryTable',summaryTable,'nodeTable',nodeTable, ...
    'scheduleNodeTable',nodeTable,'fixedAnchorTable',fixedAnchorTable, ...
    'posteriorMean',posteriorMean,'posteriorCovariance',posteriorCovariance, ...
    'posteriorCorrelation',posteriorCorrelation,'modeTable',modeTable, ...
    'identifiabilityTable',identifiabilityTable, ...
    'engineeringCompensation',engineeringCompensation, ...
    'engineeringCompensationTable',engineeringCompensation.directionTable, ...
    'likelihoodCalibration',likelihoodCalibration, ...
    'acceptance',acceptance, ...
    'samplingDiagnostic',formal.diagnostic,'passed',passed, ...
    'truthRead',false,'testDataRead',false);
runtime = toc(timer);
[manifest,file] = sht_steady_model_uq_io( ...
    'savestep',manifest,9,'node_posterior_diagnostics',result,runtime);
writetable(summaryTable,sht_steady_model_uq_io( ...
    'reportfile',manifest,'UQ09_node_posterior.csv'));
writetable(modeTable,sht_steady_model_uq_io( ...
    'reportfile',manifest,'UQ09_mode_summary.csv'));
writetable(nodeTable,sht_steady_model_uq_io( ...
    'reportfile',manifest,'UQ09_schedule_node_intervals.csv'));
writetable(fixedAnchorTable,sht_steady_model_uq_io( ...
    'reportfile',manifest,'UQ09_fixed_pressure_loss_anchors.csv'));
writetable(identifiabilityTable,sht_steady_model_uq_io( ...
    'reportfile',manifest,'UQ09_local_identifiability.csv'));
writetable(engineeringCompensation.directionTable,sht_steady_model_uq_io( ...
    'reportfile',manifest,'UQ09_engineering_compensation_directions.csv'));
writetable(engineeringCompensation.pathTable,sht_steady_model_uq_io( ...
    'reportfile',manifest,'UQ09_engineering_compensation_paths.csv'));
writetable(struct2table(likelihoodCalibration),sht_steady_model_uq_io( ...
    'reportfile',manifest,'UQ09_likelihood_scale_calibration.csv'));
local_plot_representative_marginals(theta,weights,contract,manifest);
local_plot_correlation(posteriorCorrelation,contract,manifest);
local_plot_schedule(nodeTable,fixedAnchorTable,contract,manifest);
local_plot_information(summaryTable,identifiabilityTable,contract,manifest);
fprintf(['[2.4UQ.9] 节点后验诊断通过：ESS=%.1f，候选模态=%d，' ...
    '端点MCSE/区间最大=%.3f，工程补偿方向=%d/%d。\n'], ...
    formal.diagnostic.effectiveSampleSize,formal.diagnostic.modeCount, ...
    maximumEndpointFraction,engineeringCompensation.supportedDirectionCount, ...
    engineeringCompensation.testedDirectionCount);
fprintf(['[2.4UQ.9] 似然尺度：p_eff=%.3f，nu_eff=%.3f，' ...
    '后验Mahalanobis^2中位数=%.3f，校准区间=[%.3f, %.3f]。\n'], ...
    likelihoodCalibration.effectiveParameterCount, ...
    likelihoodCalibration.effectiveResidualDegreesOfFreedom, ...
    likelihoodCalibration.posteriorMedianMahalanobisSquared, ...
    likelihoodCalibration.acceptanceLower, ...
    likelihoodCalibration.acceptanceUpper);
fprintf('[2.4UQ.9] 产物：%s\n',file);
result.manifest = manifest;
if ~passed
    fprintf(2,['[2.4UQ.9] 未通过分项：端点MCSE=%d，ESS=%d，' ...
        '工程补偿诊断完整性=%d，似然尺度=%d。\n'],endpointMcsePassed, ...
        effectiveSampleSizePassed,engineeringCompensationPassed, ...
        likelihoodCalibrationPassed);
    error('SHT:SteadyUQ:PosteriorDiagnosticAcceptanceFailed', ...
        '步骤9分项诊断未全部通过；检查点已保存：%s。',file);
end
end

function result = local_likelihood_calibration(formal,weights,step5,contract)
% 参数数大于观测数时不能使用n-p。局部后验曲率给出有效拟合自由度，
% 只用来识别误差尺度的严重失配；后验样本仍来自完整非线性精确模型。
whiteResidual = step5.likelihood.cholLower\formal.exact.residual;
mahalanobisSquared = sum(whiteResidual.^2,1);
hatMatrix = step5.whitenedJacobian*step5.localCovariance* ...
    step5.whitenedJacobian.';
effectiveParameterCount = min(max(real(trace(hatMatrix)),0), ...
    contract.observationDimension-1e-6);
effectiveResidualDf = contract.observationDimension-effectiveParameterCount;
posteriorQuantile = sht_steady_model_uq_sampler('weightedquantile', ...
    mahalanobisSquared,weights,[0.025,0.5,0.975]);
tailProbability = gammainc(mahalanobisSquared/2, ...
    effectiveResidualDf/2,'upper');
posteriorPredictiveUpperTail = sum(weights(:).'.*tailProbability);
acceptanceLower = 2*gammaincinv(0.001,effectiveResidualDf/2,'lower');
acceptanceUpper = 2*gammaincinv(0.999,effectiveResidualDf/2,'lower');
passed = isfinite(posteriorQuantile(2)) && ...
    posteriorQuantile(2)>=acceptanceLower && ...
    posteriorQuantile(2)<=acceptanceUpper;
result = struct('method','local_effective_df_chi_square_diagnostic', ...
    'observationDimension',contract.observationDimension, ...
    'effectiveParameterCount',effectiveParameterCount, ...
    'effectiveResidualDegreesOfFreedom',effectiveResidualDf, ...
    'posteriorQ025MahalanobisSquared',posteriorQuantile(1), ...
    'posteriorMedianMahalanobisSquared',posteriorQuantile(2), ...
    'posteriorQ975MahalanobisSquared',posteriorQuantile(3), ...
    'posteriorPredictiveUpperTailProbability',posteriorPredictiveUpperTail, ...
    'acceptanceLowerProbability',0.001,'acceptanceUpperProbability',0.999, ...
    'acceptanceLower',acceptanceLower,'acceptanceUpper',acceptanceUpper, ...
    'localLinearApproximationUsedForEffectiveDf',true,'passed',passed);
end

function [lowerMcse,upperMcse] = local_endpoint_mcse(theta,weights,ess,seed)
d = size(theta,1);
replicateCount = 100;
sampleCount = max(100,round(ess));
lower = zeros(d,replicateCount);
upper = zeros(d,replicateCount);
for b = 1:replicateCount
    sample = sht_steady_model_uq_sampler( ...
        'resample',theta,weights,sampleCount,seed+b);
    lower(:,b) = quantile(sample,0.025,2);
    upper(:,b) = quantile(sample,0.975,2);
end
lowerMcse = std(lower,0,2);
upperMcse = std(upper,0,2);
end

function tableOut = local_mode_table(theta,weights,diagnostic,contract)
modeCount = diagnostic.modeCount;
mode = (1:modeCount).';
mass = diagnostic.modeMass(:);
centerDistanceFromGlobal = zeros(modeCount,1);
center = cell(modeCount,1);
globalCenter = theta*weights;
for k = 1:modeCount
    member = diagnostic.modeIndex==k;
    wk = weights(member); wk = wk/sum(wk);
    value = theta(:,member)*wk;
    center{k} = value.';
    centerDistanceFromGlobal(k) = norm((value-globalCenter)./ ...
        contract.priorSigma)/sqrt(contract.parameterCount);
end
tableOut = table(mode,mass,centerDistanceFromGlobal,center, ...
    'VariableNames',{'mode','posterior_mass', ...
    'center_distance_from_global_prior_scale','parameter_center'});
end

function tableOut = local_node_table(contract,summary)
tbl = contract.parameterTable;
tableOut = table(tbl.index,tbl.name,tbl.base_name,tbl.c_index,tbl.unit, ...
    tbl.group_index,tbl.group_kind,tbl.node_index,tbl.axis_name, ...
    tbl.coordinate,tbl.normalized_coordinate,summary.deterministic_estimate, ...
    summary.posterior_mean,summary.posterior_median,summary.posterior_std, ...
    summary.q025,summary.q975,summary.prior_q025,summary.prior_q975, ...
    summary.interval_shrinkage_pct, ...
    'VariableNames',{'index','name','base_name','c_index','unit', ...
    'group_index','group_kind','node_index','axis_name','axis_value', ...
    'normalized_axis_value','deterministic_estimate','posterior_mean', ...
    'posterior_median','posterior_std','q025','q975','prior_q025', ...
    'prior_q975','interval_shrinkage_pct'});
end

function tableOut = local_fixed_anchor_table(contract)
tbl = contract.parameterTable;
groups = unique(tbl.group_index(tbl.pressure_loss),'stable');
name = strings(numel(groups),1);
cIndex = zeros(numel(groups),1);
axisName = strings(numel(groups),1);
axisValue = zeros(numel(groups),1);
fixedValue = zeros(numel(groups),1);
for i = 1:numel(groups)
    row = find(tbl.group_index==groups(i),1);
    name(i) = tbl.base_name(row);
    cIndex(i) = tbl.c_index(row);
    axisName(i) = tbl.axis_name(row);
end
tableOut = table(name,cIndex,axisName,axisValue,fixedValue, ...
    'VariableNames',{'base_name','c_index','axis_name','axis_value','fixed_value'});
end

function tableOut = local_identifiability_table( ...
        contract,step5,summary,compensation)
sensitivity = sqrt(sum((step5.whitenedJacobian.*contract.priorSigma.').^2,1)).';
positive = sensitivity(sensitivity>0);
if isempty(positive), reference = 1; else, reference = median(positive); end
relativeSensitivity = sensitivity/max(reference,eps);
lowSensitivity = relativeSensitivity<0.10;
compensationDependent = false(contract.parameterCount,1);
for k = 1:numel(compensation.direction)
    if ~compensation.direction(k).compensation_supported, continue; end
    contribution = abs(compensation.direction(k).normalized_direction);
    compensationDependent = compensationDependent | contribution>=0.15*max(contribution);
end
classification = strings(contract.parameterCount,1);
for j = 1:contract.parameterCount
    if lowSensitivity(j)
        classification(j) = "参数自身低敏感";
    elseif compensationDependent(j)
        classification(j) = "依赖其他参数补偿";
    elseif summary.interval_shrinkage_pct(j)<10
        classification(j) = "数据约束有限，主要由先验控制";
    else
        classification(j) = "当前局部数据可辨识";
    end
end
tableOut = table(contract.parameterTable.index,contract.parameterTable.name, ...
    contract.parameterTable.base_name,relativeSensitivity,lowSensitivity, ...
    compensationDependent,summary.interval_shrinkage_pct,classification, ...
    'VariableNames',{'index','name','base_name', ...
    'prior_scaled_whitened_sensitivity','self_low_sensitivity', ...
    'engineering_compensation_dependent','interval_shrinkage_pct', ...
    'classification'});
end

function local_plot_representative_marginals(theta,weights,contract,manifest)
group = unique(contract.parameterTable.group_index,'stable');
f = figure('Visible',contract.config.figureVisible,'Position',[80,50,1400,950]);
for k = 1:numel(group)
    rows = find(contract.parameterTable.group_index==group(k));
    [~,middle] = min(abs(contract.parameterTable.normalized_coordinate(rows)-0.5));
    j = rows(middle);
    subplot(4,3,k);
    [center,density] = local_weighted_histogram(theta(j,:),weights,32);
    bar(center,density,1,'FaceColor',[0.20,0.45,0.75],'EdgeColor','none');
    hold on;
    yLimit = ylim;
    plot([contract.thetaHat(j),contract.thetaHat(j)],yLimit,'--k','LineWidth',0.8);
    plot([0,0],yLimit,':r','LineWidth',0.8);
    ylim(yLimit);
    title(strrep(char(contract.parameterTable.base_name(j)),'_','\_'));
    xlabel(char(contract.parameterTable.unit(j))); ylabel('概率密度'); grid on;
end
sgtitle('各调度函数代表节点的正式后验边缘分布');
saveas(f,sht_steady_model_uq_io( ...
    'reportfile',manifest,'UQ09_representative_node_marginals.png'));
close(f);
end

function [center,density] = local_weighted_histogram(value,weights,binCount)
value = value(:); weights = weights(:)/sum(weights);
minimum = min(value); maximum = max(value);
if maximum<=minimum
    halfWidth = max(abs(minimum),1)*1e-6;
    minimum = minimum-halfWidth; maximum = maximum+halfWidth;
end
edge = linspace(minimum,maximum,binCount+1);
[~,~,bin] = histcounts(value,edge);
valid = bin>=1&bin<=binCount;
mass = accumarray(bin(valid),weights(valid),[binCount,1],@sum,0);
density = mass./diff(edge(:));
center = 0.5*(edge(1:end-1)+edge(2:end));
end

function local_plot_correlation(correlation,contract,manifest)
f = figure('Visible',contract.config.figureVisible,'Position',[100,70,1000,850]);
imagesc(correlation,[-1,1]); axis image; colorbar;
xlabel('节点参数序号'); ylabel('节点参数序号');
title('61维正式后验相关矩阵（不作为工程补偿证据）');
hold on;
boundary = contract.parameterGroupTable.last_parameter(1:end-1)+0.5;
for value = boundary.'
    plot([value,value],ylim,'k-','LineWidth',0.4);
    plot(xlim,[value,value],'k-','LineWidth',0.4);
end
saveas(f,sht_steady_model_uq_io( ...
    'reportfile',manifest,'UQ09_node_posterior_correlation.png'));
close(f);
end

function local_plot_schedule(nodeTable,fixedAnchorTable,contract,manifest)
names = unique(nodeTable.base_name,'stable');
f = figure('Visible',contract.config.figureVisible,'Position',[60,40,1450,950]);
for j = 1:numel(names)
    subplot(4,3,j);
    t = nodeTable(nodeTable.base_name==names(j),:);
    x = t.axis_value; lower = t.q025; upper = t.q975; medianValue = t.posterior_median;
    anchor = fixedAnchorTable(fixedAnchorTable.base_name==names(j),:);
    if ~isempty(anchor)
        x = [anchor.axis_value;x]; lower = [anchor.fixed_value;lower];
        upper = [anchor.fixed_value;upper]; medianValue = [anchor.fixed_value;medianValue];
    end
    if numel(x)>1
        fill([x;flipud(x)],[lower;flipud(upper)],[0.75,0.86,0.96], ...
            'EdgeColor','none'); hold on;
    end
    plot(x,medianValue,'b-o','LineWidth',1.2,'MarkerSize',3); hold on;
    plot(t.axis_value,t.deterministic_estimate,'--k.');
    title(strrep(char(names(j)),'_','\_'));
    xlabel(strrep(char(t.axis_name(1)),'_','\_')); ylabel(char(t.unit(1))); grid on;
end
sgtitle('调度函数节点后验95%可信带');
saveas(f,sht_steady_model_uq_io( ...
    'reportfile',manifest,'UQ09_schedule_node_intervals.png'));
close(f);
end

function local_plot_information(summary,identifiability,contract,manifest)
f = figure('Visible',contract.config.figureVisible,'Position',[100,80,1400,700]);
subplot(2,1,1);
bar(summary.interval_shrinkage_pct); ylabel('区间收缩率 / %'); grid on;
title('逐节点后验相对先验的区间收缩');
subplot(2,1,2);
semilogy(max(identifiability.prior_scaled_whitened_sensitivity,eps),'o-');
ylabel('先验尺度白化敏感度'); xlabel('节点参数序号'); grid on;
title('局部节点敏感度（低敏感与补偿需分开解释）');
sgtitle(sprintf('2.4节点信息诊断（%d维）',contract.parameterCount));
saveas(f,sht_steady_model_uq_io( ...
    'reportfile',manifest,'UQ09_node_information_diagnostics.png'));
close(f);
end
