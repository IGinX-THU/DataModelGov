function varargout = sht_steady_model_uq_b_common(action, varargin)
%SHT_STEADY_MODEL_UQ_B_COMMON 2.4稳态UQ方法B公共内核。
%
% 方法B在方法A的61维总体参数合同上，独立增加12个六部件局部常值和
% 20个物理引气常值（10路流量与10路总温）。K_PRec在当前C程序中不
% 参与计算，因此不进入概率参数空间。方法B不读取方法A后验；两者只共享训练数据、
% 测量误差合同、DLL回放接口和总体调度节点坐标。

switch lower(char(action))
    case 'defaultconfig'
        varargout{1} = local_default_config(varargin{:});
    case 'buildcontract'
        varargout{1} = local_build_contract(varargin{:});
    case 'loaddata'
        varargout{1} = local_load_data(varargin{:});
    case 'observation'
        [varargout{1:nargout}] = sht_steady_model_uq_common( ...
            'observation', varargin{:});
    case 'predictionvector'
        [varargout{1:nargout}] = sht_steady_model_uq_common( ...
            'predictionvector', varargin{:});
    case 'evaluate'
        varargout{1} = local_evaluate(varargin{:});
    case 'vectortoschedule'
        varargout{1} = local_vector_to_schedule(varargin{:});
    case 'scheduletovector'
        varargout{1} = local_schedule_to_vector(varargin{:});
    case 'inputcovariance'
        varargout{1} = local_input_covariance(varargin{:});
    case 'measurementcovariance'
        varargout{1} = sht_steady_model_uq_common( ...
            'measurementcovariance', varargin{:});
    case 'filehash'
        varargout{1} = sht_steady_model_uq_common('filehash', varargin{:});
    case 'flightuqfingerprint'
        varargout{1} = sht_steady_model_uq_common( ...
            'flightuqfingerprint', varargin{:});
    otherwise
        error('SHT:SteadyUQB:UnknownAction', ...
            '未知方法B公共动作：%s。', action);
end
end

function cfg = local_default_config(userCfg)
if nargin < 1 || isempty(userCfg), userCfg = struct(); end
cfg = sht_steady_model_uq_common('defaultconfig', userCfg);
cfg.randomSeed = local_option(userCfg, 'randomSeed', 20260822);
cfg.pilotSampleCount = local_option(userCfg, 'pilotSampleCount', 64);
cfg.pilotReplicateCount = local_option(userCfg, 'pilotReplicateCount', 3);
cfg.formalSampleCount = local_option(userCfg, 'formalSampleCount', 512);
cfg.posteriorPredictiveSampleCount = local_option( ...
    userCfg, 'posteriorPredictiveSampleCount', 512);
cfg.minimumEffectiveSampleSize = local_option( ...
    userCfg, 'minimumEffectiveSampleSize', 64);
cfg.minimumEffectiveSampleFraction = local_option( ...
    userCfg, 'minimumEffectiveSampleFraction', 0.30);
cfg.maximumNormalizedWeight = local_option( ...
    userCfg, 'maximumNormalizedWeight', 0.08);
cfg.smcPilotTargetEssFraction = local_option( ...
    userCfg, 'smcPilotTargetEssFraction', 0.55);
cfg.smcFormalTargetEssFraction = local_option( ...
    userCfg, 'smcFormalTargetEssFraction', 0.50);
cfg.methodARunId = char(local_option(userCfg, 'methodARunId', ''));
cfg.blockKernelWeights = local_option( ...
    userCfg, 'blockKernelWeights', [0.30, 0.22, 0.28, 0.20]);
cfg.blockInitialPcnScale = local_option( ...
    userCfg, 'blockInitialPcnScale', [0.10, 0.18, 0.18, 0.08]);
if numel(cfg.blockKernelWeights) ~= 4 || ...
        any(cfg.blockKernelWeights <= 0) || ...
        numel(cfg.blockInitialPcnScale) ~= 4 || ...
        any(cfg.blockInitialPcnScale <= 0) || ...
        any(cfg.blockInitialPcnScale >= 1)
    error('SHT:SteadyUQB:BadBlockConfiguration', ...
        '四类分块核的权重和初始pCN步长必须为四个合法正数。');
end
cfg.blockKernelWeights = cfg.blockKernelWeights(:).' / ...
    sum(cfg.blockKernelWeights);
cfg.blockInitialPcnScale = cfg.blockInitialPcnScale(:).';
end

function contract = local_build_contract(cfg)
% 复用上游61维参数的节点坐标和工程先验结构，但不保留其确定性估计值。
baseCfg = sht_steady_model_uq_common('defaultconfig', cfg);
base = sht_steady_model_uq_common('buildcontract', baseCfg);
if base.parameterCount ~= 61
    error('SHT:SteadyUQB:BaseContractDimension', ...
        '公共总体参数合同为%d维，预期61维。', base.parameterCount);
end

baseTable = base.parameterTable;
deterministicEstimate = baseTable.point_estimate(:);
baseTable.point_estimate(:) = 0;
baseTable.block_name = repmat("aggregate", height(baseTable), 1);
newTable = local_new_parameter_table(baseTable);
parameterTable = [baseTable; newTable];
parameterTable.index = (1:height(parameterTable)).';

priorSigma = parameterTable.prior_sigma .* cfg.priorScale;
priorCorrelation = blkdiag(base.priorCorrelation, eye(height(newTable)));
priorCovariance = diag(priorSigma) * priorCorrelation * diag(priorSigma);
priorCovariance = 0.5 * (priorCovariance + priorCovariance.');
lower = parameterTable.lower_bound;
upper = parameterTable.upper_bound;
priorMean = zeros(height(parameterTable), 1);
if any(priorMean <= lower) || any(priorMean >= upper)
    error('SHT:SteadyUQB:PriorMeanOutsideBounds', ...
        '方法B零中心先验均值没有严格位于全部硬边界内部。');
end

scheduleTemplate = local_zero_parameter_template( ...
    base.scheduleTemplate, baseTable);
blockNames = ["aggregate"; "local"; "bleed"; "cross"];
blockIndex = {find(parameterTable.block_name == "aggregate"), ...
    find(parameterTable.block_name == "local"), ...
    find(parameterTable.block_name == "bleed"), ...
    (1:height(parameterTable)).'};
blockCount = cellfun(@numel, blockIndex).';
parameterBlockTable = table((1:4).', blockNames, blockCount, ...
    'VariableNames', {'block_index','block_name','parameter_count'});
parameterGroupTable = local_parameter_group_table(parameterTable);

paths = sht_steady_model_uq_b_io('paths');
contractCore = struct();
contractCore.schemaVersion = 'steady_model_uq_method_b_contract_v1';
contractCore.route = cfg.route;
contractCore.trainingDataHash = sht_steady_model_uq_common( ...
    'filehash', base.trainingFile);
contractCore.engineArtifactHash = {base.engineArtifacts.sha256};
contractCore.parameterNames = cellstr(parameterTable.name);
contractCore.parameterCIndex = parameterTable.c_index(:).';
contractCore.parameterCoordinates = parameterTable.coordinate(:).';
contractCore.lower = lower(:).';
contractCore.upper = upper(:).';
contractCore.priorSigma = priorSigma(:).';
contractCore.priorCorrelation = priorCorrelation;
contractCore.covarianceScenario = cfg.covarianceScenario;
contractCore.modelDiscrepancyScale = cfg.modelDiscrepancyScale;
contractCore.codeHash = local_runtime_code_hash();
contractHash = local_text_hash(jsonencode(contractCore));

contract = struct();
contract.schemaVersion = contractCore.schemaVersion;
contract.createdAt = datestr(now, 30);
contract.route = cfg.route;
contract.config = cfg;
contract.trainingFile = base.trainingFile;
contract.testFile = base.testFile;
contract.deterministicResultFile = base.deterministicResultFile;
contract.trainingData = base.trainingData;
contract.trainingPointIds = base.trainingPointIds;
contract.trainingPointCount = base.trainingPointCount;
contract.residualPerPoint = base.residualPerPoint;
contract.observationDimension = base.observationDimension;
contract.residualOrder = base.residualOrder;
contract.parameterCount = height(parameterTable);
contract.parameterTable = parameterTable;
contract.parameterGroupTable = parameterGroupTable;
contract.parameterBlockTable = parameterBlockTable;
contract.parameterBlockIndex = blockIndex;
contract.thetaHat = priorMean; % 仅供通用采样器显示；含义是零先验参考点。
contract.referencePoint = priorMean;
contract.referencePointSource = 'independent_zero_prior_mean';
% 2.4 D阶段确定性辨识结果只用于最终对照展示，不参与方法B先验、提议或似然。
contract.deterministicEstimate = [deterministicEstimate; ...
    nan(height(newTable),1)];
contract.deterministicEstimateParameterCount = numel(deterministicEstimate);
contract.deterministicEstimateUsedByInference = false;
contract.lowerBound = lower;
contract.upperBound = upper;
contract.priorMean = priorMean;
contract.priorSigma = priorSigma;
contract.priorCorrelation = priorCorrelation;
contract.priorCovariance = priorCovariance;
contract.priorType = 'gaussian_copula_truncated_normal';
contract.scheduleTemplate = scheduleTemplate;
contract.deterministicOffsetParameterCount = ...
    base.deterministicOffsetParameterCount;
contract.scheduleConditioning = ...
    'aggregate_node_coordinates_frozen_new_physical_parameters_constant';
contract.fixedDirectInletScheduleCIndex = 0;
contract.methodAPosteriorUsed = false;
contract.methodADeterministicValuesUsed = false;
contract.commonMeasurementLinearization = ...
    'upstream_deterministic_schedule_only_no_method_a_uq_posterior';
contract.trainingOnlyUntilStep10 = true;
contract.truthAccessAllowedBeforeStep10 = false;
contract.testAccessAllowedBeforeStep10 = false;
contract.steadyWindowSampleCount = cfg.steadyWindowSampleCount;
contract.engineArtifacts = base.engineArtifacts;
contract.flightUqFingerprintBefore = base.flightUqFingerprintBefore;
contract.contractHash = contractHash;
contract.cacheFile = fullfile(paths.middleRoot, ...
    ['exact_training_cache_' contractHash(1:16) '.mat']);
if contract.parameterCount ~= 93 || ...
        numel(blockIndex{1}) ~= 61 || numel(blockIndex{2}) ~= 12 || ...
        numel(blockIndex{3}) ~= 20
    error('SHT:SteadyUQB:ParameterContractDimension', ...
        '方法B合同没有形成61+12+20=93维结构。');
end
end

function tbl = local_new_parameter_table(baseTable)
dictionary = sht_health_parameter_dictionary(1);
localIndex = [71,72,74,75,77,78,80,81,83,84,86,87].';
bleedFlow = (30:39).';
bleedTemperature = (44:53).';
cIndex = [localIndex; bleedFlow; bleedTemperature];
n = numel(cIndex);
tbl = repmat(baseTable(1,:), n, 1);
tbl.index = zeros(n,1);
tbl.name = strings(n,1);
tbl.base_name = strings(n,1);
tbl.c_index = cIndex;
tbl.unit = repmat("1",n,1);
tbl.group_index = max(baseTable.group_index) + (1:n).';
tbl.group_kind = repmat("health_constant",n,1);
tbl.schedule_entry_index = zeros(n,1);
tbl.dll_node_index = zeros(n,1);
tbl.node_index = ones(n,1);
tbl.coordinate = zeros(n,1);
tbl.normalized_coordinate = zeros(n,1);
tbl.point_estimate = zeros(n,1);
tbl.lower_bound = zeros(n,1);
tbl.upper_bound = zeros(n,1);
tbl.prior_sigma = zeros(n,1);
tbl.difference_step = zeros(n,1);
tbl.axis_name = repmat("constant",n,1);
tbl.pressure_loss = false(n,1);
tbl.block_name = strings(n,1);

for i = 1:n
    row = dictionary(dictionary.c_index == cIndex(i),:);
    if height(row) ~= 1 || ~row.active
        error('SHT:SteadyUQB:DictionaryMismatch', ...
            'h%d未在六部件健康参数字典中唯一启用。', cIndex(i));
    end
    tbl.name(i) = row.name;
    tbl.base_name(i) = row.name;
    if ismember(cIndex(i), localIndex)
        tbl.lower_bound(i) = -0.025;
        tbl.upper_bound(i) = 0.025;
        tbl.prior_sigma(i) = 0.006;
        tbl.difference_step(i) = 5e-4;
        tbl.block_name(i) = "local";
    elseif ismember(cIndex(i), bleedFlow)
        tbl.lower_bound(i) = -0.0028;
        tbl.upper_bound(i) = 0.0028;
        tbl.prior_sigma(i) = 0.0010;
        tbl.difference_step(i) = 1e-4;
        tbl.block_name(i) = "bleed";
    else
        tbl.lower_bound(i) = -0.015;
        tbl.upper_bound(i) = 0.015;
        tbl.prior_sigma(i) = 0.004;
        tbl.difference_step(i) = 2.5e-4;
        tbl.block_name(i) = "bleed";
    end
end
end

function groupTable = local_parameter_group_table(tbl)
groups = unique(tbl.group_index, 'stable');
groupName = strings(numel(groups),1);
groupKind = strings(numel(groups),1);
blockName = strings(numel(groups),1);
parameterCount = zeros(numel(groups),1);
for i = 1:numel(groups)
    use = tbl.group_index == groups(i);
    groupName(i) = tbl.base_name(find(use,1));
    groupKind(i) = tbl.group_kind(find(use,1));
    blockName(i) = tbl.block_name(find(use,1));
    parameterCount(i) = nnz(use);
end
groupTable = table(groups, groupName, groupKind, blockName, ...
    parameterCount, 'VariableNames', {'group_index','group_name', ...
    'group_kind','block_name','parameter_count'});
end

function schedule = local_zero_parameter_template(schedule, baseTable)
% h0由Pt1/Pt2直接计算形成，不属于61维联合参数，保留上游数据推导值。
estimatedCIndex = unique(baseTable.c_index(baseTable.c_index >= 0));
for i = 1:numel(schedule.healthEntries)
    entry = schedule.healthEntries(i);
    if ismember(entry.cIndex, estimatedCIndex)
        entry.kNodes(:) = 0;
        entry.kNodesDll(:) = 0;
        if isfield(entry,'deltaNodes'), entry.deltaNodes(:) = 0; end
        entry.designValue = 0;
        entry.deltaNodesDll(:) = 0;
        schedule.healthEntries(i) = entry;
    end
end
schedule.fuelBias.biasNodes(:) = 0;
schedule.h15 = 0;
schedule.designHealth = local_schedule_design_health(schedule);
end

function data = local_load_data(contract, role)
data = sht_steady_model_uq_common('loaddata', contract, role);
end

function output = local_evaluate(contract, thetaMatrix, data, options)
if nargin < 3 || isempty(data), data = contract.trainingData; end
if nargin < 4 || isempty(options), options = struct(); end
if size(thetaMatrix,1) ~= contract.parameterCount
    error('SHT:SteadyUQB:BadThetaMatrix', ...
        '方法B候选矩阵必须为%d行。', contract.parameterCount);
end
needPredictions = logical(local_option(options,'returnPredictions',false));
needDiagnostics = logical(local_option(options,'returnDiagnostics',false));
robustTransientFallback = logical(local_option( ...
    options,'useRobustTransientFallback',false));
useCache = logical(local_option(options,'useCache',contract.config.useCache));
cacheFile = char(local_option(options,'cacheFile',contract.cacheFile));
[observation,~,~] = sht_steady_model_uq_common( ...
    'observation',contract,data);
nCandidate = size(thetaMatrix,2);
residual = nan(numel(observation),nCandidate);
valid = false(1,nCandidate);
prediction = cell(1,nCandidate);
diagnostic = cell(1,nCandidate);
inside = all(thetaMatrix >= contract.lowerBound & ...
    thetaMatrix <= contract.upperBound,1) & all(isfinite(thetaMatrix),1);

cache = local_empty_cache(contract,numel(observation));
if useCache && ~needPredictions && exist(cacheFile,'file') == 2
    loaded = load(cacheFile,'cache');
    if isfield(loaded,'cache') && ...
            strcmp(loaded.cache.contractHash,contract.contractHash) && ...
            loaded.cache.residualDimension == numel(observation)
        cache = loaded.cache;
    end
end
hitCount = 0;
newIndex = zeros(0,1);
newKeys = cell(0,1);
for i = 1:nCandidate
    if ~inside(i), continue; end
    key = local_theta_key(thetaMatrix(:,i));
    if useCache && ~needPredictions
        index = find(strcmp(cache.keys,key),1);
    else
        index = [];
    end
    if isempty(index)
        newIndex(end+1,1) = i; %#ok<AGROW>
        newKeys{end+1,1} = key; %#ok<AGROW>
    else
        residual(:,i) = cache.residual(:,index);
        valid(i) = cache.valid(index);
        hitCount = hitCount+1;
    end
end

dllTimer = tic;
if ~isempty(newIndex)
    deterministic = load(contract.deterministicResultFile,'result');
    schedules = cell(numel(newIndex),1);
    for k = 1:numel(newIndex)
        schedules{k} = local_vector_to_schedule( ...
            contract,thetaMatrix(:,newIndex(k)));
    end
    batchOptions = struct('useRobustTransientFallback', ...
        robustTransientFallback);
    initialSeedMatrices = local_option(options,'initialSeedMatrices',[]);
    if ~isempty(initialSeedMatrices)
        batchOptions.initialSeedMatrices = initialSeedMatrices;
    end
    batch = sht_steady_model_adapt_v2_common( ...
        'evaluateschedulebatchdataset',deterministic.result,data, ...
        schedules,batchOptions);
    for k = 1:numel(newIndex)
        i = newIndex(k);
        item = batch.candidate(k);
        if item.valid
            predicted = sht_steady_model_uq_common( ...
                'predictionvector',contract.route,item.prediction);
            residual(:,i) = predicted-observation;
            valid(i) = all(isfinite(residual(:,i)));
        end
        if needPredictions, prediction{i} = item.prediction; end
        if needDiagnostics, diagnostic{i} = item.diagnostic; end
        if useCache && ~needPredictions
            cache.keys{end+1} = newKeys{k};
            cache.theta(:,end+1) = thetaMatrix(:,i);
            cache.residual(:,end+1) = residual(:,i);
            cache.valid(end+1) = valid(i);
        end
    end
end
dllRuntime = toc(dllTimer);
if useCache && ~needPredictions && ~isempty(newIndex)
    cache.updatedAt = datestr(now,30);
    cache.evaluationCount = size(cache.theta,2);
    [folder,~,~] = fileparts(cacheFile);
    if exist(folder,'dir') ~= 7, mkdir(folder); end
    save(cacheFile,'cache','-v7.3');
end
output = struct('theta',thetaMatrix,'residual',residual,'valid',valid, ...
    'prediction',{prediction},'diagnostic',{diagnostic}, ...
    'insideBounds',inside, ...
    'candidateCount',nCandidate,'cacheHitCount',hitCount, ...
    'dllEvaluationCount',numel(newIndex),'dllRuntime_s',dllRuntime, ...
    'cacheFile',cacheFile, ...
    'robustTransientFallbackEnabled',robustTransientFallback);
end

function schedule = local_vector_to_schedule(contract, theta)
theta = theta(:);
if numel(theta) ~= contract.parameterCount || any(~isfinite(theta))
    error('SHT:SteadyUQB:BadScheduleVector', ...
        '方法B参数向量必须为%d维有限向量。',contract.parameterCount);
end
if any(theta < contract.lowerBound) || any(theta > contract.upperBound)
    error('SHT:SteadyUQB:ScheduleVectorOutsideBounds', ...
        '方法B参数向量超出硬边界。');
end
schedule = contract.scheduleTemplate;
tbl = contract.parameterTable;
groupIds = unique(tbl.group_index,'stable');
constantHealth = zeros(159,1);
for g = groupIds(:).'
    rows = find(tbl.group_index == g);
    kind = char(tbl.group_kind(rows(1)));
    switch kind
        case 'health_schedule'
            cIndex = tbl.c_index(rows(1));
            entryIndex = find([schedule.healthEntries.cIndex] == cIndex,1);
            if isempty(entryIndex)
                error('SHT:SteadyUQB:TemplateScheduleEntryMissing', ...
                    '方法B模板调度缺少h%d。',cIndex);
            end
            entry = schedule.healthEntries(entryIndex);
            x = tbl.coordinate(rows);
            k = theta(rows);
            if entry.pressureLoss
                entry.xNodes = [0;x(:)];
                entry.kNodes = [0;k(:)];
            else
                entry.xNodes = x(:);
                entry.kNodes = k(:);
            end
            entry.xNodesDll = entry.xNodes;
            entry.kNodesDll = entry.kNodes;
            entry.designValue = local_interp_clamp( ...
                entry.xNodesDll,entry.kNodesDll,entry.designCoordinate);
            entry.deltaNodesDll = entry.kNodesDll-entry.designValue;
            if entry.pressureLoss
                entry.kNodesDll(1) = 0;
                entry.deltaNodesDll(1) = -entry.designValue;
            end
            if isfield(entry,'dllResamplingUsed')
                entry.dllResamplingUsed = false;
            end
            schedule.healthEntries(entryIndex) = entry;
        case 'fuel_bias'
            schedule.fuelBias.xNodes = tbl.coordinate(rows);
            schedule.fuelBias.biasNodes = theta(rows);
        case 'constant'
            schedule.h15 = theta(rows(1));
        case 'health_constant'
            cIndex = tbl.c_index(rows(1));
            constantHealth(cIndex+1) = theta(rows(1));
        otherwise
            error('SHT:SteadyUQB:UnknownParameterGroupKind', ...
                '方法B未知参数组类型%s。',kind);
    end
end
schedule.designHealth = local_schedule_design_health(schedule);
activeConstant = find(constantHealth ~= 0);
schedule.designHealth(activeConstant) = constantHealth(activeConstant);
end

function theta = local_schedule_to_vector(contract, schedule)
if ~isstruct(schedule) || ~isfield(schedule,'healthEntries') || ...
        ~isfield(schedule,'fuelBias') || ~isfield(schedule,'h15') || ...
        ~isfield(schedule,'designHealth')
    error('SHT:SteadyUQB:BadScheduleForVector', ...
        '输入不是方法B完整调度结构。');
end
tbl = contract.parameterTable;
theta = nan(contract.parameterCount,1);
for i = 1:contract.parameterCount
    kind = char(tbl.group_kind(i));
    switch kind
        case 'health_schedule'
            entryIndex = find([schedule.healthEntries.cIndex] == ...
                tbl.c_index(i),1);
            if isempty(entryIndex)
                error('SHT:SteadyUQB:ScheduleEntryMissingForVector', ...
                    '输入调度缺少h%d。',tbl.c_index(i));
            end
            entry = schedule.healthEntries(entryIndex);
            theta(i) = entry.kNodesDll(tbl.dll_node_index(i));
        case 'fuel_bias'
            theta(i) = schedule.fuelBias.biasNodes(tbl.dll_node_index(i));
        case 'constant'
            theta(i) = schedule.h15;
        case 'health_constant'
            theta(i) = schedule.designHealth(tbl.c_index(i)+1);
    end
end
if any(~isfinite(theta))
    error('SHT:SteadyUQB:NonfiniteScheduleVector', ...
        '从方法B调度结构提取的参数存在非有限值。');
end
end

function health = local_schedule_design_health(schedule)
health = zeros(159,1);
for i = 1:numel(schedule.healthEntries)
    entry = schedule.healthEntries(i);
    health(entry.cIndex+1) = entry.designValue;
end
health(16) = schedule.h15;
end

function result = local_input_covariance(contract, data, options)
% 输入误差传播是A/B共用的物理测量合同，不读取方法A UQ后验。
if nargin < 2 || isempty(data), data = contract.trainingData; end
if nargin < 3 || isempty(options), options = struct(); end
baseCfg = sht_steady_model_uq_common('defaultconfig',contract.config);
baseContract = sht_steady_model_uq_common('buildcontract',baseCfg);
result = sht_steady_model_uq_common( ...
    'inputcovariance',baseContract,data,options);
result.linearizationSource = ...
    'common_upstream_deterministic_schedule_no_method_a_uq_posterior';
result.methodAPosteriorUsed = false;
end

function cache = local_empty_cache(contract, dimension)
cache = struct('schemaVersion','steady_model_uq_method_b_cache_v1', ...
    'contractHash',contract.contractHash,'residualDimension',dimension, ...
    'keys',{{}},'theta',zeros(contract.parameterCount,0), ...
    'residual',zeros(dimension,0),'valid',false(1,0), ...
    'evaluationCount',0,'updatedAt','');
end

function key = local_theta_key(theta)
key = sprintf('%.17g,',theta(:));
end

function value = local_interp_clamp(x,y,query)
x = x(:); y = y(:);
query = min(max(query,x(1)),x(end));
value = interp1(x,y,query,'linear');
end

function hash = local_runtime_code_hash()
root = fileparts(mfilename('fullpath'));
files = {'sht_steady_model_uq_b_common.m', ...
    'sht_steady_model_uq_b_smc.m', ...
    'sht_steady_model_uq_sampler.m', ...
    'sht_steady_model_uq_likelihood.m', ...
    'sht_steady_model_adapt_v2_common.m'};
textValue = '';
for i = 1:numel(files)
    file = fullfile(root,files{i});
    if exist(file,'file') == 2
        textValue = [textValue files{i} ':' ...
            sht_steady_model_uq_common('filehash',file) ';']; %#ok<AGROW>
    else
        textValue = [textValue files{i} ':missing;']; %#ok<AGROW>
    end
end
hash = local_text_hash(textValue);
end

function hash = local_text_hash(textValue)
digest = java.security.MessageDigest.getInstance('SHA-256');
bytes = unicode2native(char(textValue),'UTF-8');
% 空合同文本在独立交付场景下是合法输入；同时固定为列向量，避免
% MATLAB R2020a 对Java update重载的行列形状差异。
if ~isempty(bytes)
    digest.update(typecast(uint8(bytes(:)),'int8'));
end
digestBytes = typecast(int8(digest.digest()),'uint8');
hash = lower(reshape(dec2hex(digestBytes,2).',1,[]));
end

function value = local_option(options,name,defaultValue)
if isstruct(options) && isfield(options,name) && ~isempty(options.(name))
    value = options.(name);
else
    value = defaultValue;
end
end
