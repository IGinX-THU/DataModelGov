function result = Start_SteadyModelPredict_01_InputDrivenPrediction( ...
        modelInput, estimationResultFile, posteriorOptions)
%START_STEADYMODELPREDICT_01_INPUTDRIVENPREDICTION 输入驱动稳态预测入口。
%
% modelInput可为标量结构体或表，环境边界支持两种互斥输入方式：
%   模式2：Pamb、Tamb、Mach、Wf_model、Mkp、Mkg；
%   模式3：Altitude、Tamb、Mach、Wf_model、Mkp、Mkg。
% 可选字段为point_id、Np_initial、Ng_initial和inletBoundaryMode。若同时
% 提供Pamb和Altitude，必须显式指定模式。省略modelInput时使用模式2
% 的六部件模型设计点输入。模式3由DLL标准大气模型根据高度计算Pamb。
%
% 本入口不使用测量输出，不经过总距角或控制闭环，也不应用Wf测量偏置。
% 省略posteriorOptions时保持原确定性预测；提供标量结构体时，使用其中
% 的method（A或B）和可选runId加载正式后验并传播可信区间。也可以直接
% 用字符'A'或'B'选择对应方法的latest正式后验。

paths = sht_steady_model_adapt_v2_common('paths');
if nargin < 1
    modelInput = [];
end
if nargin < 2
    estimationResultFile = '';
end
if nargin < 3
    posteriorOptions = [];
end
if ischar(posteriorOptions) || ...
        (isstring(posteriorOptions) && isscalar(posteriorOptions))
    posteriorOptions = struct('method', char(posteriorOptions));
end
posteriorPredictionRequested = ~isempty(posteriorOptions);
if posteriorPredictionRequested && ...
        (~isstruct(posteriorOptions) || ~isscalar(posteriorOptions))
    error('SHT:SteadyPrediction:BadPosteriorOptions', ...
        'posteriorOptions必须为空、方法字符或标量结构体。');
end
defaultResultFile = fullfile(paths.middleDataDir, ...
    'steady_model_adapt_v2_transient_instant_latest.mat');
estimationResultFile = sht_resolve_delivery_input_file( ...
    estimationResultFile, defaultResultFile);
if exist(estimationResultFile,'file') ~= 2
    error('SHT:SteadyPrediction:MissingEstimationResult', ...
        '辨识结果文件不存在：%s。',estimationResultFile);
end
loaded = load(estimationResultFile,'result');
if ~isfield(loaded,'result') || ~isstruct(loaded.result)
    error('SHT:SteadyPrediction:BadEstimationResult', ...
        '文件不包含有效辨识结果变量result：%s。',estimationResultFile);
end
if isfield(loaded.result,'truthWasRead') && loaded.result.truthWasRead
    error('SHT:SteadyPrediction:TruthContaminatedResult', ...
        '所选辨识结果读取过隐藏真值，不能用于实际交付预测。');
end

usedDefaultDesignInput = isempty(modelInput);
if usedDefaultDesignInput
    cfg = sht_default_config(struct('engine',struct('modelMode',1)));
    modelInput = struct('point_id',"DESIGN_POINT", ...
        'inletBoundaryMode',2,'Altitude',0, ...
        'Pamb',101325,'Tamb',288.15,'Mach',0, ...
        'Wf_model',cfg.engine.initial.Wf0, ...
        'Mkp',cfg.engine.initial.Mkp,'Mkg',cfg.engine.initial.Mkg, ...
        'Np_initial',cfg.engine.initial.Np0, ...
        'Ng_initial',cfg.engine.initial.Ng0);
end

result = sht_steady_model_adapt_v2_common( ...
    'predictsavedschedule',loaded.result,modelInput);
result.program = mfilename;
result.estimationResultFile = estimationResultFile;
result.usedDefaultDesignInput = usedDefaultDesignInput;
result.posteriorPredictionPerformed = posteriorPredictionRequested;
if posteriorPredictionRequested
    result.posteriorPrediction = sht_steady_model_predict_posterior( ...
        loaded.result, estimationResultFile, result, posteriorOptions);
else
    result.posteriorPrediction = struct();
end
result.status = 'completed';

stamp = datestr(now,'yyyymmdd_HHMMSS');
latestFile = fullfile(paths.middleDataDir, ...
    'steady_model_input_prediction_latest.mat');
excelFile = fullfile(paths.reportOutputDir, ...
    ['steady_model_input_prediction_' stamp '.xlsx']);
summaryFile = fullfile(paths.reportOutputDir, ...
    ['steady_model_input_prediction_' stamp '_summary.md']);
posteriorFigureFile = '';
if posteriorPredictionRequested
    posteriorFigureFile = fullfile(paths.reportOutputDir, ...
        ['steady_model_input_prediction_' stamp ...
        '_posterior_intervals.png']);
end
if exist(excelFile,'file') == 2
    delete(excelFile);
end
writetable(result.predictionTable,excelFile,'Sheet','prediction');
if posteriorPredictionRequested
    writetable(result.posteriorPrediction.intervalTable, excelFile, ...
        'Sheet', 'posterior_intervals');
    local_plot_posterior_intervals( ...
        result.posteriorPrediction.intervalTable, posteriorFigureFile);
end
result.output = struct('latestMatFile',latestFile, ...
    'excelFile',excelFile,'summaryFile',summaryFile, ...
    'posteriorFigureFile',posteriorFigureFile);
local_write_summary(summaryFile,result);
save(latestFile,'result','-v7.3');
assignin('base','SteadyModelInputPredictionResult',result);

fprintf('\n=== 输入驱动稳态预测完成 ===\n');
fprintf('预测点：%d；使用设计点缺省输入：%d；全部有效：%d。\n', ...
    height(result.predictionTable),usedDefaultDesignInput,result.passed);
fprintf('进口模式：%d；控制闭环：0；测量输出：0；参数真值：0。\n', ...
    result.inputContract.inletBoundaryMode);
disp(result.predictionTable);
if posteriorPredictionRequested
    fprintf(['正式后验：方法%s，run=%s，有效后验质量=%.3f，' ...
        '区间验收=%d。\n'],result.posteriorPrediction.method, ...
        result.posteriorPrediction.runId, ...
        result.posteriorPrediction.validPosteriorMass, ...
        result.posteriorPrediction.passed);
    disp(result.posteriorPrediction.intervalTable);
end
fprintf('结果：\n  %s\n  %s\n  %s\n',latestFile,excelFile,summaryFile);
if posteriorPredictionRequested
    fprintf('  %s\n',posteriorFigureFile);
end
end

function local_write_summary(filePath,result)
fid = fopen(filePath,'w','n','UTF-8');
if fid < 0
    error('SHT:SteadyPrediction:SummaryOpenFailure', ...
        '无法写入预测摘要：%s。',filePath);
end
cleanupObject = onCleanup(@() fclose(fid));
fprintf(fid,'# 输入驱动稳态预测摘要\n\n');
fprintf(fid,'- 冻结辨识结果：`%s`\n',result.estimationResultFile);
fprintf(fid,'- 预测点数：%d\n',height(result.predictionTable));
fprintf(fid,'- 使用设计点缺省输入：%d\n',result.usedDefaultDesignInput);
fprintf(fid,'- 进口边界模式：%d\n',result.inputContract.inletBoundaryMode);
fprintf(fid,'- 高度参与环境反算：%d\n', ...
    result.inputContract.altitudeUsedForAtmosphere);
fprintf(fid,'- 控制闭环参与：%d\n',result.inputContract.controlLoopUsed);
fprintf(fid,'- 测量数据参与：%d\n',result.measurementDataUsed);
fprintf(fid,'- 参数真值被读取：%d\n',result.truthWasRead);
fprintf(fid,'- 全部预测有效：%d\n',result.passed);
fprintf(fid,'- 执行后验传播：%d\n',result.posteriorPredictionPerformed);
if result.posteriorPredictionPerformed
    posterior = result.posteriorPrediction;
    fprintf(fid,'- 后验方法：%s\n',posterior.method);
    fprintf(fid,'- 后验运行：`%s`\n',posterior.runId);
    fprintf(fid,'- 正式粒子数：%d\n',posterior.sourcePosteriorParticleCount);
    fprintf(fid,'- 唯一粒子数：%d\n',posterior.uniquePosteriorParticleCount);
    fprintf(fid,'- 有效后验质量：%.6f\n',posterior.validPosteriorMass);
    fprintf(fid,'- 模型输入不确定性传播：%d\n', ...
        posterior.inputUncertaintyPropagated);
    fprintf(fid,'- 后验区间验收：%d\n',posterior.passed);
    fprintf(fid,'- 后验传播耗时：%.3f s\n',posterior.runtime_s);
    fprintf(fid,'- 后验区间图：`%s`\n', ...
        result.output.posteriorFigureFile);
end
clear cleanupObject;
end

function local_plot_posterior_intervals(tbl, filePath)
names = unique(tbl.output_name, 'stable');
figureHandle = figure('Visible','off','Color','w', ...
    'Name','任意输入工况后验预测区间', ...
    'Position',[80,80,1380,820]);
layout = tiledlayout(2,3,'TileSpacing','compact','Padding','compact');
modelColor = [0.13,0.45,0.70];
observableColor = [0.90,0.45,0.12];
medianColor = [0.00,0.25,0.52];
frozenColor = [0.15,0.15,0.15];
for i = 1:numel(names)
    ax = nexttile(layout);
    use = tbl.output_name == names(i);
    current = tbl(use,:);
    x = (1:height(current)).';
    hold(ax,'on');
    % 四项结果采用独立横向位置，单工况时也不会相互遮挡。
    modelX = x - 0.24;
    observableX = x + 0.24;
    medianX = x - 0.07;
    frozenX = x + 0.07;
    hModel = local_interval_bar(ax,modelX,current.model_lower, ...
        current.model_upper,modelColor);
    hObservable = local_interval_bar(ax,observableX, ...
        current.observable_lower,current.observable_upper,observableColor);
    hMedian = plot(ax,medianX,current.model_median,'d', ...
        'LineStyle','none','Color',medianColor, ...
        'MarkerFaceColor',medianColor,'MarkerSize',7,'LineWidth',1.2);
    hFrozen = plot(ax,frozenX,current.deterministic_frozen_model,'x', ...
        'LineStyle','none','Color',frozenColor, ...
        'MarkerSize',9,'LineWidth',1.8);
    hold(ax,'off');
    grid(ax,'on');
    title(ax,char(names(i)),'Interpreter','none');
    xlabel(ax,'预测工况');
    ylabel(ax,char(current.unit(1)),'Interpreter','none');
    xticks(ax,x);
    xticklabels(ax,cellstr(current.point_id));
    ax.TickLabelInterpreter = 'none';
    xlim(ax,[0.55,height(current)+0.45]);
    if i == 1
        legend(ax,[hModel,hObservable,hMedian,hFrozen], ...
            {'模型输出95%区间','可观测量95%区间','后验中位数', ...
            '冻结个体模型'},'Location','best');
    end
end
title(layout,'任意指定工况的后验预测区间');
exportgraphics(figureHandle,filePath,'Resolution',160);
close(figureHandle);
end

function handle = local_interval_bar(ax,x,lower,upper,color)
center = 0.5*(lower+upper);
handle = errorbar(ax,x,center,center-lower,upper-center, ...
    'LineStyle','none','Marker','none','Color',color, ...
    'LineWidth',2.2,'CapSize',12);
end
