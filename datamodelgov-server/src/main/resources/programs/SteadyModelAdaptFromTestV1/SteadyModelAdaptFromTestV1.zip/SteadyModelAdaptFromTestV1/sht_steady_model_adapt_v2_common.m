function varargout = sht_steady_model_adapt_v2_common(action, varargin)
%SHT_STEADY_MODEL_ADAPT_V2_COMMON 第二轮六部件稳态修正系数辨识公共内核。
%
% 该文件只提供无状态公共能力。两个正式入口分别选择steady和
% transient_instant模型口径，互不读取结果、互不调用，也不共享初值文件。
% 隐藏真值不在本文件中读取，保证参数估计与仿真真值严格隔离。

switch lower(action)
    case 'defaultoptions'
        varargout{1} = local_default_options(varargin{:});
    case 'run'
        varargout{1} = local_run(varargin{:});
    case 'paths'
        varargout{1} = local_paths(varargin{:});
    case 'readmeasurementtable'
        varargout{1} = local_read_measurement_table(varargin{:});
    case 'validatesavedschedule'
        varargout{1} = local_validate_saved_schedule(varargin{:});
    case 'predictsavedschedule'
        varargout{1} = local_predict_saved_schedule(varargin{:});
    case 'evaluateschedule'
        varargout{1} = local_evaluate_saved_schedule(varargin{:});
    case 'evaluateconstant'
        varargout{1} = local_evaluate_saved_constant(varargin{:});
    case 'evaluateoffsetbatch'
        varargout{1} = local_evaluate_offset_batch(varargin{:});
    case 'evaluateoffsetbatchdataset'
        varargout{1} = local_evaluate_offset_batch_dataset(varargin{:});
    case 'evaluateschedulebatchdataset'
        varargout{1} = local_evaluate_schedule_batch_dataset(varargin{:});
    case 'evaluatedatasetvariants'
        varargout{1} = local_evaluate_dataset_variants(varargin{:});
    otherwise
        error('SHT:SteadyAdaptV2:UnknownAction', ...
            '未知第二轮稳态辨识公共动作：%s。', action);
end
end

function options = local_default_options(route)
% 所有可调数值集中在入口配置中，避免求解器内部出现不可追溯常数。
route = local_validate_route(route);
options = struct();
options.route = route;
options.modelMode = 1;
options.clusterSpan = 0.010;
options.nodeMergeFraction = 0.005;
options.nodeMergeAbsolute = 1e-5;
options.maxModelResidual = 1e-2;
options.maxIterationA = 12;
options.maxIterationGroup = 4;
% 阶段D需要在Stage C曲线基础上联合修正11个整体偏移量。现有对比中
% Tikhonov通常在第7轮收敛，因此默认上限取10，避免5轮上限造成假停机。
options.maxIterationRefine = 10;
options.initialLambda = 1e-2;
options.costRelativeTolerance = 1e-4;
options.stepRelativeTolerance = 1e-3;
options.figureVisible = 'off';
options.verbose = true;
options.randomSeed = 20260820;
options.saveStampedResult = true;
% 实际交付辨识只读取训练集。历史专项对照如需在同一运行中评价测试集，
% 必须显式打开evaluateTestSet并给出testFile。
options.trainingFile = '';
options.testFile = '';
options.evaluateTestSet = false;
options.inletBoundaryMode = 4;
options.pt1TruthFile = '';
options.outputTag = '';
options.stageAOnly = false;
% 瞬态时刻路径完成测试集回放后，额外用各测试点的瞬态共同工作解
% 初始化稳态求解，检验同一组参数对整机稳态平衡和两轴转速的预测能力。
options.evaluateSteadyTestFromTransient = true;
% 正式辨识和正式UQ保持C端RunOneStep原求解口径。该开关只允许专项
% 诊断调用稳健七维Newton，以区分参数不可行与C端Newton未收敛。
options.useRobustTransientFallback = false;
% 历史程序默认用测得转速把Mkp/Mkg换算成固定功率。专项稳态分支回放
% 可显式选择torque，使Newton每次残差计算按候选转速实时换算功率。
options.steadyLoadBoundaryMode = 'fixed_power';
options.includePt2Residual = false;
options.estimateInletPressureLoss = false;
options.stageARegularizationMethod = 'tsvd';
% 阶段A采用Tikhonov时，对10个发动机参数和1个燃油偏置的工程先验
% 标准差统一缩放。该倍率只改变统计正则强度，不改变LM数值阻尼。
options.stageATikhonovPriorScale = 1.0;
% TSVD首选直接配置“截断个数”。保留个数字段仅用于兼容历史入口；
% 非空时由它覆盖截断个数，并由待估参数总数反算实际截断个数。
options.stageATsvdTruncatedCount = 5;
options.stageATsvdRetainedCount = [];
% TSVD只允许严格截断伪逆：保留方向使用1/sigma，截断方向置零。
% 若求解不稳定，应减少保留奇异方向数，不得引入阻尼TSVD。
options.stageATsvdStepMode = 'direct_inverse';
% 阶段B保留两种正式方法：
%   tikhonov  以阶段A为先验中心的软约束方法；
%   tsvd      逐轮更新SVD子空间，保留方向直接逆、截断方向置零。
options.stageBRegularizationMethod = 'tikhonov';
% 阶段B采用Tikhonov时，统一缩放10个发动机参数和1个燃油偏置的
% 先验标准差。小于1增强正则化，大于1减弱正则化；不改变LM数值阻尼。
options.stageBTikhonovPriorScale = 0.75;
% r=1...6扫描表明，保留5个方向时训练集和两类测试集预测最均衡。
options.stageBTsvdRetainedCount = 5;
% 阶段D在Stage C调度曲线基础上联合估计10个健康曲线整体偏移和
% 1个燃油偏置曲线整体偏移。Tikhonov保留原实现；TSVD仅使用数据
% 雅可比，保留方向直接逆、截断方向严格置零。
options.stageDRegularizationMethod = 'tikhonov';
options.stageDTikhonovPriorScale = 1.0;
% r=1...11扫描及专项稳定性检查表明，保留6个方向在参数恢复、输出
% 泛化和条件数之间更均衡；正式入口采用该值，Tikhonov仍可切换对照。
options.stageDTsvdRetainedCount = 6;
% 阶段D稳定性检查接口。差分倍率只缩放阶段D物理参数差分步长；
% 初值为空时从零偏移开始，非空时必须提供全部11个整体偏移量。
options.stageDDifferenceStepScale = 1.0;
options.stageDInitialOffset = [];
% 正式入口打开以下门控，专项扫描程序保持关闭以便记录未收敛方案。
options.requireConvergedStages = false;
options.requireValidFinalReplay = false;
% measured表示输入Wf是传感器读数，需要扣除估计偏置；physical_model
% 表示输入已经是发动机模型所需的物理燃油流量，不再应用测量偏置。
options.fuelInputSemantics = 'measured';
end

function result = local_run(route, options)
route = local_validate_route(route);
if nargin < 2 || isempty(options)
    options = local_default_options(route);
else
    options = local_complete_options(options, route);
end
rng(options.randomSeed, 'twister');
runTimer = tic;
phaseTimer = tic;

paths = local_paths(options);
[trainingData, testData] = local_read_input_tables(paths, options);
testDataAvailable = options.evaluateTestSet && ~isempty(testData);
truthInput = struct('used', false, 'sourceFile', "", ...
    'sourceColumn', "", 'pointCount', 0);
if options.inletBoundaryMode == 1
    [trainingData, testData, truthInput] = local_attach_pt1_truth( ...
        trainingData, testData, paths, options);
elseif ~ismember(options.inletBoundaryMode, [2, 4])
    error('SHT:SteadyAdaptV2:UnsupportedInletBoundaryMode', ...
        ['第二轮稳态辨识公共内核仅支持模式1（Pt1/Tt1直接输入对照）' ...
         '、模式2（Pamb/Tamb/Mach环境输入）或模式4' ...
         '（实测Pt2直接输入），当前为%d。'], ...
        options.inletBoundaryMode);
end
parameters = local_parameter_definition(options);

cfg = sht_default_config(struct('engine', struct('modelMode', 1)));
if cfg.engine.modelMode ~= 1
    error('SHT:SteadyAdaptV2:WrongModelMode', ...
        '第二轮辨识必须使用六部件模型modelMode=1。');
end
engine = sht_engine_open(cfg.engine);
cleanupObject = onCleanup(@() sht_engine_close(engine));
timing = struct();
timing.dataAndInitializationSeconds = toc(phaseTimer);

wfDesign = cfg.engine.initial.Wf0;
scales = local_residual_scales(route, cfg, trainingData, options);
zeroModel = local_constant_model(parameters, zeros(height(parameters), 1), 0);

if options.verbose
    fprintf('\n=== 第二轮六部件稳态修正系数辨识：%s ===\n', ...
        local_route_label(route));
    fprintf('训练点：%d，嵌入测试点：%d，设计点Wf：%.9g kg/s\n', ...
        height(trainingData), height(testData), wfDesign);
    if ~testDataAvailable
        fprintf('参数辨识未读取测试集；测试验证由独立交付入口执行。\n');
    end
end

% 零修正回放同时给出聚类坐标。它只使用公开Excel，不读取真值调度资产。
phaseTimer = tic;
[baselineTraining, baselineTrainingValid] = local_evaluate_dataset( ...
    route, engine, cfg, trainingData, zeroModel, options);
[baselineTest, baselineTestValid, baselineTestDiagnostic] = local_evaluate_dataset( ...
    route, engine, cfg, testData, zeroModel, options);
if ~baselineTrainingValid
    disp(baselineTraining(:, {'point_id','return_code','converge_tag', ...
        'max_model_residual','error_message'}));
    error('SHT:SteadyAdaptV2:BaselineTrainingFailure', ...
        '零修正模型不能完成全部训练工况回放，禁止继续参数估计。');
end
% 分组是试车数据本身的属性，不应随稳态/瞬态回放路径改变。AC与CC
% 共用高压轴，且进气道近似绝热，因此用实测Ng和Tt1构造相对换算
% 转速。模型内部AC换算转速仍用于各调度曲线的实际横坐标。
measuredAcCorrectedSpeed = local_measured_ac_corrected_speed( ...
    trainingData, cfg);
groups = local_cluster_by_ac_speed( ...
    trainingData, measuredAcCorrectedSpeed, options.clusterSpan);
timing.baselineAndClusteringSeconds = toc(phaseTimer);

if options.verbose
    fprintf('AC相对换算转速聚类得到%d组。\n', height(groups));
    disp(groups(:, {'group_id','point_ids','point_count', ...
        'ac_ncr_mean','ac_ncr_min','ac_ncr_max'}));
end

% 阶段A：全部训练工况上的常值估计。模式4默认将进气道压损从联合
% 未知量中移除，因此为10个发动机修正系数加1个燃油偏置。
phaseTimer = tic;
[lowerA, upperA, priorSigmaA, diffStepA] = ...
    local_constant_parameter_settings(parameters, wfDesign, 'global');
x0A = zeros(height(parameters) + 1, 1);
priorSigmaAUsed = priorSigmaA;
if strcmp(options.stageARegularizationMethod, 'tikhonov')
    priorSigmaAUsed = priorSigmaA .* options.stageATikhonovPriorScale;
end
[retainedCountA, truncatedCountA, countSourceA] = ...
    local_resolve_stage_a_tsvd_count(options, numel(x0A));
options.stageATsvdRetainedCountResolved = retainedCountA;
options.stageATsvdTruncatedCountResolved = truncatedCountA;
options.stageATsvdCountSource = countSourceA;
objectiveA = @(x) local_constant_objective( ...
    x, route, engine, cfg, trainingData, parameters, scales, ...
    zeros(size(x0A)), priorSigmaAUsed, options, ...
    options.stageARegularizationMethod);
stageAOptions = options;
stageAUseDirectTsvdInverse = ...
    strcmp(options.stageARegularizationMethod, 'tsvd') && ...
    strcmp(options.stageATsvdStepMode, 'direct_inverse');
if stageAUseDirectTsvdInverse
    % 无阻尼TSVD不使用LM滤波参数；候选步仍需通过边界、有效性和
    % 代价下降线搜索，因此“无阻尼”不等于无约束全步接受。
    stageAOptions.initialLambda = 0;
end
stageA = local_bounded_lm(objectiveA, x0A, lowerA, upperA, ...
    diffStepA, options.maxIterationA, stageAOptions, 'A_all_point_constant', ...
    options.stageARegularizationMethod, priorSigmaAUsed, ...
    retainedCountA, stageAUseDirectTsvdInverse);
stageA.priorSigmaBaseline = priorSigmaA;
stageA.priorSigmaUsed = priorSigmaAUsed;
stageA.tikhonovPriorScale = options.stageATikhonovPriorScale;
timing.stageASeconds = toc(phaseTimer);

if options.verbose
    fprintf('阶段A：cost %.6g -> %.6g，迭代%d次，停止原因=%s。\n', ...
        stageA.costInitial, stageA.costFinal, stageA.iterationCount, ...
        stageA.stopReason);
    fprintf(['阶段A正则化：%s；信息矩阵维数=%d x %d；' ...
        '待估计参数=%d；保留/截断奇异值=%d/%d。\n'], ...
        upper(stageA.regularizationMethod), ...
        stageA.informationMatrixDimension(1), ...
        stageA.informationMatrixDimension(2), ...
        stageA.parameterCount, stageA.retainedSingularValueCount, ...
        stageA.truncatedSingularValueCount);
    if strcmp(stageA.regularizationMethod, 'tsvd')
        fprintf('阶段A TSVD步长模式：%s。\n', stageA.tsvdStepMode);
    end
end

if options.stageAOnly
    result = local_finish_stage_a_only(route, options, paths, ...
        trainingData, testData, parameters, scales, engine, cfg, ...
        zeroModel, baselineTraining, baselineTest, ...
        baselineTrainingValid, baselineTestValid, groups, stageA, ...
        timing, runTimer, truthInput, baselineTestDiagnostic);
    clear cleanupObject;
    return;
end

% 阶段B：每个AC转速组内同时估计10个发动机修正系数和1个燃油偏置。
% 两种方法使用同一个阶段A结果作为参考中心，但弱方向的处理不同。
phaseTimer = tic;
groupResults = repmat(local_empty_group_result(), height(groups), 1);
[lowerG, upperG, priorSigmaG, diffStepG] = ...
    local_constant_parameter_settings(parameters, wfDesign, 'group');
for i = 1:height(groups)
    rowMask = local_group_row_indices(groups, i);
    groupData = trainingData(rowMask, :);
    stageBMethod = options.stageBRegularizationMethod;
    priorSigmaGUsed = priorSigmaG;
    if strcmp(stageBMethod, 'tikhonov')
        priorSigmaGUsed = priorSigmaG .* options.stageBTikhonovPriorScale;
    end
    objectiveG = @(x) local_constant_objective( ...
        x, route, engine, cfg, groupData, parameters, scales, ...
        stageA.x, priorSigmaGUsed, options, stageBMethod);
    stageBOptions = options;
    if strcmp(stageBMethod, 'tsvd')
        stageBOptions.initialLambda = 0;
    end
    labelG = sprintf('B_group_%02d', i);
    solveG = local_bounded_lm(objectiveG, stageA.x, lowerG, upperG, ...
        diffStepG, options.maxIterationGroup, stageBOptions, labelG, ...
        stageBMethod, priorSigmaGUsed, options.stageBTsvdRetainedCount, ...
        strcmp(stageBMethod, 'tsvd'));
    solveG = local_annotate_stage_b_solve( ...
        solveG, stageA.x, priorSigmaGUsed, stageBMethod);
    groupResults(i).group_id = groups.group_id(i);
    groupResults(i).point_ids = groups.point_ids(i);
    groupResults(i).row_indices = rowMask;
    groupResults(i).x = solveG.x;
    groupResults(i).solve = solveG;
    if options.verbose
        fprintf(['阶段B %s（%s）：cost %.6g -> %.6g，迭代%d次，' ...
            '保留奇异方向%d个。\n'], ...
            char(groups.group_id(i)), upper(stageBMethod), ...
            solveG.costInitial, solveG.costFinal, solveG.iterationCount, ...
            solveG.retainedSingularValueCount);
    end
end
timing.stageBSeconds = toc(phaseTimer);

% 阶段C：组间等效常值转换为10条健康曲线、1条燃油偏置曲线和h15常值。
phaseTimer = tic;
scheduleB = local_build_schedule( ...
    trainingData, baselineTraining, groups, groupResults, ...
    parameters, wfDesign, options);
inletDirect = struct();
if options.inletBoundaryMode == 4 && ~options.estimateInletPressureLoss
    inletDirect = local_build_direct_inlet_pressure_loss( ...
        trainingData, stageA.meta.prediction, table(), table(), options);
    scheduleB = local_attach_direct_inlet_schedule(scheduleB, inletDirect);
end
[scheduleB, predictionBTraining, predictionBTrainingValid, ...
    scheduleStabilization] = local_stabilize_schedule( ...
    scheduleB, stageA.x, route, engine, cfg, trainingData, ...
    parameters, options);
if ~predictionBTrainingValid
    error('SHT:SteadyAdaptV2:NoValidScheduleInitialization', ...
        '组间调度曲线向阶段A回缩后仍不能通过全部训练工况收敛门限。');
end
timing.stageCSeconds = toc(phaseTimer);

% 阶段D：保持曲线相对形状，只释放每条曲线的整体小偏移。
phaseTimer = tic;
[lowerR, upperR, priorSigmaR, diffStepR] = ...
    local_refine_parameter_settings(scheduleB, parameters, wfDesign);
diffStepR = diffStepR .* options.stageDDifferenceStepScale;
stageDParameterCount = height(parameters) + 1;
if isempty(options.stageDInitialOffset)
    x0R = zeros(stageDParameterCount, 1);
else
    x0R = options.stageDInitialOffset(:);
    if numel(x0R) ~= stageDParameterCount || any(~isfinite(x0R))
        error('SHT:SteadyAdaptV2:BadStageDInitialOffsetLength', ...
            '阶段D初值必须为空或包含%d个有限整体偏移量。', ...
            stageDParameterCount);
    end
    if any(x0R < lowerR | x0R > upperR)
        error('SHT:SteadyAdaptV2:StageDInitialOffsetOutOfBounds', ...
            '阶段D初值存在超出当前调度曲线可用参数边界的分量。');
    end
end
stageDMethod = options.stageDRegularizationMethod;
priorSigmaRUsed = priorSigmaR;
stageDOptions = options;
if strcmp(stageDMethod, 'tikhonov')
    priorSigmaRUsed = priorSigmaR .* options.stageDTikhonovPriorScale;
else
    stageDOptions.initialLambda = 0;
end
objectiveR = @(x) local_schedule_objective( ...
    x, scheduleB, route, engine, cfg, trainingData, ...
    parameters, scales, priorSigmaRUsed, options, stageDMethod);
stageRefine = local_bounded_lm(objectiveR, x0R, lowerR, upperR, ...
    diffStepR, options.maxIterationRefine, stageDOptions, ...
    'D_all_point_schedule_refine', stageDMethod, priorSigmaRUsed, ...
    options.stageDTsvdRetainedCount, strcmp(stageDMethod, 'tsvd'));
stageRefine.initialOffset = x0R;
stageRefine.differenceStep = diffStepR;
stageRefine.differenceStepScale = options.stageDDifferenceStepScale;
stageRefine.lowerBound = lowerR;
stageRefine.upperBound = upperR;
relativeLowerMargin = (stageRefine.x - lowerR) ./ max(upperR - lowerR, eps);
relativeUpperMargin = (upperR - stageRefine.x) ./ max(upperR - lowerR, eps);
stageRefine.minimumRelativeBoundMargin = min([ ...
    relativeLowerMargin(:); relativeUpperMargin(:)]);
stageRefine.atBound = stageRefine.minimumRelativeBoundMargin <= 1e-8;
finalSchedule = local_apply_schedule_offsets( ...
    scheduleB, stageRefine.x, parameters);
finalModel = local_schedule_model(finalSchedule);
timing.stageDSeconds = toc(phaseTimer);

phaseTimer = tic;
[finalTraining, finalTrainingValid] = local_evaluate_dataset( ...
    route, engine, cfg, trainingData, finalModel, options);
[finalTest, finalTestValid, finalTestDiagnostic] = local_evaluate_dataset( ...
    route, engine, cfg, testData, finalModel, options);

steadyTestFromTransient = local_evaluate_transient_test_as_steady( ...
    route, engine, cfg, trainingData, testData, ...
    zeroModel, finalModel, options, ...
    baselineTestDiagnostic, finalTestDiagnostic);

baselineMetricsTraining = local_dataset_metrics( ...
    route, trainingData, baselineTraining, scales);
baselineMetricsTest = local_dataset_metrics( ...
    route, testData, baselineTest, scales);
finalMetricsTraining = local_dataset_metrics( ...
    route, trainingData, finalTraining, scales);
finalMetricsTest = local_dataset_metrics( ...
    route, testData, finalTest, scales);

parameterTable = local_parameter_result_table( ...
    parameters, stageA.x, groupResults, finalSchedule);
groupEstimateTable = local_group_estimate_table( ...
    groups, groupResults, parameters, wfDesign);
scheduleNodeTable = local_schedule_node_table(finalSchedule);
predictionTrainingTable = local_prediction_detail_table( ...
    route, trainingData, baselineTraining, finalTraining, scales);
predictionTestTable = local_prediction_detail_table( ...
    route, testData, baselineTest, finalTest, scales);
timing.finalEvaluationSeconds = toc(phaseTimer);
timing.estimationSeconds = toc(runTimer);

result = struct();
result.schemaVersion = 'SHT_STEADY_MODEL_ADAPT_V2_RESULT_V2_DELIVERY_SEPARATED';
result.program = '';
result.route = route;
result.routeLabel = local_route_label(route);
result.createdAt = datestr(now, 31);
result.timing = timing;
result.options = options;
result.input = struct('trainingFile', paths.trainingFile, ...
    'testFile', paths.testFile, 'trainingPointCount', height(trainingData), ...
    'testPointCount', height(testData), ...
    'testDataAvailable', testDataAvailable, ...
    'inletBoundaryMode', options.inletBoundaryMode, ...
    'residualIncludesPt2', options.includePt2Residual, ...
    'pt1TruthSource', truthInput);
result.parameterDefinition = parameters;
result.residualScales = scales;
result.groups = groups;
result.baseline = struct('training', baselineTraining, ...
    'test', baselineTest, 'trainingValid', baselineTrainingValid, ...
    'testValid', local_optional_test_valid(testDataAvailable, baselineTestValid), ...
    'trainingMetrics', baselineMetricsTraining, ...
    'testMetrics', baselineMetricsTest);
result.stageA = stageA;
result.stageB = groupResults;
result.scheduleBeforeRefine = scheduleB;
result.scheduleBeforeRefineTrainingPrediction = predictionBTraining;
result.scheduleBeforeRefineTrainingValid = predictionBTrainingValid;
result.scheduleStabilization = scheduleStabilization;
result.stageRefine = stageRefine;
result.finalSchedule = finalSchedule;
result.final = struct('training', finalTraining, 'test', finalTest, ...
    'trainingValid', finalTrainingValid, ...
    'testValid', local_optional_test_valid(testDataAvailable, finalTestValid), ...
    'trainingMetrics', finalMetricsTraining, ...
    'testMetrics', finalMetricsTest);
result.steadyTestFromTransient = steadyTestFromTransient;
result.parameterTable = parameterTable;
result.groupEstimateTable = groupEstimateTable;
result.scheduleNodeTable = scheduleNodeTable;
result.predictionTrainingTable = predictionTrainingTable;
result.predictionTestTable = predictionTestTable;
result.inletPressureLossDirect = inletDirect;
result.truthWasRead = truthInput.used;
stageBConverged = arrayfun(@(x) x.solve.converged, groupResults);
result.acceptance = struct( ...
    'stageAConverged', stageA.converged, ...
    'stageBAllConverged', all(stageBConverged), ...
    'stageBConvergedByGroup', stageBConverged(:), ...
    'stageDConverged', stageRefine.converged, ...
    'trainingReplayValid', finalTrainingValid, ...
    'testReplayValid', local_optional_test_valid(testDataAvailable, finalTestValid), ...
    'allStagesConverged', stageA.converged && ...
        all(stageBConverged) && stageRefine.converged, ...
    'formalAccepted', stageA.converged && ...
        all(stageBConverged) && stageRefine.converged && ...
        finalTrainingValid && (~testDataAvailable || finalTestValid));

if options.requireConvergedStages && ~result.acceptance.allStagesConverged
    failedGroup = find(~stageBConverged);
    error('SHT:SteadyAdaptV2:FormalStageNotConverged', ...
        ['正式%s路径存在未收敛阶段：A=%d，B未收敛组=%s，D=%d。' ...
         '当前结果不会覆盖正式latest文件。'], ...
        route, stageA.converged, mat2str(failedGroup(:).'), ...
        stageRefine.converged);
end
if options.requireValidFinalReplay && ...
        ~(finalTrainingValid && (~testDataAvailable || finalTestValid))
    error('SHT:SteadyAdaptV2:FormalReplayInvalid', ...
        ['正式%s路径最终训练/测试回放有效性为%d/%s；' ...
         '当前结果不会覆盖正式latest文件。'], ...
        route, finalTrainingValid, ...
        local_optional_test_valid_text(testDataAvailable, finalTestValid));
end

stamp = datestr(now, 'yyyymmdd_HHMMSS');
routeTag = local_result_tag(route, options);
latestFile = fullfile(paths.middleDataDir, ...
    ['steady_model_adapt_v2_' routeTag '_latest.mat']);
stampedFile = fullfile(paths.middleDataDir, ...
    ['steady_model_adapt_v2_' routeTag '_' stamp '.mat']);
excelFile = fullfile(paths.reportOutputDir, ...
    ['steady_model_adapt_v2_' routeTag '_' stamp '.xlsx']);
summaryFile = fullfile(paths.reportOutputDir, ...
    ['steady_model_adapt_v2_' routeTag '_' stamp '_summary.md']);

result.output = struct('latestMatFile', latestFile, ...
    'stampedMatFile', stampedFile, 'excelFile', excelFile, ...
    'summaryFile', summaryFile, 'figureFiles', strings(0, 1));
save(latestFile, 'result', '-v7.3');
if options.saveStampedResult
    save(stampedFile, 'result', '-v7.3');
end
local_write_result_excel(excelFile, result);
figureFiles = local_plot_result(result, paths, stamp);
result.output.figureFiles = figureFiles;
local_write_summary(summaryFile, result);
save(latestFile, 'result', '-v7.3');
if options.saveStampedResult
    save(stampedFile, 'result', '-v7.3');
end

if options.verbose
    fprintf('\n最终训练NRMS：%.6g -> %.6g。\n', ...
        baselineMetricsTraining.overall_nrms, ...
        finalMetricsTraining.overall_nrms);
    if testDataAvailable
        fprintf('嵌入测试NRMS：%.6g -> %.6g；训练/测试回放有效：%d/%d。\n', ...
            baselineMetricsTest.overall_nrms, finalMetricsTest.overall_nrms, ...
            finalTrainingValid, finalTestValid);
    else
        fprintf('训练回放有效：%d；测试集未在辨识入口中读取。\n', ...
            finalTrainingValid);
    end
    local_print_steady_test_from_transient(steadyTestFromTransient);
    fprintf('辨识与验证计算耗时：%.3f s。\n', timing.estimationSeconds);
    fprintf('结果：\n  %s\n  %s\n', latestFile, excelFile);
end

clear cleanupObject;
end

function result = local_finish_stage_a_only(route, options, paths, ...
        trainingData, testData, parameters, scales, engine, cfg, ...
        zeroModel, baselineTraining, baselineTest, baselineTrainingValid, ...
        baselineTestValid, groups, stageA, timing, runTimer, truthInput, ...
        baselineTestDiagnostic)
% 对照试验只验收全工况常值辨识，不进入分组与调度曲线。
phaseTimer = tic;
nHealth = height(parameters);
stageAModel = local_constant_model( ...
    parameters, stageA.x(1:nHealth), stageA.x(end));
[stageATraining, stageATrainingValid] = local_evaluate_dataset( ...
    route, engine, cfg, trainingData, stageAModel, options);
[stageATest, stageATestValid, stageATestDiagnostic] = local_evaluate_dataset( ...
    route, engine, cfg, testData, stageAModel, options);
steadyTestFromTransient = local_evaluate_transient_test_as_steady( ...
    route, engine, cfg, trainingData, testData, ...
    zeroModel, stageAModel, options, ...
    baselineTestDiagnostic, stageATestDiagnostic);
baselineMetricsTraining = local_dataset_metrics( ...
    route, trainingData, baselineTraining, scales);
baselineMetricsTest = local_dataset_metrics( ...
    route, testData, baselineTest, scales);
stageAMetricsTraining = local_dataset_metrics( ...
    route, trainingData, stageATraining, scales);
stageAMetricsTest = local_dataset_metrics( ...
    route, testData, stageATest, scales);
predictionTrainingTable = local_prediction_detail_table( ...
    route, trainingData, baselineTraining, stageATraining, scales);
predictionTestTable = local_prediction_detail_table( ...
    route, testData, baselineTest, stageATest, scales);
if options.inletBoundaryMode == 4 && ~options.estimateInletPressureLoss
    inletPressureLossDirect = local_build_direct_inlet_pressure_loss( ...
        trainingData, stageATraining, testData, stageATest, options);
else
    inletPressureLossDirect = struct();
end
timing.finalEvaluationSeconds = toc(phaseTimer);
timing.estimationSeconds = toc(runTimer);

parameterTable = table( ...
    [parameters.c_index; NaN], ...
    [parameters.name; "Wf_bias"], ...
    [repmat("health_coefficient", nHealth, 1); "kg/s"], ...
    stageA.x(:), ...
    'VariableNames', {'c_index','name','unit','stageA_estimate'});

result = struct();
result.schemaVersion = ...
    'SHT_STEADY_MODEL_ADAPT_V2_STAGE_A_RESULT_V2_DELIVERY_SEPARATED';
result.program = '';
result.route = route;
result.routeLabel = [local_route_label(route) '（仅A阶段）'];
result.createdAt = datestr(now, 31);
result.timing = timing;
result.options = options;
result.input = struct('trainingFile', paths.trainingFile, ...
    'testFile', paths.testFile, 'trainingPointCount', height(trainingData), ...
    'testPointCount', height(testData), ...
    'testDataAvailable', ~isempty(testData), ...
    'inletBoundaryMode', options.inletBoundaryMode, ...
    'residualIncludesPt2', options.includePt2Residual, ...
    'pt1TruthSource', truthInput);
result.parameterDefinition = parameters;
result.residualScales = scales;
result.groups = groups;
result.baseline = struct('training', baselineTraining, ...
    'test', baselineTest, 'trainingValid', baselineTrainingValid, ...
    'testValid', local_optional_test_valid(~isempty(testData), baselineTestValid), ...
    'trainingMetrics', baselineMetricsTraining, ...
    'testMetrics', baselineMetricsTest);
result.stageA = stageA;
result.stageAReplay = struct('training', stageATraining, ...
    'test', stageATest, 'trainingValid', stageATrainingValid, ...
    'testValid', local_optional_test_valid(~isempty(testData), stageATestValid), ...
    'trainingMetrics', stageAMetricsTraining, ...
    'testMetrics', stageAMetricsTest);
result.steadyTestFromTransient = steadyTestFromTransient;
result.parameterTable = parameterTable;
result.predictionTrainingTable = predictionTrainingTable;
result.predictionTestTable = predictionTestTable;
result.inletPressureLossDirect = inletPressureLossDirect;
result.truthWasRead = truthInput.used;

stamp = datestr(now, 'yyyymmdd_HHMMSS');
routeTag = local_result_tag(route, options);
latestFile = fullfile(paths.middleDataDir, ...
    ['steady_model_adapt_v2_' routeTag '_latest.mat']);
stampedFile = fullfile(paths.middleDataDir, ...
    ['steady_model_adapt_v2_' routeTag '_' stamp '.mat']);
excelFile = fullfile(paths.reportOutputDir, ...
    ['steady_model_adapt_v2_' routeTag '_' stamp '.xlsx']);
summaryFile = fullfile(paths.reportOutputDir, ...
    ['steady_model_adapt_v2_' routeTag '_' stamp '_summary.md']);
result.output = struct('latestMatFile', latestFile, ...
    'stampedMatFile', stampedFile, 'excelFile', excelFile, ...
    'summaryFile', summaryFile, 'figureFiles', strings(0, 1));

save(latestFile, 'result', '-v7.3');
if options.saveStampedResult
    save(stampedFile, 'result', '-v7.3');
end
writetable(parameterTable, excelFile, 'Sheet', 'stageA_parameters');
writetable(stageA.history, excelFile, 'Sheet', 'stageA_history');
writetable(predictionTrainingTable, excelFile, 'Sheet', 'training');
if result.input.testDataAvailable
    writetable(predictionTestTable, excelFile, 'Sheet', 'test');
end
writetable(scales, excelFile, 'Sheet', 'residual_scales');
local_write_steady_test_from_transient_excel( ...
    excelFile, steadyTestFromTransient);
if ~isempty(fieldnames(inletPressureLossDirect))
    writetable(inletPressureLossDirect.trainingTable, excelFile, ...
        'Sheet', 'inlet_kdp_training');
    if result.input.testDataAvailable
        writetable(inletPressureLossDirect.testTable, excelFile, ...
            'Sheet', 'inlet_kdp_test');
    end
    inletNodeTable = table( ...
        inletPressureLossDirect.entry.xNodes, ...
        inletPressureLossDirect.entry.kNodes, ...
        'VariableNames', {'inlet_corrected_mass_flow','Inlet_K_dP'});
    writetable(inletNodeTable, excelFile, 'Sheet', 'inlet_kdp_nodes');
end
local_write_stage_a_summary(summaryFile, result);

if options.verbose
    fprintf('\nA阶段训练NRMS：%.6g -> %.6g。\n', ...
        baselineMetricsTraining.overall_nrms, ...
        stageAMetricsTraining.overall_nrms);
    if result.input.testDataAvailable
        fprintf('A阶段测试NRMS：%.6g -> %.6g；训练/测试回放有效：%d/%d。\n', ...
            baselineMetricsTest.overall_nrms, stageAMetricsTest.overall_nrms, ...
            stageATrainingValid, stageATestValid);
    else
        fprintf('A阶段训练回放有效：%d；测试集未在辨识入口中读取。\n', ...
            stageATrainingValid);
    end
    local_print_steady_test_from_transient(steadyTestFromTransient);
    fprintf('A阶段辨识与回放耗时：%.3f s。\n', timing.estimationSeconds);
    fprintf('结果：\n  %s\n  %s\n', latestFile, excelFile);
end
end

function local_write_stage_a_summary(filePath, result)
fid = fopen(filePath, 'w', 'n', 'UTF-8');
if fid < 0
    error('SHT:SteadyAdaptV2:SummaryOpenFailure', ...
        '无法写入A阶段摘要：%s。', filePath);
end
cleanupObject = onCleanup(@() fclose(fid));
fprintf(fid, '# 第二轮六部件稳态辨识A阶段对照\n\n');
fprintf(fid, '- 模型路径：%s\n', result.routeLabel);
fprintf(fid, '- 进口边界模式：%d\n', result.input.inletBoundaryMode);
fprintf(fid, '- 残差是否包含Pt2：%d\n', ...
    result.input.residualIncludesPt2);
fprintf(fid, '- Pt1来源：%s\n', result.input.pt1TruthSource.sourceFile);
fprintf(fid, '- 训练点/测试点：%d/%d\n', ...
    result.input.trainingPointCount, result.input.testPointCount);
fprintf(fid, '- cost：%.12g -> %.12g\n', ...
    result.stageA.costInitial, result.stageA.costFinal);
fprintf(fid, '- 迭代次数：%d\n', result.stageA.iterationCount);
fprintf(fid, '- 停止原因：%s\n', result.stageA.stopReason);
fprintf(fid, '- 数值秩/条件数：%d / %.12g\n', ...
    result.stageA.numericalRank, result.stageA.conditionNumber);
fprintf(fid, '- 阶段A正则化：%s\n', ...
    upper(result.stageA.regularizationMethod));
if strcmpi(result.stageA.regularizationMethod, 'tikhonov')
    fprintf(fid, '- Tikhonov先验尺度统一倍率：%.8g\n', ...
        result.options.stageATikhonovPriorScale);
elseif strcmpi(result.stageA.regularizationMethod, 'tsvd')
    fprintf(fid, '- TSVD步长模式：%s\n', ...
        result.stageA.tsvdStepMode);
end
fprintf(fid, '- 信息矩阵维数：%d x %d\n', ...
    result.stageA.informationMatrixDimension(1), ...
    result.stageA.informationMatrixDimension(2));
fprintf(fid, '- 待估计参数个数：%d\n', result.stageA.parameterCount);
fprintf(fid, '- 奇异值保留/截断个数：%d/%d\n', ...
    result.stageA.retainedSingularValueCount, ...
    result.stageA.truncatedSingularValueCount);
if ~isempty(fieldnames(result.inletPressureLossDirect))
    fprintf(fid, '- 进气道压损：逐工况方程反算后线性拟合，设计点值=%.12g\n', ...
        result.inletPressureLossDirect.designValue);
end
fprintf(fid, '- 训练NRMS：%.12g -> %.12g\n', ...
    result.baseline.trainingMetrics.overall_nrms, ...
    result.stageAReplay.trainingMetrics.overall_nrms);
if result.input.testDataAvailable
    fprintf(fid, '- 测试NRMS：%.12g -> %.12g\n', ...
        result.baseline.testMetrics.overall_nrms, ...
        result.stageAReplay.testMetrics.overall_nrms);
else
    fprintf(fid, '- 测试集：未在参数辨识入口中读取\n');
end
if result.steadyTestFromTransient.performed
    fprintf(fid, ['- 测试集额外稳态模型NRMS（以对应瞬态收敛解为初值）：' ...
        '%.12g -> %.12g\n'], ...
        result.steadyTestFromTransient.baseline.steadyMetrics.overall_nrms, ...
        result.steadyTestFromTransient.corrected.steadyMetrics.overall_nrms);
    fprintf(fid, '- 额外稳态模型零修正/阶段A回放有效：%d/%d\n', ...
        result.steadyTestFromTransient.baseline.steadyValid, ...
        result.steadyTestFromTransient.corrected.steadyValid);
end
if result.input.testDataAvailable
    fprintf(fid, '- 训练/测试回放有效：%d/%d\n', ...
        result.stageAReplay.trainingValid, result.stageAReplay.testValid);
else
    fprintf(fid, '- 训练回放有效：%d\n', ...
        result.stageAReplay.trainingValid);
end
clear cleanupObject;
end

function route = local_validate_route(route)
route = lower(string(route));
if ~isscalar(route) || ~ismember(route, ["steady", "transient_instant"])
    error('SHT:SteadyAdaptV2:BadRoute', ...
        '模型路径必须为steady或transient_instant。');
end
route = char(route);
end

function options = local_complete_options(options, route)
defaults = local_default_options(route);
names = fieldnames(defaults);
for i = 1:numel(names)
    if ~isfield(options, names{i}) || isempty(options.(names{i}))
        options.(names{i}) = defaults.(names{i});
    end
end
options.route = route;
if ~isscalar(options.inletBoundaryMode) || ...
        ~ismember(options.inletBoundaryMode, [1, 2, 4])
    error('SHT:SteadyAdaptV2:BadInletBoundaryMode', ...
        '正式辨识的options.inletBoundaryMode必须为1、2或4。');
end
if ~islogical(options.stageAOnly) || ~isscalar(options.stageAOnly)
    error('SHT:SteadyAdaptV2:BadStageAOnly', ...
        'options.stageAOnly必须为逻辑标量。');
end
if ~islogical(options.evaluateSteadyTestFromTransient) || ...
        ~isscalar(options.evaluateSteadyTestFromTransient)
    error('SHT:SteadyAdaptV2:BadSteadyTestSwitch', ...
        'options.evaluateSteadyTestFromTransient必须为逻辑标量。');
end
if ~islogical(options.useRobustTransientFallback) || ...
        ~isscalar(options.useRobustTransientFallback)
    error('SHT:SteadyAdaptV2:BadTransientFallbackSwitch', ...
        'options.useRobustTransientFallback必须为逻辑标量。');
end
loadMode = lower(string(options.steadyLoadBoundaryMode));
if ~isscalar(loadMode) || ~ismember(loadMode, ["fixed_power", "torque"])
    error('SHT:SteadyAdaptV2:BadSteadyLoadBoundaryMode', ...
        'options.steadyLoadBoundaryMode必须为fixed_power或torque。');
end
options.steadyLoadBoundaryMode = char(loadMode);
if ~islogical(options.includePt2Residual) || ...
        ~isscalar(options.includePt2Residual)
    error('SHT:SteadyAdaptV2:BadPt2ResidualSwitch', ...
        'options.includePt2Residual必须为逻辑标量。');
end
if ~islogical(options.estimateInletPressureLoss) || ...
        ~isscalar(options.estimateInletPressureLoss)
    error('SHT:SteadyAdaptV2:BadInletEstimateSwitch', ...
        'options.estimateInletPressureLoss必须为逻辑标量。');
end
method = lower(string(options.stageARegularizationMethod));
if ~isscalar(method) || ~ismember(method, ["tsvd", "tikhonov"])
    error('SHT:SteadyAdaptV2:BadStageARegularization', ...
        '阶段A正则化方式必须为tsvd或tikhonov。');
end
options.stageARegularizationMethod = char(method);
if ~isnumeric(options.stageATikhonovPriorScale) || ...
        ~isscalar(options.stageATikhonovPriorScale) || ...
        ~isfinite(options.stageATikhonovPriorScale) || ...
        options.stageATikhonovPriorScale <= 0
    error('SHT:SteadyAdaptV2:BadStageATikhonovPriorScale', ...
        'options.stageATikhonovPriorScale必须为有限正标量。');
end
stageAStepMode = lower(string(options.stageATsvdStepMode));
if ~isscalar(stageAStepMode) || stageAStepMode ~= "direct_inverse"
    error('SHT:SteadyAdaptV2:BadStageATsvdStepMode', ...
        ['options.stageATsvdStepMode只允许direct_inverse。TSVD保留方向' ...
         '必须严格使用1/sigma；若不稳定，应减少保留奇异方向数。']);
end
options.stageATsvdStepMode = char(stageAStepMode);
stageBMethod = lower(string(options.stageBRegularizationMethod));
validStageBMethods = ["tikhonov", "tsvd"];
if ~isscalar(stageBMethod) || ~ismember(stageBMethod, validStageBMethods)
    error('SHT:SteadyAdaptV2:BadStageBRegularization', ...
        '阶段B正则化方式必须为tikhonov或tsvd。');
end
options.stageBRegularizationMethod = char(stageBMethod);
if ~isnumeric(options.stageBTikhonovPriorScale) || ...
        ~isscalar(options.stageBTikhonovPriorScale) || ...
        ~isfinite(options.stageBTikhonovPriorScale) || ...
        options.stageBTikhonovPriorScale <= 0
    error('SHT:SteadyAdaptV2:BadStageBTikhonovPriorScale', ...
        'options.stageBTikhonovPriorScale必须为有限正标量。');
end
if ~isnumeric(options.stageBTsvdRetainedCount) || ...
        ~isscalar(options.stageBTsvdRetainedCount) || ...
        ~isfinite(options.stageBTsvdRetainedCount) || ...
        options.stageBTsvdRetainedCount < 1 || ...
        options.stageBTsvdRetainedCount ~= round(options.stageBTsvdRetainedCount)
    error('SHT:SteadyAdaptV2:BadStageBTsvdRetainedCount', ...
        'options.stageBTsvdRetainedCount必须为正整数。');
end
stageDMethod = lower(string(options.stageDRegularizationMethod));
validStageDMethods = ["tikhonov", "tsvd"];
if ~isscalar(stageDMethod) || ~ismember(stageDMethod, validStageDMethods)
    error('SHT:SteadyAdaptV2:BadStageDRegularization', ...
        '阶段D正则化方式必须为tikhonov或tsvd。');
end
options.stageDRegularizationMethod = char(stageDMethod);
if ~isnumeric(options.stageDTikhonovPriorScale) || ...
        ~isscalar(options.stageDTikhonovPriorScale) || ...
        ~isfinite(options.stageDTikhonovPriorScale) || ...
        options.stageDTikhonovPriorScale <= 0
    error('SHT:SteadyAdaptV2:BadStageDTikhonovPriorScale', ...
        'options.stageDTikhonovPriorScale必须为有限正标量。');
end
if ~isnumeric(options.stageDTsvdRetainedCount) || ...
        ~isscalar(options.stageDTsvdRetainedCount) || ...
        ~isfinite(options.stageDTsvdRetainedCount) || ...
        options.stageDTsvdRetainedCount < 1 || ...
        options.stageDTsvdRetainedCount ~= round(options.stageDTsvdRetainedCount)
    error('SHT:SteadyAdaptV2:BadStageDTsvdRetainedCount', ...
        'options.stageDTsvdRetainedCount必须为正整数。');
end
if ~isnumeric(options.stageDDifferenceStepScale) || ...
        ~isscalar(options.stageDDifferenceStepScale) || ...
        ~isfinite(options.stageDDifferenceStepScale) || ...
        options.stageDDifferenceStepScale <= 0
    error('SHT:SteadyAdaptV2:BadStageDDifferenceStepScale', ...
        'options.stageDDifferenceStepScale必须为有限正标量。');
end
if ~isempty(options.stageDInitialOffset) && ...
        (~isnumeric(options.stageDInitialOffset) || ...
        ~isvector(options.stageDInitialOffset) || ...
        any(~isfinite(options.stageDInitialOffset(:))))
    error('SHT:SteadyAdaptV2:BadStageDInitialOffset', ...
        'options.stageDInitialOffset必须为空或有限数值向量。');
end
logicalOptionNames = {'requireConvergedStages', ...
    'requireValidFinalReplay', 'evaluateTestSet'};
for i = 1:numel(logicalOptionNames)
    name = logicalOptionNames{i};
    if ~islogical(options.(name)) || ~isscalar(options.(name))
        error('SHT:SteadyAdaptV2:BadFormalAcceptanceSwitch', ...
            'options.%s必须为逻辑标量。', name);
    end
end
if ~isnumeric(options.stageATsvdTruncatedCount) || ...
        ~isscalar(options.stageATsvdTruncatedCount) || ...
        ~isfinite(options.stageATsvdTruncatedCount) || ...
        options.stageATsvdTruncatedCount < 0 || ...
        options.stageATsvdTruncatedCount ~= round(options.stageATsvdTruncatedCount)
    error('SHT:SteadyAdaptV2:BadTsvdTruncatedCount', ...
        'options.stageATsvdTruncatedCount必须为非负整数。');
end
if ~isempty(options.stageATsvdRetainedCount) && ...
        (~isnumeric(options.stageATsvdRetainedCount) || ...
        ~isscalar(options.stageATsvdRetainedCount) || ...
        ~isfinite(options.stageATsvdRetainedCount) || ...
        options.stageATsvdRetainedCount < 1 || ...
        options.stageATsvdRetainedCount ~= round(options.stageATsvdRetainedCount))
    error('SHT:SteadyAdaptV2:BadTsvdRetainedCount', ...
        '非空的options.stageATsvdRetainedCount必须为正整数。');
end
if options.inletBoundaryMode == 4
    if options.estimateInletPressureLoss
        error('SHT:SteadyAdaptV2:Mode4InletCompensationConflict', ...
            ['模式4已经根据Pt1/Pt2直接反算进气道压损，' ...
             '不得再把Inlet_K_dP放入联合估计。']);
    end
    if options.includePt2Residual
        error('SHT:SteadyAdaptV2:Mode4Pt2ResidualConflict', ...
            '模式4以实测Pt2作为模型输入，Pt2不得同时作为拟合残差。');
    end
end
options.outputTag = char(string(options.outputTag));
options.pt1TruthFile = char(string(options.pt1TruthFile));
options.trainingFile = local_scalar_text(options.trainingFile, ...
    'options.trainingFile');
options.testFile = local_scalar_text(options.testFile, 'options.testFile');
fuelInputSemantics = lower(string(options.fuelInputSemantics));
if ~isscalar(fuelInputSemantics) || ...
        ~ismember(fuelInputSemantics, ["measured", "physical_model"])
    error('SHT:SteadyAdaptV2:BadFuelInputSemantics', ...
        'options.fuelInputSemantics必须为measured或physical_model。');
end
options.fuelInputSemantics = char(fuelInputSemantics);
end

function value = local_scalar_text(value, name)
value = string(value);
if ~isscalar(value)
    error('SHT:SteadyAdaptV2:BadTextOption', ...
        '%s必须是字符向量或字符串标量。', name);
end
value = char(value);
end

function value = local_optional_test_valid(testAvailable, testValid)
if testAvailable
    value = logical(testValid);
else
    value = NaN;
end
end

function value = local_optional_test_valid_text(testAvailable, testValid)
if testAvailable
    value = sprintf('%d', logical(testValid));
else
    value = '未执行';
end
end

function [retainedCount, truncatedCount, source] = ...
        local_resolve_stage_a_tsvd_count(options, parameterCount)
% 将用户入口的截断个数转换为求解器所需的保留个数。历史入口若显式
% 给出保留个数，则保持兼容，但同一次运行只采用一种口径。
if isempty(options.stageATsvdRetainedCount)
    truncatedCount = options.stageATsvdTruncatedCount;
    retainedCount = parameterCount - truncatedCount;
    source = 'truncated_count';
else
    retainedCount = options.stageATsvdRetainedCount;
    truncatedCount = parameterCount - retainedCount;
    source = 'retained_count_compatibility_override';
end
if retainedCount < 1 || retainedCount > parameterCount || ...
        truncatedCount < 0 || truncatedCount >= parameterCount
    error('SHT:SteadyAdaptV2:BadResolvedTsvdCount', ...
        ['阶段A共有%d个待估参数，TSVD必须至少保留1个方向；' ...
         '当前请求保留/截断=%d/%d。'], ...
        parameterCount, retainedCount, truncatedCount);
end
end

function label = local_route_label(route)
if strcmp(route, 'steady')
    label = '稳态模型路径';
else
    label = '瞬态时刻模型路径';
end
end

function tag = local_route_tag(route)
if strcmp(route, 'steady')
    tag = 'steady';
else
    tag = 'transient_instant';
end
end

function tag = local_result_tag(route, options)
tag = local_route_tag(route);
suffix = lower(strtrim(options.outputTag));
if isempty(suffix)
    return;
end
suffix = regexprep(suffix, '[^a-z0-9_]+', '_');
suffix = regexprep(suffix, '^_+|_+$', '');
if isempty(suffix)
    error('SHT:SteadyAdaptV2:BadOutputTag', ...
        'options.outputTag没有可用的ASCII字母或数字。');
end
tag = [tag '_' suffix];
end

function paths = local_paths(options)
if nargin < 1 || isempty(options)
    options = struct('trainingFile', '', 'testFile', '');
end
thisDir = fileparts(mfilename('fullpath'));
programRoot = fileparts(thisDir);
paths = struct();
paths.tuneDir = thisDir;
paths.middleDataDir = fullfile(thisDir, 'MiddleData');
paths.testDataDir = fullfile(thisDir, 'TestData');
paths.reportOutputDir = fullfile(programRoot, ...
    'report_outputs', 'steady_model_adapt_v2');
paths.trainingFile = fullfile(paths.testDataDir, ...
    'steady_bench_2p4_training_means.xlsx');
paths.testFile = fullfile(paths.testDataDir, ...
    'steady_bench_2p4_test_means.xlsx');
if isfield(options, 'trainingFile') && ~isempty(options.trainingFile)
    paths.trainingFile = sht_resolve_delivery_input_file( ...
        options.trainingFile, paths.trainingFile);
end
if isfield(options, 'testFile') && ~isempty(options.testFile)
    paths.testFile = sht_resolve_delivery_input_file( ...
        options.testFile, paths.testFile);
end
dirs = {paths.middleDataDir, paths.reportOutputDir};
for i = 1:numel(dirs)
    if ~exist(dirs{i}, 'dir')
        mkdir(dirs{i});
    end
end
end

function [trainingData, testData] = local_read_input_tables(paths, options)
if ~exist(paths.trainingFile, 'file')
    error('SHT:SteadyAdaptV2:MissingTrainingData', ...
        '训练集不存在：%s。', paths.trainingFile);
end
trainingData = local_read_table(paths.trainingFile);
local_validate_input_table(trainingData, '训练集');
if options.evaluateTestSet
    if ~exist(paths.testFile, 'file')
        error('SHT:SteadyAdaptV2:MissingTestData', ...
            '已要求嵌入测试评价，但测试集不存在：%s。', paths.testFile);
    end
    testData = local_read_table(paths.testFile);
    local_validate_input_table(testData, '测试集');
else
    % 保留同一表结构，使历史结果组织和专项研究接口继续可用；零行测试表
    % 不参与任何参数估计、指标计算或正式验收。
    testData = trainingData([], :);
end
end

function tbl = local_read_measurement_table(filePath, label)
if nargin < 2 || isempty(label)
    label = '测量数据';
end
filePath = char(string(filePath));
if exist(filePath, 'file') ~= 2
    error('SHT:SteadyAdaptV2:MissingMeasurementData', ...
        '%s文件不存在：%s。', label, filePath);
end
tbl = local_read_table(filePath);
local_validate_input_table(tbl, label);
end

function [trainingData, testData, meta] = local_attach_pt1_truth( ...
        trainingData, testData, paths, options)
% 模式1仅用于受控对照：Excel仍保持真实可测字段，Pt1从与
% 当前Excel工况编号一致的替代数据MAT中按point_id严格匹配。
if isempty(options.pt1TruthFile)
    sourceDir = fullfile(paths.testDataDir, 'test_data_generation');
    candidates = dir(fullfile(sourceDir, 'steady_bench_substitute_*.mat'));
    [~, order] = sort([candidates.datenum], 'descend');
    candidates = candidates(order);
    candidateFiles = strings(numel(candidates), 1);
    for i = 1:numel(candidates)
        candidateFiles(i) = string(fullfile( ...
            candidates(i).folder, candidates(i).name));
    end
else
    candidateFiles = string(options.pt1TruthFile);
end
if isempty(candidateFiles)
    error('SHT:SteadyAdaptV2:MissingPt1TruthFile', ...
        '没有找到steady_bench_substitute_*.mat，无法获取Pt1真值。');
end

allData = [trainingData; testData];
selectedFile = "";
selectedPt1 = [];
lastReason = "";
for i = 1:numel(candidateFiles)
    filePath = candidateFiles(i);
    if ~isfile(filePath)
        lastReason = "文件不存在";
        continue;
    end
    source = load(char(filePath), 'dataTable');
    if ~isfield(source, 'dataTable') || ~istable(source.dataTable)
        lastReason = "缺少dataTable";
        continue;
    end
    sourceTable = source.dataTable;
    required = {'point_id','model_Pt1','Np','Ng','Wf','Tt1'};
    if ~all(ismember(required, sourceTable.Properties.VariableNames))
        lastReason = "dataTable缺少必要字段";
        continue;
    end
    sourceId = string(sourceTable.point_id);
    if numel(unique(sourceId)) ~= numel(sourceId)
        lastReason = "point_id不唯一";
        continue;
    end
    [matched, location] = ismember(allData.point_id, sourceId);
    if ~all(matched)
        lastReason = "point_id与Excel不完整匹配";
        continue;
    end
    % 用三个独立测量量防止误读到同编号的历史数据。
    sourceCheck = [sourceTable.Np(location), sourceTable.Ng(location), ...
        sourceTable.Tt1(location)];
    excelCheck = [allData.Np_mean, allData.Ng_mean, allData.Tt1_mean];
    tolerance = 1e-9 + 1e-9 * max(abs(excelCheck), 1);
    if any(abs(sourceCheck - excelCheck) > tolerance, 'all')
        lastReason = "测量均值与Excel不一致";
        continue;
    end
    pt1 = sourceTable.model_Pt1(location);
    if ~isnumeric(pt1) || any(~isfinite(pt1) | pt1 <= 0)
        lastReason = "model_Pt1不是有限正值";
        continue;
    end
    selectedFile = filePath;
    selectedPt1 = pt1(:);
    break;
end
if strlength(selectedFile) == 0
    error('SHT:SteadyAdaptV2:NoMatchingPt1TruthFile', ...
        '未找到与当前Excel严格一致的Pt1真值数据：%s。', lastReason);
end

nTraining = height(trainingData);
trainingData.Pt1_truth = selectedPt1(1:nTraining);
testData.Pt1_truth = selectedPt1((nTraining + 1):end);
meta = struct('used', true, 'sourceFile', selectedFile, ...
    'sourceColumn', "dataTable.model_Pt1", ...
    'pointCount', numel(selectedPt1));
end

function tbl = local_read_table(filePath)
try
    tbl = readtable(filePath, 'FileType', 'spreadsheet', 'TextType', 'string');
catch
    tbl = readtable(filePath, 'FileType', 'spreadsheet');
end
tbl.point_id = string(tbl.point_id);
end

function local_validate_input_table(tbl, label)
required = {'point_id','Np_mean','Ng_mean','Wf_mean','Tt45_mean', ...
    'Pt45_mean','Mkp_mean','Mkg_mean','Pt2_mean','Tt1_mean', ...
    'Pt3_mean','Tt3_mean','Pamb_mean','Tamb_mean', ...
    'Altitude_mean','Mach_mean'};
missing = setdiff(required, tbl.Properties.VariableNames);
if ~isempty(missing)
    error('SHT:SteadyAdaptV2:BadInputSchema', ...
        '%s缺少字段：%s。', label, strjoin(missing, ', '));
end
if height(tbl) < 1
    error('SHT:SteadyAdaptV2:EmptyInput', '%s没有工况点。', label);
end
numericFields = setdiff(required, {'point_id'});
for i = 1:numel(numericFields)
    value = tbl.(numericFields{i});
    if ~isnumeric(value) || any(~isfinite(value))
        error('SHT:SteadyAdaptV2:BadInputValue', ...
            '%s字段%s必须全部为有限数值。', label, numericFields{i});
    end
end
if numel(unique(tbl.point_id)) ~= height(tbl)
    error('SHT:SteadyAdaptV2:DuplicatePointId', ...
        '%s的point_id存在重复。', label);
end
end

function parameters = local_parameter_definition(options)
cIndex = [0; 1; 2; 6; 7; 8; 10; 11; 12; 14; 15];
name = ["Inlet_K_dP"; "HPC_K_W"; "HPC_K_eta"; ...
    "Burner_K_dP"; "GT_K_W"; "GT_K_eta"; ...
    "GT_PT_Duct_K_dP"; "PT_K_W"; "PT_K_eta"; ...
    "PT_Nozzle_Duct_K_dP"; "Nozzle_K_A8"];
axisName = ["inlet_corrected_mass_flow"; "ac_corrected_speed"; ...
    "ac_corrected_speed"; "burner_inlet_corrected_mass_flow"; ...
    "gt_total_pressure_ratio"; "gt_total_pressure_ratio"; ...
    "gt_pt_duct_corrected_mass_flow"; "pt_total_pressure_ratio"; ...
    "pt_total_pressure_ratio"; "pt_nozzle_duct_corrected_mass_flow"; ...
    "constant"];
axisType = [1; 5; 5; 2; 7; 7; 3; 8; 8; 4; 0];
scheduled = axisType ~= 0;
pressureLoss = ismember(cIndex, [0, 6, 10, 14]);
lowerBound = [-0.02; -0.08; -0.08; -0.08; -0.10; -0.10; ...
    -0.08; -0.10; -0.10; -0.08; -0.10];
upperBound = [0.15; 0.08; 0.08; 0.04; 0.10; 0.10; ...
    0.10; 0.10; 0.10; 0.10; 0.10];
% 阶段A使用零中心、参数专用的工程先验尺度。该尺度与本轮总体部件
% 修正量级相当，使真值通常位于约1~2个先验标准差内，同时抑制多个
% 弱可辨识参数通过大幅反向变化共同拟合同一组测量输出。
priorSigmaGlobal = [0.012; 0.015; 0.015; 0.012; 0.018; 0.018; ...
    0.012; 0.018; 0.018; 0.012; 0.020];
priorSigmaGroup = [0.018; 0.015; 0.015; 0.015; 0.018; 0.018; ...
    0.015; 0.018; 0.018; 0.015; 0.018];
finiteDifferenceStep = 5e-4 * ones(numel(cIndex), 1);
parameters = table(cIndex, cIndex + 1, name, scheduled, pressureLoss, ...
    axisName, axisType, lowerBound, upperBound, priorSigmaGlobal, ...
    priorSigmaGroup, finiteDifferenceStep, ...
    'VariableNames', {'c_index','matlab_index','name','scheduled', ...
    'pressure_loss','axis_name','axis_type','lower_bound','upper_bound', ...
    'prior_sigma_global','prior_sigma_group','difference_step'});
if ~options.estimateInletPressureLoss
    parameters(parameters.c_index == 0, :) = [];
end
end

function scales = local_residual_scales(route, cfg, data, options)
if strcmp(route, 'steady')
    names = ["Np","Ng","Pt2","Pt3","Tt3","Tt45","Pt45"];
    value = [max(0.003 * max(abs(data.Np_mean)), 30); ...
        max(0.003 * max(abs(data.Ng_mean)), 50); ...
        max(0.0005 * max(abs(data.Pt2_mean)), 50); ...
        max(0.005 * max(abs(data.Pt3_mean)), 1000); ...
        max(0.005 * max(abs(data.Tt3_mean)), 1); ...
        max(0.005 * max(abs(data.Tt45_mean)), 1); ...
        max(0.005 * max(abs(data.Pt45_mean)), 500)];
else
    names = ["Pt2","Pt3","Tt3","Tt45","Pt45","dNp_dt","dNg_dt"];
    value = [max(0.0005 * max(abs(data.Pt2_mean)), 50); ...
        max(0.005 * max(abs(data.Pt3_mean)), 1000); ...
        max(0.005 * max(abs(data.Tt3_mean)), 1); ...
        max(0.005 * max(abs(data.Tt45_mean)), 1); ...
        max(0.005 * max(abs(data.Pt45_mean)), 500); ...
        max(0.001 * cfg.engine.initial.Np0, 10); ...
        max(0.001 * cfg.engine.initial.Ng0, 20)];
end
if ~options.includePt2Residual
    keep = names ~= "Pt2";
    names = names(keep);
    value = value(keep);
end
names = names(:);
value = value(:);
scales = table(names, value, 'VariableNames', {'name','scale'});
end

function model = local_constant_model(parameters, thetaHealth, fuelBias)
model = struct();
model.kind = 'constant';
model.health = zeros(159, 1);
for i = 1:height(parameters)
    model.health(parameters.matlab_index(i)) = thetaHealth(i);
end
model.fuelBias = fuelBias;
model.schedule = [];
end

function model = local_schedule_model(schedule)
model = struct('kind', 'schedule', 'health', schedule.designHealth, ...
    'fuelBias', NaN, 'schedule', schedule);
end

function [lower, upper, priorSigma, diffStep] = ...
        local_constant_parameter_settings(parameters, wfDesign, stage)
lower = [parameters.lower_bound; -0.02 * wfDesign];
upper = [parameters.upper_bound; 0.02 * wfDesign];
if strcmp(stage, 'global')
    % 燃油偏置真值约为设计点燃油的0.3%，采用同量级零中心先验。
    priorSigma = [parameters.prior_sigma_global; 0.003 * wfDesign];
else
    priorSigma = [parameters.prior_sigma_group; 0.0025 * wfDesign];
end
diffStep = [parameters.difference_step; max(2e-6, 1e-4 * wfDesign)];
end

function [lower, upper, priorSigma, diffStep] = ...
        local_refine_parameter_settings(schedule, parameters, wfDesign)
n = height(parameters) + 1;
lower = -inf(n, 1);
upper = inf(n, 1);
priorSigma = [0.010 * ones(height(parameters), 1); 0.0015 * wfDesign];
diffStep = [2e-4 * ones(height(parameters), 1); max(1e-6, 5e-5 * wfDesign)];
for i = 1:height(parameters)
    if parameters.scheduled(i)
        entry = schedule.healthEntries([schedule.healthEntries.cIndex] == ...
            parameters.c_index(i));
        active = true(size(entry.kNodes));
        if entry.pressureLoss
            active(1) = false;
        end
        values = entry.kNodes(active);
    else
        values = schedule.h15;
    end
    lower(i) = max(-0.025, parameters.lower_bound(i) - min(values));
    upper(i) = min(0.025, parameters.upper_bound(i) - max(values));
end
fuelValues = schedule.fuelBias.biasNodes;
lower(end) = max(-0.004 * wfDesign, -0.02 * wfDesign - min(fuelValues));
upper(end) = min(0.004 * wfDesign, 0.02 * wfDesign - max(fuelValues));
end

function [residual, meta] = local_constant_objective( ...
        x, route, engine, cfg, data, parameters, scales, ...
        priorCenter, priorSigma, options, regularizationMethod)
model = local_constant_model(parameters, x(1:height(parameters)), x(end));
[prediction, valid] = local_evaluate_dataset( ...
    route, engine, cfg, data, model, options);
dataResidual = local_data_residual(route, data, prediction, scales);
if ~valid || any(~isfinite(dataResidual))
    dataResidual = local_penalty_residual(numel(dataResidual));
end
regularization = (x(:) - priorCenter(:)) ./ priorSigma(:);
if strcmpi(regularizationMethod, 'tikhonov')
    residual = [dataResidual; regularization];
else
    % TSVD直接作用于数据雅可比。弱奇异方向被截断后保持在当前值，
    % 不再通过附加伪观测行改变数据残差的奇异谱。
    residual = dataResidual;
end
meta = struct('valid', valid, 'prediction', prediction, ...
    'dataResidual', dataResidual, 'regularization', regularization, ...
    'regularizationMethod', char(regularizationMethod));
end

function [residual, meta] = local_schedule_objective( ...
        offset, baseSchedule, route, engine, cfg, data, ...
        parameters, scales, priorSigma, options, regularizationMethod)
schedule = local_apply_schedule_offsets(baseSchedule, offset, parameters);
model = local_schedule_model(schedule);
[prediction, valid] = local_evaluate_dataset( ...
    route, engine, cfg, data, model, options);
dataResidual = local_data_residual(route, data, prediction, scales);
if ~valid || any(~isfinite(dataResidual))
    dataResidual = local_penalty_residual(numel(dataResidual));
end
regularization = offset(:) ./ priorSigma(:);
if strcmpi(regularizationMethod, 'tikhonov')
    residual = [dataResidual; regularization];
else
    residual = dataResidual;
end
meta = struct('valid', valid, 'prediction', prediction, ...
    'dataResidual', dataResidual, 'regularization', regularization, ...
    'regularizationMethod', char(regularizationMethod), ...
    'schedule', schedule);
end

function residual = local_penalty_residual(n)
residual = 1e3 * ones(n, 1);
end

function solve = local_bounded_lm( ...
        objective, x0, lower, upper, diffStep, maxIteration, options, label, ...
        regularizationMethod, parameterScale, retainedCountRequested, ...
        useDirectTsvdInverse)
% 有界高斯-牛顿。Tikhonov使用增广残差；TSVD在参数尺度归一化
% 的数据雅可比上截断弱奇异方向。候选步均必须使对应目标代价下降。
x = min(max(x0(:), lower(:)), upper(:));
% 本函数已有名为lower的边界向量，不能调用同名MATLAB函数。
% 入口校验已经把方法名规范为小写，这里只做字符类型统一。
regularizationMethod = char(string(regularizationMethod));
isTsvd = strcmp(regularizationMethod, 'tsvd');
if ~islogical(useDirectTsvdInverse) || ...
        ~isscalar(useDirectTsvdInverse)
    error('SHT:SteadyAdaptV2:BadDirectTsvdSwitch', ...
        '%s的TSVD直接伪逆开关必须为逻辑标量。', label);
end
useDirectTsvdInverse = isTsvd && useDirectTsvdInverse;
if isTsvd && ~useDirectTsvdInverse
    error('SHT:SteadyAdaptV2:DampedTsvdForbidden', ...
        ['%s请求了非严格伪逆TSVD。当前工程禁止阻尼TSVD；' ...
         '请改用direct_inverse并在必要时减少保留奇异方向数。'], label);
end
parameterScale = parameterScale(:);
if numel(parameterScale) ~= numel(x) || ...
        any(~isfinite(parameterScale) | parameterScale <= 0)
    error('SHT:SteadyAdaptV2:BadParameterScale', ...
        '%s的参数尺度必须与待估参数等长且均为有限正值。', label);
end
[r, meta] = objective(x);
if any(~isfinite(r)) || ~meta.valid
    error('SHT:SteadyAdaptV2:InitialObjectiveInvalid', ...
        '%s初始参数不能完成全部参与工况的合法模型回放。', label);
end
cost = 0.5 * (r' * r);
costInitial = cost;
initialX = x;
initialResidual = r;
initialMeta = meta;
initialJ = [];
initialDataJ = [];
lambda = options.initialLambda;
history = repmat(local_empty_iteration_record(), maxIteration, 1);
lastRetainedCount = numel(x);
stopReason = "max_iteration";
converged = false;

for iteration = 1:maxIteration
    J = local_finite_difference_jacobian( ...
        objective, x, r, lower, upper, diffStep);
    if iteration == 1
        % 保存进入本阶段、尚未接受任何参数更新时的数据雅可比。阶段A
        % 的该快照就是零修正基准模型，可供后续与阶段D最终个体模型
        % 使用同一尺度开展局部可辨识性对比。这里只复用求解器本来就
        % 要计算的首次雅可比，不增加DLL差分回放。
        initialJ = J;
        initialDataResidualCount = numel(initialMeta.dataResidual);
        initialDataJ = initialJ(1:initialDataResidualCount, :);
    end
    if isTsvd
        % z=D^{-1}*Delta_x，Jz=J*D。D采用工程先验尺度，仅用于
        % 消除不同参数单位和量级的影响，不作为高斯先验惩罚项。
        scaledJ = J .* parameterScale.';
        [u, sMatrix, v] = svd(scaledJ, 'econ');
        singularValueIteration = diag(sMatrix);
        if isempty(singularValueIteration)
            numericalRankIteration = 0;
        else
            rankThreshold = max(size(scaledJ)) * ...
                eps(max(singularValueIteration));
            numericalRankIteration = sum( ...
                singularValueIteration > rankThreshold);
        end
        retainedCount = min([retainedCountRequested, ...
            numericalRankIteration, numel(singularValueIteration)]);
        if retainedCount < 1
            error('SHT:SteadyAdaptV2:ZeroTsvdRank', ...
                '%s的数据雅可比没有可保留的数值奇异方向。', label);
        end
        retainedSingularValue = singularValueIteration(1:retainedCount);
        % 纯TSVD伪逆：保留方向使用1/sigma，未保留方向不进入求和，
        % 因而其更新严格为零。数值零奇异值已由rankThreshold排除；
        % 此处不允许增加阻尼或其他隐式滤波。
        filterFactor = 1 ./ retainedSingularValue;
        stepScaled = -v(:, 1:retainedCount) * ...
            (filterFactor .* (u(:, 1:retainedCount)' * r));
        step = parameterScale .* stepScaled;
        lastRetainedCount = retainedCount;
    else
        gradient = J' * r;
        curvature = J' * J;
        diagonal = max(diag(curvature), 1);
        step = -(curvature + lambda * diag(diagonal)) \ gradient;
        lastRetainedCount = min(numel(x), rank(J));
    end
    normalizedStep = norm(step ./ max(upper - lower, eps));
    directionalDerivative = r' * (J * step);

    % 小步长本身就是既定收敛条件，必须在线搜索之前检查。如果将该判断
    % 放到候选步被接受之后，那么位于数值驻点附近的无阻尼TSVD会因为
    % 没有更低代价候选而被误报为no_acceptable_step。
    if normalizedStep < options.stepRelativeTolerance
        history(iteration).iteration = iteration;
        history(iteration).cost_before = cost;
        history(iteration).cost_after = cost;
        history(iteration).cost_relative_change = 0;
        history(iteration).lambda = lambda;
        history(iteration).alpha = 0;
        history(iteration).step_relative_norm = normalizedStep;
        history(iteration).proposed_step_relative_norm = normalizedStep;
        history(iteration).directional_derivative = directionalDerivative;
        history(iteration).accepted = false;
        history(iteration).stop_reason = "parameter_step_small";
        converged = true;
        stopReason = "parameter_step_small";
        break;
    end

    accepted = false;
    trialCost = cost;
    trialX = x;
    trialR = r;
    trialMeta = meta;
    alphaUsed = 0;
    bestValidTrialCost = Inf;
    for alpha = [1, 0.5, 0.25, 0.125, 0.0625, 0.03125, 0.015625]
        candidate = min(max(x + alpha * step, lower), upper);
        [candidateR, candidateMeta] = objective(candidate);
        candidateCost = 0.5 * (candidateR' * candidateR);
        if all(isfinite(candidateR)) && candidateMeta.valid
            bestValidTrialCost = min(bestValidTrialCost, candidateCost);
        end
        if all(isfinite(candidateR)) && candidateMeta.valid && ...
                candidateCost < cost
            accepted = true;
            trialCost = candidateCost;
            trialX = candidate;
            trialR = candidateR;
            trialMeta = candidateMeta;
            alphaUsed = alpha;
            break;
        end
    end

    history(iteration).iteration = iteration;
    history(iteration).cost_before = cost;
    history(iteration).cost_after = trialCost;
    history(iteration).lambda = lambda;
    history(iteration).alpha = alphaUsed;
    history(iteration).proposed_step_relative_norm = normalizedStep;
    history(iteration).step_relative_norm = alphaUsed * normalizedStep;
    history(iteration).directional_derivative = directionalDerivative;
    if isfinite(bestValidTrialCost)
        history(iteration).best_trial_relative_change = ...
            (bestValidTrialCost - cost) / max(cost, eps);
    end
    history(iteration).accepted = accepted;

    if ~accepted
        if isTsvd
            % 无阻尼TSVD没有lambda可继续增大。若此前已经接受过下降步，
            % 且当前方向的全部有效线搜索候选都不低于现有代价，则表示
            % 在本轮保留奇异子空间内已无进一步下降，而不是求解失败。
            % 独立训练/测试回放有效性仍由上层正式门控单独检查。
            priorAccepted = iteration > 1 && ...
                any([history(1:(iteration - 1)).accepted]);
            noFurtherDecrease = isfinite(bestValidTrialCost) && ...
                bestValidTrialCost >= cost;
            if priorAccepted && noFurtherDecrease
                converged = true;
                stopReason = "no_further_cost_decrease";
            else
                stopReason = "no_acceptable_step";
            end
            history(iteration).stop_reason = stopReason;
            break;
        end
        history(iteration).stop_reason = "step_rejected";
        lambda = min(lambda * 10, 1e12);
        if lambda >= 1e10
            stopReason = "no_acceptable_step";
            break;
        end
        continue;
    end

    relativeCostChange = abs(cost - trialCost) / max(cost, eps);
    x = trialX;
    r = trialR;
    meta = trialMeta;
    cost = trialCost;
    if ~isTsvd
        lambda = max(lambda / 3, 1e-10);
    end
    history(iteration).cost_relative_change = relativeCostChange;
    if alphaUsed * normalizedStep < options.stepRelativeTolerance
        converged = true;
        stopReason = "accepted_step_small";
        history(iteration).stop_reason = stopReason;
        break;
    end
    if relativeCostChange < options.costRelativeTolerance
        converged = true;
        stopReason = "cost_change_small";
        history(iteration).stop_reason = stopReason;
        break;
    end
end

iterationCount = iteration;
history = struct2table(history(1:iterationCount));

% 保存结果中的雅可比必须对应最终参数，而不是最后一次已接受步之前的
% 参数。该重算同时为后续工程可辨识性分析提供不含先验伪观测的数据
% 雅可比；它会增加一次n参数差分，但避免使用过时灵敏度得出错误结论。
finalJ = local_finite_difference_jacobian( ...
    objective, x, r, lower, upper, diffStep);
lastJ = finalJ;
dataResidualCount = numel(meta.dataResidual);
dataJ = finalJ(1:dataResidualCount, :);
scaledDataJ = dataJ .* parameterScale.';
if isTsvd
    lastScaledJ = scaledDataJ;
else
    lastScaledJ = finalJ;
end
singularValues = svd(lastScaledJ, 'econ');
if isempty(singularValues)
    numericalRank = 0;
    conditionNumber = Inf;
else
    threshold = max(size(lastJ)) * eps(max(singularValues));
    numericalRank = sum(singularValues > threshold);
    if numericalRank >= 1
        conditionNumber = singularValues(1) / singularValues(numericalRank);
    else
        conditionNumber = Inf;
    end
end

solve = struct();
solve.label = label;
solve.x = x;
solve.initialX = initialX;
solve.initialResidual = initialResidual;
solve.initialDataResidual = initialMeta.dataResidual;
solve.initialJacobian = initialJ;
solve.initialDataJacobian = initialDataJ;
solve.converged = converged;
solve.stopReason = stopReason;
solve.iterationCount = iterationCount;
solve.costInitial = costInitial;
solve.costFinal = cost;
solve.residual = r;
solve.meta = meta;
solve.jacobian = lastJ;
solve.scaledJacobian = lastScaledJ;
solve.dataJacobian = dataJ;
solve.scaledDataJacobian = scaledDataJ;
solve.singularValues = singularValues;
solve.numericalRank = numericalRank;
solve.conditionNumber = conditionNumber;
solve.regularizationMethod = regularizationMethod;
if isTsvd
    solve.tsvdStepMode = 'direct_inverse';
else
    solve.tsvdStepMode = 'not_applicable';
end
solve.parameterScale = parameterScale;
solve.parameterCount = numel(x);
solve.dataResidualCount = dataResidualCount;
solve.lowerBound = lower(:);
solve.upperBound = upper(:);
solve.differenceStep = diffStep(:);
solve.informationMatrixDimension = [numel(x), numel(x)];
solve.requestedRetainedSingularValueCount = retainedCountRequested;
if isTsvd
    solve.retainedSingularValueCount = min(lastRetainedCount, numericalRank);
else
    solve.retainedSingularValueCount = numericalRank;
end
solve.truncatedSingularValueCount = max(0, ...
    numel(x) - solve.retainedSingularValueCount);
if solve.retainedSingularValueCount >= 1
    solve.retainedConditionNumber = singularValues(1) / ...
        singularValues(solve.retainedSingularValueCount);
else
    solve.retainedConditionNumber = Inf;
end
solve.history = history;
dataSingularValues = svd(scaledDataJ, 'econ');
solve.dataSingularValues = dataSingularValues;
if isempty(dataSingularValues)
    solve.dataNumericalRank = 0;
    solve.dataConditionNumber = Inf;
else
    dataRankThreshold = max(size(scaledDataJ)) * ...
        eps(max(dataSingularValues));
    solve.dataNumericalRank = sum(dataSingularValues > dataRankThreshold);
    if solve.dataNumericalRank >= 1
        solve.dataConditionNumber = dataSingularValues(1) / ...
            dataSingularValues(solve.dataNumericalRank);
    else
        solve.dataConditionNumber = Inf;
    end
end
end

function J = local_finite_difference_jacobian( ...
        objective, x, residual, lower, upper, diffStep)
%LOCAL_FINITE_DIFFERENCE_JACOBIAN 优先前向差分，无效时反向回退。
% 不能把模型无效时返回的有限惩罚向量当作真实输出，否则雅可比会出现
% 人工巨大列，并直接污染奇异值、TSVD方向和可辨识性判断。
J = zeros(numel(residual), numel(x));
for j = 1:numel(x)
    direction = [1, -1];
    if x(j) + diffStep(j) > upper(j)
        direction = [-1, 1];
    end
    derivativeAvailable = false;
    for stepScale = [1, 0.5, 0.25, 0.125, 0.0625]
        for signValue = direction
            xp = x;
            xp(j) = min(max(x(j) + ...
                signValue * stepScale * diffStep(j), ...
                lower(j)), upper(j));
            actualStep = xp(j) - x(j);
            if actualStep == 0
                continue;
            end
            [rp, perturbedMeta] = objective(xp);
            if perturbedMeta.valid && all(isfinite(rp))
                J(:, j) = (rp - residual) / actualStep;
                derivativeAvailable = true;
                break;
            end
        end
        if derivativeAvailable
            break;
        end
    end
    if ~derivativeAvailable
        error('SHT:SteadyAdaptV2:FiniteDifferenceUnavailable', ...
            ['参数%d在正、反两个差分方向均不能完成合法模型回放；' ...
             '请减小差分步长或检查参数边界。'], j);
    end
end
end

function solve = local_annotate_stage_b_solve( ...
        solve, priorCenter, parameterScale, method)
% 统一阶段B方法的诊断字段，便于同一对比程序直接汇总。
priorCenter = priorCenter(:);
parameterScale = parameterScale(:);
scaledDisplacement = (solve.x(:) - priorCenter) ./ parameterScale;
solve.stageBMethod = char(method);
solve.priorCenter = priorCenter;
solve.scaledPriorDisplacement = scaledDisplacement;
solve.scaledPriorDisplacementNorm = norm(scaledDisplacement);
solve.maxAbsScaledPriorDisplacement = max(abs(scaledDisplacement));
solve.dataCostFinal = 0.5 * sum(solve.meta.dataResidual(:) .^ 2);
solve.priorPenaltyCostFinal = ...
    0.5 * sum(solve.meta.regularization(:) .^ 2);
if ~isfield(solve, 'discardedSubspaceDisplacementNorm')
    solve.discardedSubspaceDisplacementNorm = NaN;
end
end

function record = local_empty_iteration_record()
record = struct('iteration', NaN, 'cost_before', NaN, ...
    'cost_after', NaN, 'cost_relative_change', NaN, ...
    'lambda', NaN, 'alpha', NaN, 'step_relative_norm', NaN, ...
    'proposed_step_relative_norm', NaN, ...
    'directional_derivative', NaN, ...
    'best_trial_relative_change', NaN, ...
    'accepted', false, 'stop_reason', "");
end

function group = local_empty_group_result()
group = struct('group_id', "", 'point_ids', "", ...
    'row_indices', [], 'x', [], 'solve', struct());
end

function correctedSpeed = local_measured_ac_corrected_speed(data, cfg)
% AC与CC由高压轴共同驱动。以设计点Ng0和288.15 K为基准，将实测
% 高压轴转速按实测Tt1换算，可得到不依赖模型回放路径的分组坐标。
if any(~isfinite(data.Ng_mean) | data.Ng_mean <= 0) || ...
        any(~isfinite(data.Tt1_mean) | data.Tt1_mean <= 0)
    error('SHT:SteadyAdaptV2:BadMeasuredAcSpeedInput', ...
        '构造AC相对换算转速需要有限正值Ng_mean和Tt1_mean。');
end
correctedSpeed = (data.Ng_mean ./ cfg.engine.initial.Ng0) .* ...
    sqrt(288.15 ./ data.Tt1_mean);
end

function groups = local_cluster_by_ac_speed(data, correctedSpeed, spanLimit)
correctedSpeed = correctedSpeed(:);
if numel(correctedSpeed) ~= height(data) || ...
        any(~isfinite(correctedSpeed))
    error('SHT:SteadyAdaptV2:BadClusterCoordinate', ...
        'AC相对换算转速分组坐标必须与训练工况等长且全部有限。');
end
[sortedSpeed, order] = sort(correctedSpeed);
clusterMembers = {};
startIndex = 1;
for i = 2:numel(order)
    if sortedSpeed(i) - sortedSpeed(startIndex) > spanLimit
        clusterMembers{end + 1, 1} = order(startIndex:(i - 1)); %#ok<AGROW>
        startIndex = i;
    end
end
clusterMembers{end + 1, 1} = order(startIndex:end);

record = repmat(struct('group_id', "", 'point_ids', "", ...
    'point_count', NaN, 'ac_ncr_mean', NaN, 'ac_ncr_min', NaN, ...
    'ac_ncr_max', NaN, 'row_indices', []), numel(clusterMembers), 1);
for i = 1:numel(clusterMembers)
    idx = clusterMembers{i}(:);
    speed = correctedSpeed(idx);
    record(i).group_id = string(sprintf('G%02d', i));
    record(i).point_ids = strjoin(data.point_id(idx), ',');
    record(i).point_count = numel(idx);
    record(i).ac_ncr_mean = mean(speed);
    record(i).ac_ncr_min = min(speed);
    record(i).ac_ncr_max = max(speed);
    record(i).row_indices = idx;
end
groups = struct2table(record);
groups.coordinate_source(:) = "measured_Ng_Tt1";
end

function idx = local_group_row_indices(groups, groupIndex)
%LOCAL_GROUP_ROW_INDICES 兼容struct2table对等长数组的自动展开行为。
% 各组成员数不同时，row_indices是元胞列；全部组恰好都是单点组
% （或等长组）时，MATLAB会将其压缩成数值列或矩阵。两种表示均
% 恢复为同一个列向量下标，避免聚类结果改变时触发类型错误。
value = groups.row_indices;
if iscell(value)
    idx = value{groupIndex};
else
    idx = value(groupIndex, :);
end
idx = idx(:);
idx = idx(isfinite(idx) & idx >= 1 & idx == round(idx));
if isempty(idx)
    error('SHT:SteadyAdaptV2:EmptyGroupRows', ...
        '聚类组%d没有合法的训练工况行号。', groupIndex);
end
end

function schedule = local_build_schedule( ...
        data, baselinePrediction, groups, groupResults, ...
        parameters, wfDesign, options)
groupTheta = zeros(numel(groupResults), numel(groupResults(1).x));
for groupIndex = 1:numel(groupResults)
    groupTheta(groupIndex, :) = groupResults(groupIndex).x(:).';
end
[~, designRow] = max(data.Wf_mean);
entries = repmat(local_empty_schedule_entry(), ...
    sum(parameters.scheduled), 1);
entryCounter = 0;
for p = 1:height(parameters)
    if ~parameters.scheduled(p)
        continue;
    end
    entryCounter = entryCounter + 1;
    axisField = char(parameters.axis_name(p));
    xGroup = zeros(height(groups), 1);
    kGroup = groupTheta(:, p);
    for g = 1:height(groups)
        idx = local_group_row_indices(groups, g);
        xGroup(g) = mean(baselinePrediction.(axisField)(idx));
    end
    [xGroup, kGroup, mergeCount] = local_merge_near_nodes( ...
        xGroup, kGroup, options);
    pressureLoss = parameters.pressure_loss(p);
    if pressureLoss
        xCanonical = [0; xGroup(:)];
        kCanonical = [0; kGroup(:)];
    else
        xCanonical = xGroup(:);
        kCanonical = kGroup(:);
    end
    entry = local_empty_schedule_entry();
    entry.cIndex = parameters.c_index(p);
    entry.name = char(parameters.name(p));
    entry.axisName = axisField;
    entry.axisType = parameters.axis_type(p);
    entry.pressureLoss = pressureLoss;
    entry.xNodes = xCanonical;
    entry.kNodes = kCanonical;
    entry.designCoordinate = baselinePrediction.(axisField)(designRow);
    entry.lowerBound = parameters.lower_bound(p);
    entry.upperBound = parameters.upper_bound(p);
    entry.mergedNodeCount = mergeCount;
    entry = local_refresh_schedule_entry(entry);
    entries(entryCounter) = entry;
end

xFuel = zeros(height(groups), 1);
kFuel = groupTheta(:, end);
for g = 1:height(groups)
    idx = local_group_row_indices(groups, g);
    xFuel(g) = mean(data.Wf_mean(idx) / wfDesign);
end
[xFuel, kFuel, fuelMergeCount] = local_merge_near_nodes( ...
    xFuel, kFuel, options);

schedule = struct();
schedule.schemaVersion = 'SHT_ESTIMATED_SCHEDULE_V1_EFFECTIVE_NODES';
schedule.interpolation = 'linear';
schedule.extrapolation = 'nearest_endpoint';
schedule.healthEntries = entries;
schedule.h15 = mean(groupTheta(:, find(parameters.c_index == 15, 1)));
schedule.fuelBias = struct('axisName', 'measured_wf_ratio', ...
    'xNodes', xFuel(:), 'biasNodes', kFuel(:), ...
    'mergedNodeCount', fuelMergeCount, 'wfDesign', wfDesign);
schedule.groupCount = height(groups);
schedule.designPointId = data.point_id(designRow);
schedule.designHealth = local_schedule_design_health(schedule);
end

function direct = local_build_direct_inlet_pressure_loss( ...
        trainingData, trainingPrediction, testData, testPrediction, options)
% 模式4已由C程序按实际进口方程反算每个工况的附加压损。这里只做
% 排序、近邻节点合并和线性拟合，不再把h0放回联合参数优化。
required = {'inlet_corrected_mass_flow', ...
    'inlet_pressure_loss_correction', 'Pt1_internal', 'Pt2_measured', ...
    'inlet_nominal_loss', 'inlet_total_loss', 'inlet_ram_recovery'};
if ~all(ismember(required, trainingPrediction.Properties.VariableNames))
    error('SHT:SteadyAdaptV2:MissingDirectInletFields', ...
        '模式4回放结果缺少进气道压损直接反算字段。');
end
valid = trainingPrediction.valid & ...
    isfinite(trainingPrediction.inlet_corrected_mass_flow) & ...
    isfinite(trainingPrediction.inlet_pressure_loss_correction);
if ~all(valid)
    error('SHT:SteadyAdaptV2:InvalidDirectInletEstimate', ...
        '存在不能用于进气道压损直接拟合的训练工况。');
end
xRaw = trainingPrediction.inlet_corrected_mass_flow;
kRaw = trainingPrediction.inlet_pressure_loss_correction;
[xMerged, kMerged, mergeCount] = local_merge_near_nodes( ...
    xRaw, kRaw, options);
if xMerged(1) <= 0
    error('SHT:SteadyAdaptV2:NonPositiveInletFlowNode', ...
        '训练工况的进口换算流量节点必须为正。');
end

entry = local_empty_schedule_entry();
entry.cIndex = 0;
entry.name = 'Inlet_K_dP';
entry.axisName = 'inlet_corrected_mass_flow';
entry.axisType = 1;
entry.pressureLoss = true;
entry.xNodes = [0; xMerged(:)];
entry.kNodes = [0; kMerged(:)];
[~, designRow] = max(trainingData.Wf_mean);
entry.designCoordinate = xRaw(designRow);
entry.lowerBound = -0.02;
entry.upperBound = 0.15;
entry.mergedNodeCount = mergeCount;
entry = local_refresh_schedule_entry(entry);

trainingTable = local_direct_inlet_detail_table( ...
    trainingData, trainingPrediction, entry);
if ~isempty(testData) && ~isempty(testPrediction)
    testTable = local_direct_inlet_detail_table( ...
        testData, testPrediction, entry);
else
    testTable = table();
end
direct = struct();
direct.method = 'mode4_exact_equation_inversion_and_linear_fit';
direct.interpolation = 'linear';
direct.extrapolation = 'nearest_endpoint';
direct.entry = entry;
direct.trainingTable = trainingTable;
direct.testTable = testTable;
direct.rawTrainingNodeCount = numel(xRaw);
direct.mergedPositiveNodeCount = numel(xMerged);
direct.mergeCount = mergeCount;
direct.designValue = entry.designValue;
end

function detail = local_direct_inlet_detail_table(data, prediction, entry)
x = prediction.inlet_corrected_mass_flow;
k = prediction.inlet_pressure_loss_correction;
kFit = arrayfun(@(value) local_interp_clamp( ...
    entry.xNodes, entry.kNodes, value), x);
detail = table(data.point_id, x, prediction.Pt1_internal, ...
    prediction.Pt2_measured, prediction.inlet_nominal_loss, ...
    k, prediction.inlet_total_loss, prediction.inlet_ram_recovery, ...
    kFit, k - kFit, ...
    'VariableNames', {'point_id','inlet_corrected_mass_flow', ...
    'Pt1_internal_Pa','Pt2_measured_Pa','nominal_loss', ...
    'direct_K_dP','total_loss','ram_recovery','fitted_K_dP', ...
    'fit_residual'});
end

function schedule = local_attach_direct_inlet_schedule(schedule, direct)
if any([schedule.healthEntries.cIndex] == 0)
    error('SHT:SteadyAdaptV2:DuplicateInletSchedule', ...
        '调度结构中已经存在h0，不能重复附加直接反算结果。');
end
schedule.healthEntries(end + 1) = direct.entry;
[~, order] = sort([schedule.healthEntries.cIndex]);
schedule.healthEntries = schedule.healthEntries(order);
schedule.directInletPressureLoss = direct;
schedule.designHealth = local_schedule_design_health(schedule);
end

function entry = local_empty_schedule_entry()
entry = struct('cIndex', NaN, 'name', '', 'axisName', '', ...
    'axisType', NaN, 'pressureLoss', false, 'xNodes', [], ...
    'kNodes', [], 'designCoordinate', NaN, 'designValue', NaN, ...
    'xNodesDll', [], 'kNodesDll', [], 'deltaNodesDll', [], ...
    'lowerBound', NaN, 'upperBound', NaN, 'mergedNodeCount', 0, ...
    'dllResamplingUsed', false);
end

function entry = local_refresh_schedule_entry(entry)
entry.designValue = local_interp_clamp( ...
    entry.xNodes, entry.kNodes, entry.designCoordinate);
expectedCount = 6 + double(entry.pressureLoss);
if numel(entry.xNodes) == expectedCount
    xDll = entry.xNodes(:);
    kDll = entry.kNodes(:);
    resampled = false;
else
    if entry.pressureLoss
        positive = entry.xNodes(entry.xNodes > 0);
        if isempty(positive)
            positive = [1; 2];
        end
        xPositive = linspace(min(positive), max(positive), 6).';
        xDll = [0; xPositive];
    else
        xmin = min(entry.xNodes);
        xmax = max(entry.xNodes);
        if xmin == xmax
            xmin = xmin - max(abs(xmin) * 0.01, 1e-3);
            xmax = xmax + max(abs(xmax) * 0.01, 1e-3);
        end
        xDll = linspace(xmin, xmax, 6).';
    end
    kDll = arrayfun(@(x) local_interp_clamp( ...
        entry.xNodes, entry.kNodes, x), xDll);
    if entry.pressureLoss
        kDll(1) = 0;
    end
    resampled = true;
end
entry.xNodesDll = xDll;
entry.kNodesDll = kDll;
entry.deltaNodesDll = kDll - entry.designValue;
if entry.pressureLoss
    entry.deltaNodesDll(1) = -entry.designValue;
end
entry.dllResamplingUsed = resampled;
end

function health = local_schedule_design_health(schedule)
health = zeros(159, 1);
for i = 1:numel(schedule.healthEntries)
    entry = schedule.healthEntries(i);
    health(entry.cIndex + 1) = entry.designValue;
end
health(16) = schedule.h15;
end

function [xMerged, yMerged, mergeCount] = ...
        local_merge_near_nodes(x, y, options)
[x, order] = sort(x(:));
y = y(order);
span = max(x) - min(x);
threshold = max(options.nodeMergeAbsolute, ...
    options.nodeMergeFraction * max(span, eps));
xOut = [];
yOut = [];
memberX = x(1);
memberY = y(1);
for i = 2:numel(x)
    if x(i) - memberX(end) <= threshold
        memberX(end + 1, 1) = x(i); %#ok<AGROW>
        memberY(end + 1, 1) = y(i); %#ok<AGROW>
    else
        xOut(end + 1, 1) = mean(memberX); %#ok<AGROW>
        yOut(end + 1, 1) = mean(memberY); %#ok<AGROW>
        memberX = x(i);
        memberY = y(i);
    end
end
xOut(end + 1, 1) = mean(memberX);
yOut(end + 1, 1) = mean(memberY);
xMerged = xOut;
yMerged = yOut;
mergeCount = numel(x) - numel(xMerged);
end

function schedule = local_apply_schedule_offsets( ...
        baseSchedule, offset, parameters)
schedule = baseSchedule;
for p = 1:height(parameters)
    if parameters.scheduled(p)
        idx = find([schedule.healthEntries.cIndex] == ...
            parameters.c_index(p), 1);
        entry = schedule.healthEntries(idx);
        active = true(size(entry.kNodes));
        if entry.pressureLoss
            active(1) = false;
        end
        entry.kNodes(active) = entry.kNodes(active) + offset(p);
        entry.kNodes(active) = min(max(entry.kNodes(active), ...
            entry.lowerBound), entry.upperBound);
        if entry.pressureLoss
            entry.kNodes(1) = 0;
        end
        schedule.healthEntries(idx) = local_refresh_schedule_entry(entry);
    else
        schedule.h15 = min(max(schedule.h15 + offset(p), ...
            parameters.lower_bound(p)), parameters.upper_bound(p));
    end
end
schedule.fuelBias.biasNodes = schedule.fuelBias.biasNodes + offset(end);
fuelLimit = 0.02 * schedule.fuelBias.wfDesign;
schedule.fuelBias.biasNodes = min(max( ...
    schedule.fuelBias.biasNodes, -fuelLimit), fuelLimit);
schedule.designHealth = local_schedule_design_health(schedule);
end

function [stableSchedule, prediction, valid, retentionDetail] = ...
        local_stabilize_schedule(baseSchedule, stageAValue, route, ...
        engine, cfg, data, parameters, options)
% 组内估计分别合法，并不保证拼接后的曲线对所有点仍合法。采用从完整组间
% 形状到全局常值的同伦回缩。若阶段A常值在低流量门控后的调度表示中
% 仍不可行，再把绝对修正幅值连续回缩到已验证可行的零修正基线。
retentionCandidates = [1, 0.85, 0.70, 0.55, 0.40, 0.25, 0.10, 0];
stableSchedule = baseSchedule;
prediction = table();
valid = false;
retentionDetail = struct('shapeScale', NaN, 'absoluteScale', NaN, ...
    'strategy', "not_found");
for scale = retentionCandidates
    candidate = baseSchedule;
    for p = 1:height(parameters)
        if parameters.scheduled(p)
            idx = find([candidate.healthEntries.cIndex] == ...
                parameters.c_index(p), 1);
            entry = candidate.healthEntries(idx);
            active = true(size(entry.kNodes));
            if entry.pressureLoss
                active(1) = false;
            end
            entry.kNodes(active) = stageAValue(p) + scale * ...
                (entry.kNodes(active) - stageAValue(p));
            if entry.pressureLoss
                entry.kNodes(1) = 0;
            end
            candidate.healthEntries(idx) = local_refresh_schedule_entry(entry);
        else
            candidate.h15 = stageAValue(p) + scale * ...
                (candidate.h15 - stageAValue(p));
        end
    end
    candidate.fuelBias.biasNodes = stageAValue(end) + scale * ...
        (candidate.fuelBias.biasNodes - stageAValue(end));
    candidate.designHealth = local_schedule_design_health(candidate);
    [candidatePrediction, candidateValid] = local_evaluate_dataset( ...
        route, engine, cfg, data, local_schedule_model(candidate), options);
    if candidateValid
        stableSchedule = candidate;
        prediction = candidatePrediction;
        valid = true;
        retentionDetail.shapeScale = scale;
        retentionDetail.absoluteScale = 1;
        retentionDetail.strategy = "shape_homotopy";
        return;
    end
end

% 形状完全回缩仍无效时，说明阶段A绝对幅值与低流量门控组合后过强。
% 继续缩小绝对幅值；absoluteScale=0严格等价于零修正调度，因此只要
% 基线回放有效，本循环必然提供一个物理可行的阶段D初值。
absoluteCandidates = [0.75, 0.50, 0.25, 0.10, 0];
for absoluteScale = absoluteCandidates
    candidate = baseSchedule;
    for p = 1:height(parameters)
        if parameters.scheduled(p)
            idx = find([candidate.healthEntries.cIndex] == ...
                parameters.c_index(p), 1);
            entry = candidate.healthEntries(idx);
            entry.kNodes(:) = absoluteScale * stageAValue(p);
            if entry.pressureLoss
                entry.kNodes(1) = 0;
            end
            candidate.healthEntries(idx) = local_refresh_schedule_entry(entry);
        else
            candidate.h15 = absoluteScale * stageAValue(p);
        end
    end
    candidate.fuelBias.biasNodes(:) = absoluteScale * stageAValue(end);
    candidate.designHealth = local_schedule_design_health(candidate);
    [candidatePrediction, candidateValid] = local_evaluate_dataset( ...
        route, engine, cfg, data, local_schedule_model(candidate), options);
    if candidateValid
        stableSchedule = candidate;
        prediction = candidatePrediction;
        valid = true;
        retentionDetail.shapeScale = 0;
        retentionDetail.absoluteScale = absoluteScale;
        retentionDetail.strategy = "absolute_homotopy";
        return;
    end
end
end

function value = local_interp_clamp(x, y, query)
x = x(:);
y = y(:);
if numel(x) == 1
    value = y(1);
    return;
end
query = min(max(query, x(1)), x(end));
value = interp1(x, y, query, 'linear');
end

function [prediction, allValid, diagnostic] = local_evaluate_dataset( ...
        route, engine, cfg, data, model, options, initialSeedMatrix)
% 一次候选参数对应的调度表只初始化一次，随后对所有工况重复查询。
if nargin < 7 || isempty(initialSeedMatrix)
    initialSeedMatrix = [];
else
    if ~isnumeric(initialSeedMatrix) || ...
            ~isequal(size(initialSeedMatrix), [height(data), 9]) || ...
            any(~isfinite(initialSeedMatrix(:)))
        error('SHT:SteadyAdaptV2:BadInitialSeedMatrix', ...
            '外部共同工作初值必须为测试点数x9的有限矩阵。');
    end
end
if strcmp(model.kind, 'schedule')
    local_configure_dll_schedule(engine, model.schedule);
else
    local_disable_dll_schedule(engine);
end

records = repmat(local_empty_prediction_record(), height(data), 1);
diagnostic = local_empty_dataset_diagnostic(height(data));
allValid = true;
for i = 1:height(data)
    try
        seedOverride = [];
        if ~isempty(initialSeedMatrix)
            seedOverride = initialSeedMatrix(i, :).';
        end
        [records(i), pointDiagnostic] = local_evaluate_point( ...
            route, engine, cfg, data(i, :), model, options, seedOverride);
        diagnostic.initialSeed(i, :) = pointDiagnostic.initialSeed;
        diagnostic.solutionSeed(i, :) = pointDiagnostic.solutionSeed;
        diagnostic.seedSource(i) = pointDiagnostic.seedSource;
        diagnostic.solutionAvailable(i) = ...
            pointDiagnostic.solutionAvailable;
    catch evaluationError
        records(i) = local_empty_prediction_record();
        records(i).point_id = data.point_id(i);
        records(i).valid = false;
        records(i).error_message = string(evaluationError.message);
    end
    allValid = allValid && records(i).valid;
end
prediction = struct2table(records);
end

function [record, diagnostic] = local_evaluate_point( ...
        route, engine, cfg, point, model, options, seedOverride)
if nargin < 7
    seedOverride = [];
end
diagnostic = local_empty_point_diagnostic();
npMeasured = point.Np_mean(1);
ngMeasured = point.Ng_mean(1);
wfInput = point.Wf_mean(1);
if strcmp(model.kind, 'schedule')
    xFuel = wfInput / model.schedule.fuelBias.wfDesign;
    fuelBias = local_interp_clamp(model.schedule.fuelBias.xNodes, ...
        model.schedule.fuelBias.biasNodes, xFuel);
    health = model.schedule.designHealth;
    scheduleEnabled = true;
else
    fuelBias = model.fuelBias;
    health = model.health;
    scheduleEnabled = false;
end
if strcmp(options.fuelInputSemantics, 'physical_model')
    fuelBias = 0;
end
wfModel = wfInput - fuelBias;
if ~isfinite(wfModel) || wfModel <= 0
    error('SHT:SteadyAdaptV2:NonPositiveFuel', ...
        '工况%s的燃油偏置使模型燃油流量非正。', char(point.point_id));
end

% 当前DLL的轴负载接口仍为功率。用同一时刻测得的转速和扭矩重构
% 试车边界功率；稳态路径中的Np/Ng仍由模型独立求解。
ptLoadPower = point.Mkp_mean(1) * pi * npMeasured / 30;
gtLoadPower = point.Mkg_mean(1) * pi * ngMeasured / 30;
stepInValue = zeros(cfg.engine.interface.stepInLength, 1);
stepInValue(1:10) = [npMeasured; ngMeasured; wfModel; ...
    cfg.engine.boundary.A8; 0; ptLoadPower; gtLoadPower; 0; ...
    cfg.engine.boundary.hpcAlpha; 0];
if options.inletBoundaryMode == 1
    % 受控方法对照：Pt1使用替代数据真值，Tt1仍使用试车
    % 测量均值。该路径不是真实数据可部署方案，只用于判断边界
    % 重构方式对参数辨识的影响。
    if ~ismember('Pt1_truth', point.Properties.VariableNames)
        error('SHT:SteadyAdaptV2:MissingPt1Truth', ...
            '模式1对照缺少Pt1_truth。');
    end
    inletBoundary = struct( ...
        'inletBoundaryMode', 1, ...
        'altitude', point.Altitude_mean(1), ...
        'Mach', point.Mach_mean(1), ...
        'deltaTemperature', 0, ...
        'Pt1', point.Pt1_truth(1), ...
        'Tt1', point.Tt1_mean(1), ...
        'Pamb', point.Pamb_mean(1));
elseif options.inletBoundaryMode == 2
    % 模式2：预测入口只给Pamb/Tamb/Mach，DLL重构Pt1和Tt1，再由
    % 进口部件计算Pt2。高度只作为可选元数据，不参与重复环境计算。
    inletBoundary = struct( ...
        'inletBoundaryMode', 2, ...
        'altitude', point.Altitude_mean(1), ...
        'Mach', point.Mach_mean(1), ...
        'deltaTemperature', 0, ...
        'Pamb', point.Pamb_mean(1), ...
        'Tamb', point.Tamb_mean(1));
elseif options.inletBoundaryMode == 3
    % 模式3只用于无测量数据预测：逐点给定高度、Mach和静温，DLL
    % 复用标准大气模型计算Pamb，再重构Pt1/Tt1。
    inletBoundary = struct( ...
        'inletBoundaryMode', 3, ...
        'altitude', point.Altitude_mean(1), ...
        'Mach', point.Mach_mean(1), ...
        'deltaTemperature', 0, ...
        'Tamb', point.Tamb_mean(1));
else
    % 模式4：仍由环境边界重构内部Pt1，直接以实测Pt2作为AC入口
    % 压力。进气道压损由C程序按原始压损方程反算，不参与联合估计。
    inletBoundary = struct( ...
        'inletBoundaryMode', 4, ...
        'altitude', point.Altitude_mean(1), ...
        'Mach', point.Mach_mean(1), ...
        'deltaTemperature', 0, ...
        'Pamb', point.Pamb_mean(1), ...
        'Tamb', point.Tamb_mean(1), ...
        'Tt1', point.Tt1_mean(1), ...
        'Pt2', point.Pt2_mean(1));
end
[stepInValue, inletBoundaryDetail] = ...
    sht_apply_inlet_boundary_stepin(stepInValue, inletBoundary);
if options.inletBoundaryMode == 1
    assert(inletBoundaryDetail.mode == 1 && ...
        inletBoundaryDetail.directPt1InputUsed && ...
        ~inletBoundaryDetail.pt2InputUsed && ...
        stepInValue(14) == point.Pt1_truth(1), ...
        'Pt1真值对照的模式1边界契约被破坏。');
elseif options.inletBoundaryMode == 2
    assert(inletBoundaryDetail.mode == 2 && ...
        ~inletBoundaryDetail.directPt1InputUsed && ...
        ~inletBoundaryDetail.measuredTt1InputUsed && ...
        ~inletBoundaryDetail.pt2InputUsed && stepInValue(14) == 0 && ...
        stepInValue(15) == 0, ...
        '模式2预测契约被破坏：Pt1、Tt1和Pt2均应由DLL内部重构。');
elseif options.inletBoundaryMode == 3
    assert(inletBoundaryDetail.mode == 3 && ...
        ~inletBoundaryDetail.directPt1InputUsed && ...
        ~inletBoundaryDetail.measuredTt1InputUsed && ...
        ~inletBoundaryDetail.pt2InputUsed && ...
        inletBoundaryDetail.altitudeAtmosphereUsed && ...
        all(stepInValue(14:16) == 0) && ...
        stepInValue(19) == point.Tamb_mean(1), ...
        '模式3预测契约被破坏：仅允许高度、Mach和静温进入环境重构。');
else
    assert(inletBoundaryDetail.mode == 4 && ...
        ~inletBoundaryDetail.directPt1InputUsed && ...
        inletBoundaryDetail.pt2InputUsed && ...
        stepInValue(14) == point.Pt2_mean(1), ...
        '模式4辨识回放契约被破坏：stepIn(14)必须为实测Pt2。');
end
stepInValue(cfg.engine.interface.healthScheduleEnableIndex) = ...
    double(scheduleEnabled);
healthStart = cfg.engine.interface.healthStartIndex;
stepInValue(healthStart:(healthStart + numel(health) - 1)) = health(:);

if isempty(seedOverride)
    seed = local_initial_common_variable_seed( ...
        cfg, ptLoadPower, npMeasured, ngMeasured);
    diagnostic.seedSource = "configured_initial_guess";
else
    seed = seedOverride(:);
    if numel(seed) ~= 9 || any(~isfinite(seed))
        error('SHT:SteadyAdaptV2:BadPointInitialSeed', ...
            '工况%s的外部共同工作初值必须为有限9维向量。', ...
            char(point.point_id));
    end
    diagnostic.seedSource = "external_common_work_seed";
end
diagnostic.initialSeed = seed(:).';
local_set_dll_seed(engine, cfg, seed);
robustFallbackUsed = false;
if strcmp(route, 'steady')
    if strcmp(options.steadyLoadBoundaryMode, 'torque')
        % Mkp/Mkg是外部负载扭矩。把功率换算放入共同工作残差计算，
        % 避免用未知测试转速预先固定轴功率并诱发错误稳态分支。
        fallback = sht_solve_steady_components_from_seed( ...
            engine, cfg, stepInValue, seed, struct( ...
            'ptLoadTorqueNm', point.Mkp_mean(1), ...
            'gtLoadTorqueNm', point.Mkg_mean(1)));
        ret = fallback.ret;
        eng = fallback.engOut.eng;
    else
        [ret, ~, eng] = local_call_one_point( ...
            engine, cfg, stepInValue);
        % C内置Newton失败时才启用指定分支的阻尼求解器，正常工况不增加开销。
        initialResidual = local_engine_max_residual(eng);
        if ret ~= 0 || eng.convergeTag ~= 0 || ...
                ~isfinite(initialResidual) || ...
                initialResidual > options.maxModelResidual
            fallback = sht_solve_steady_components_from_seed( ...
                engine, cfg, stepInValue, seed);
            ret = fallback.ret;
            eng = fallback.engOut.eng;
        end
    end
    dNpDt = NaN;
    dNgDt = NaN;
else
    [ret, stepOutValue, eng] = local_call_one_step( ...
        engine, cfg, stepInValue);
    initialResidual = local_engine_max_residual(eng);
    if options.useRobustTransientFallback && ...
            (ret ~= 0 || eng.convergeTag ~= 0 || ...
            ~isfinite(initialResidual) || ...
            initialResidual > options.maxModelResidual)
        fallback = sht_solve_transient_components_from_seed( ...
            engine, cfg, stepInValue, seed(1:7));
        ret = fallback.ret;
        eng = fallback.engOut.eng;
        stepOutValue = fallback.stepOut;
        robustFallbackUsed = true;
    end
    dNpDt = stepOutValue(1);
    dNgDt = stepOutValue(2);
    if robustFallbackUsed
        % DLL_SHT_RunTransientComponents的前7项为共同工作残差，随后两项
        % 才是两轴导数；RunOneStep则直接把导数写在前两项。
        dNpDt = stepOutValue(8);
        dNgDt = stepOutValue(9);
    end
end

maxResidual = local_engine_max_residual(eng);
record = local_empty_prediction_record();
record.point_id = point.point_id(1);
record.return_code = ret;
record.converge_tag = double(eng.convergeTag);
record.max_model_residual = maxResidual;
record.robust_transient_fallback_used = robustFallbackUsed;
record.wf_measured = wfInput;
record.wf_bias = fuelBias;
record.wf_model = wfModel;
record.Np = double(eng.LPS_Nmech);
record.Ng = double(eng.HPS_Nmech);
if options.inletBoundaryMode == 1
    record.Pt1_boundary_input = point.Pt1_truth(1);
end
record.Pt1_internal = double(eng.Ambient.gasPathOut(4));
record.Tt1 = double(eng.Ambient.gasPathOut(3));
record.Pamb = double(eng.Ambient.y(5));
record.Tamb = double(eng.Ambient.y(6));
record.Pt2 = double(eng.Inlet.gasPathOut(4));
record.Pt2_measured = point.Pt2_mean(1);
record.inlet_boundary_mode = inletBoundaryDetail.mode;
record.direct_pt1_input_used = inletBoundaryDetail.directPt1InputUsed;
record.pt2_input_used = inletBoundaryDetail.pt2InputUsed;
record.inlet_nominal_loss = ...
    double(eng.Inlet.pressureLossModel.lastNominalLoss);
record.inlet_pressure_loss_correction = ...
    double(eng.Inlet.pressureLossModel.lastCorrectionLoss);
record.inlet_total_loss = ...
    double(eng.Inlet.pressureLossModel.lastTotalLoss);
recoveryDenominator = record.Pt1_internal * ...
    (1 - record.inlet_total_loss);
if isfinite(recoveryDenominator) && recoveryDenominator > 0
    record.inlet_ram_recovery = record.Pt2 / recoveryDenominator;
end
record.Pt3 = double(eng.HPC2.y(4));
record.Tt3 = double(eng.HPC2.y(3));
record.Tt45 = double(eng.HPT2.y(3));
record.Pt45 = double(eng.HPT2.y(4));
record.dNp_dt = dNpDt;
record.dNg_dt = dNgDt;
record.inlet_corrected_mass_flow = local_corrected_flow( ...
    eng.Ambient.gasPathOut);
record.burner_inlet_corrected_mass_flow = local_corrected_flow( ...
    eng.HPC2.y);
record.gt_pt_duct_corrected_mass_flow = local_corrected_flow( ...
    eng.HPT2.y);
record.pt_nozzle_duct_corrected_mass_flow = local_corrected_flow( ...
    eng.LPT2.y);
record.ac_corrected_speed = double(eng.HPC.y(16));
varIte = double(eng.varIte(:));
if numel(varIte) >= 7
    record.gt_total_pressure_ratio = varIte(4) * varIte(5);
    record.pt_total_pressure_ratio = varIte(6) * varIte(7);
end
% convergeTag保留为求解器诊断，但不单独否决候选。部分工况会在达到
% 迭代停止条件时返回tag=1，而共同工作残差已经远低于验收门限。
record.valid = ret == 0 && ...
    isfinite(maxResidual) && maxResidual <= options.maxModelResidual && ...
    all(isfinite([record.Np, record.Ng, record.Pamb, record.Tamb, ...
    record.Tt1, record.Pt2, record.Pt3, record.Tt3, ...
    record.Tt45, record.Pt45]));
if strcmp(route, 'transient_instant')
    record.valid = record.valid && all(isfinite([dNpDt, dNgDt]));
end
if ~record.valid
    record.error_message = string(sprintf( ...
        'ret=%d, tag=%g, maxResidual=%.6g', ...
        ret, record.converge_tag, maxResidual));
end

solutionSeed = double(eng.varIte(:));
if strcmp(route, 'transient_instant')
    % 瞬态模型只求解前7个气路共同工作变量；两轴转速是已测状态输入，
    % 因此构造后续稳态初值时必须显式补回当前测试点Np/Ng。
    solutionSeed = [solutionSeed(1:7); npMeasured; ngMeasured];
else
    solutionSeed = solutionSeed(1:9);
end
diagnostic.solutionSeed = solutionSeed(:).';
diagnostic.solutionAvailable = record.valid && ...
    all(isfinite(solutionSeed));
end

function diagnostic = local_empty_dataset_diagnostic(pointCount)
diagnostic = struct( ...
    'initialSeed', nan(pointCount, 9), ...
    'solutionSeed', nan(pointCount, 9), ...
    'seedSource', strings(pointCount, 1), ...
    'solutionAvailable', false(pointCount, 1));
end

function diagnostic = local_empty_point_diagnostic()
diagnostic = struct('initialSeed', nan(1, 9), ...
    'solutionSeed', nan(1, 9), 'seedSource', "", ...
    'solutionAvailable', false);
end

function record = local_empty_prediction_record()
record = struct('point_id', "", 'return_code', NaN, ...
    'converge_tag', NaN, 'max_model_residual', NaN, ...
    'robust_transient_fallback_used', false, ...
    'wf_measured', NaN, 'wf_bias', NaN, 'wf_model', NaN, ...
    'Np', NaN, 'Ng', NaN, 'Pt1_boundary_input', NaN, ...
    'Pt1_internal', NaN, 'Tt1', NaN, 'Pamb', NaN, 'Tamb', NaN, ...
    'Pt2', NaN, 'Pt2_measured', NaN, ...
    'inlet_boundary_mode', NaN, 'direct_pt1_input_used', false, ...
    'pt2_input_used', false, 'inlet_nominal_loss', NaN, ...
    'inlet_pressure_loss_correction', NaN, ...
    'inlet_total_loss', NaN, 'inlet_ram_recovery', NaN, ...
    'Pt3', NaN, 'Tt3', NaN, ...
    'Tt45', NaN, 'Pt45', NaN, 'dNp_dt', NaN, 'dNg_dt', NaN, ...
    'inlet_corrected_mass_flow', NaN, ...
    'burner_inlet_corrected_mass_flow', NaN, ...
    'gt_pt_duct_corrected_mass_flow', NaN, ...
    'pt_nozzle_duct_corrected_mass_flow', NaN, ...
    'ac_corrected_speed', NaN, 'gt_total_pressure_ratio', NaN, ...
    'pt_total_pressure_ratio', NaN, 'valid', false, ...
    'error_message', "");
end

function seed = local_initial_common_variable_seed( ...
        cfg, ptLoadPower, npMeasured, ngMeasured)
seedInfo = sht_get_steady_trim_initial_guess( ...
    cfg, npMeasured, ptLoadPower, 'auto');
if seedInfo.available && numel(seedInfo.varIte) == 9 && ...
        all(isfinite(seedInfo.varIte))
    seed = seedInfo.varIte(:);
else
    % 仅在公共初值资产不可用时使用设计状态附近的工程回退值。
    npRatio = npMeasured / cfg.engine.initial.Np0;
    loadRatio = ptLoadPower / cfg.engine.initial.power0;
    seed = [max(2.5, 6.7 * max(loadRatio, 0.15)); ...
        min(max(0.70 + 0.18 * (1 - loadRatio), 0.5), 0.98); ...
        min(max(0.70 + 0.14 * (1 - loadRatio), 0.5), 0.98); ...
        2.0 + 1.8 * max(loadRatio, 0.1); ...
        1.5 + 1.6 * max(loadRatio, 0.1); ...
        1.5 + 1.5 * max(loadRatio, 0.1); ...
        1.2 + 1.2 * max(loadRatio, 0.1); ...
        npMeasured; ngMeasured];
    if npRatio < 0.75
        seed(8:9) = [npMeasured; ngMeasured];
    end
end
seed(8) = npMeasured;
seed(9) = ngMeasured;
end

function local_set_dll_seed(engine, cfg, seed)
stepInValue = zeros(cfg.engine.interface.stepInLength, 1);
stepInValue(21:29) = seed(:);
engPtr = local_engine_pointer(engine);
stepIn = libpointer('doublePtr', stepInValue);
stepOut = libpointer('doublePtr', zeros(cfg.engine.interface.stepOutLength, 1));
status = calllib(engine.libraryName, 'DLL_SHT_varIteInit', ...
    stepIn, stepOut, engPtr);
if status ~= 0
    error('SHT:SteadyAdaptV2:SeedInitializationFailure', ...
        'DLL共同工作初值写入失败，状态码=%d。', status);
end
end

function [ret, stepOutValue, eng] = local_call_one_point( ...
        engine, cfg, stepInValue)
engPtr = local_engine_pointer(engine);
stepIn = libpointer('doublePtr', stepInValue);
stepOut = libpointer('doublePtr', zeros(cfg.engine.interface.stepOutLength, 1));
[ret, ~, stepOutValue, engOut] = calllib(engine.libraryName, ...
    'DLL_SHT_RunOnePoint', stepIn, stepOut, engPtr);
eng = engOut.eng;
end

function [ret, stepOutValue, eng] = local_call_one_step( ...
        engine, cfg, stepInValue)
engPtr = local_engine_pointer(engine);
stepIn = libpointer('doublePtr', stepInValue);
stepOut = libpointer('doublePtr', zeros(cfg.engine.interface.stepOutLength, 1));
[ret, ~, stepOutValue, engOut] = calllib(engine.libraryName, ...
    'DLL_SHT_RunOneStep', stepIn, stepOut, engPtr);
eng = engOut.eng;
end

function engPtr = local_engine_pointer(engine)
engPtrInit.eng = libstruct(engine.engineStructName);
engPtr = libstruct(engine.enginePointerName, engPtrInit);
end

function value = local_engine_max_residual(eng)
value = max(abs([double(eng.errOut(:)); double(eng.Nozzle.y(end))]));
end

function correctedFlow = local_corrected_flow(gasPath)
gasPath = double(gasPath(:));
massFlow = gasPath(1);
totalTemperature = gasPath(3);
totalPressure = gasPath(4);
correctedFlow = massFlow * sqrt(totalTemperature / 288.15) * ...
    101325 / totalPressure;
end

function local_disable_dll_schedule(engine)
status = calllib(engine.libraryName, ...
    'DLL_SHT_HealthScheduleSetEnabled', int32(0));
if status ~= 0
    % DLL刚初始化、尚未配置表时SetEnabled(0)也应返回0；非0表示接口漂移。
    error('SHT:SteadyAdaptV2:ScheduleDisableFailure', ...
        '关闭DLL健康调度失败，状态码=%d。', status);
end
end

function local_configure_dll_schedule(engine, schedule)
% DLL要求31张表全部就绪后才能启用。本程序只估计其中10张，剩余表
% 使用零增量占位，确保未估参数严格保持stepIn给定常值（本轮为0）。
local_disable_dll_schedule(engine);
status = calllib(engine.libraryName, 'DLL_SHT_HealthScheduleReset');
if status ~= 0
    error('SHT:SteadyAdaptV2:ScheduleResetFailure', ...
        '复位DLL健康调度失败，状态码=%d。', status);
end

[allIndex, allAxis] = local_all_schedule_dictionary();
for i = 1:numel(allIndex)
    cIndex = allIndex(i);
    axisType = allAxis(i);
    estimatedIndex = find([schedule.healthEntries.cIndex] == cIndex, 1);
    if isempty(estimatedIndex)
        [xNode, deltaNode] = local_zero_increment_schedule(axisType);
    else
        entry = schedule.healthEntries(estimatedIndex);
        xNode = entry.xNodesDll(:);
        deltaNode = entry.deltaNodesDll(:);
    end
    status = calllib(engine.libraryName, ...
        'DLL_SHT_HealthScheduleConfigureTable', int32(cIndex), ...
        int32(axisType), int32(numel(xNode)), ...
        libpointer('doublePtr', xNode), ...
        libpointer('doublePtr', deltaNode));
    if status ~= 0
        error('SHT:SteadyAdaptV2:ScheduleConfigureFailure', ...
            '配置h%d调度表失败，axis=%d，nodeCount=%d，状态码=%d。', ...
            cIndex, axisType, numel(xNode), status);
    end
end
configured = calllib(engine.libraryName, ...
    'DLL_SHT_HealthScheduleGetConfiguredCount');
if configured ~= 31
    error('SHT:SteadyAdaptV2:ScheduleCountMismatch', ...
        'DLL已配置调度表数量为%d，预期31。', configured);
end
end

function [cIndex, axisType] = local_all_schedule_dictionary()
cIndex = [0, 1, 2, 3, 6, 7, 8, 9, 10, 11, 12, 13, 14, 71:88].';
axisType = zeros(size(cIndex));
for i = 1:numel(cIndex)
    h = cIndex(i);
    if h == 0
        axisType(i) = 1;
    elseif h == 6
        axisType(i) = 2;
    elseif h == 10
        axisType(i) = 3;
    elseif h == 14
        axisType(i) = 4;
    elseif ismember(h, [1:3, 71:73])
        axisType(i) = 5;
    elseif ismember(h, 74:76)
        axisType(i) = 6;
    elseif ismember(h, [7:9, 77:82])
        axisType(i) = 7;
    elseif ismember(h, [11:13, 83:88])
        axisType(i) = 8;
    else
        error('SHT:SteadyAdaptV2:InternalScheduleDictionary', ...
            'h%d未配置调度坐标。', h);
    end
end
end

function [xNode, deltaNode] = local_zero_increment_schedule(axisType)
if axisType <= 4
    xNode = [0; 1; 2; 3; 4; 5; 6];
elseif axisType <= 6
    xNode = [0.5; 0.7; 0.85; 1.0; 1.15; 1.3];
else
    xNode = [1; 2; 3; 4; 5; 6];
end
deltaNode = zeros(size(xNode));
end

function residual = local_data_residual(route, data, prediction, scales)
names = cellstr(scales.name);
residual = zeros(height(data) * numel(names), 1);
cursor = 0;
for j = 1:numel(names)
    name = names{j};
    predicted = prediction.(name);
    target = local_target_vector(data, name);
    idx = cursor + (1:height(data));
    residual(idx) = (predicted - target) / scales.scale(j);
    cursor = cursor + height(data);
end
if strcmp(route, 'steady') && any(ismember(names, {'dNp_dt','dNg_dt'}))
    error('SHT:SteadyAdaptV2:InternalResidualDefinition', ...
        '稳态路径残差错误包含轴加速度。');
end
end

function target = local_target_vector(data, name)
switch name
    case 'Np'
        target = data.Np_mean;
    case 'Ng'
        target = data.Ng_mean;
    case 'Pt2'
        target = data.Pt2_mean;
    case 'Pt3'
        target = data.Pt3_mean;
    case 'Tt3'
        target = data.Tt3_mean;
    case 'Tt45'
        target = data.Tt45_mean;
    case 'Pt45'
        target = data.Pt45_mean;
    case {'dNp_dt', 'dNg_dt'}
        target = zeros(height(data), 1);
    otherwise
        error('SHT:SteadyAdaptV2:UnknownResidual', ...
            '未知残差字段%s。', name);
end
end

function metrics = local_dataset_metrics(route, data, prediction, scales)
names = cellstr(scales.name);
if isempty(data)
    field = string(names(:));
    nanColumn = nan(numel(names), 1);
    metrics = struct('route', route, 'valid_point_nrms', NaN, ...
        'overall_nrms', NaN, 'valid_point_count', 0, 'point_count', 0, ...
        'all_points_valid', NaN, 'max_model_residual', NaN, ...
        'byField', table(field, nanColumn, nanColumn, nanColumn, nanColumn, ...
        'VariableNames', {'field','rmse','normalized_rmse', ...
        'mean_absolute_error','mean_absolute_relative_error_pct'}));
    return;
end
validPoint = prediction.valid & ...
    isfinite(prediction.max_model_residual);
field = strings(numel(names), 1);
rmse = nan(numel(names), 1);
normalizedRmse = nan(numel(names), 1);
meanAbsoluteError = nan(numel(names), 1);
meanAbsoluteRelativeErrorPct = nan(numel(names), 1);
for i = 1:numel(names)
    field(i) = string(names{i});
    target = local_target_vector(data, names{i});
    predictedValue = prediction.(names{i});
    fieldValid = validPoint & isfinite(predictedValue) & ...
        isfinite(target);
    if ~any(fieldValid)
        continue;
    end
    target = target(fieldValid);
    errorValue = predictedValue(fieldValid) - target;
    rmse(i) = sqrt(mean(errorValue .^ 2));
    normalizedRmse(i) = rmse(i) / scales.scale(i);
    meanAbsoluteError(i) = mean(abs(errorValue));
    denominator = abs(target);
    valid = denominator > max(1e-12, 1e-8 * max(denominator));
    if any(valid)
        meanAbsoluteRelativeErrorPct(i) = ...
            mean(abs(errorValue(valid)) ./ denominator(valid)) * 100;
    end
end
metrics = struct();
metrics.route = route;
metrics.valid_point_nrms = sqrt(mean(normalizedRmse .^ 2, 'omitnan'));
if all(validPoint)
    metrics.overall_nrms = metrics.valid_point_nrms;
else
    % 不用失败回放的默认零值或溢出值伪造“全集误差”。
    metrics.overall_nrms = NaN;
end
metrics.valid_point_count = sum(validPoint);
metrics.point_count = height(prediction);
metrics.all_points_valid = all(validPoint);
metrics.max_model_residual = max( ...
    prediction.max_model_residual(validPoint), [], 'omitnan');
metrics.byField = table(field, rmse, normalizedRmse, meanAbsoluteError, ...
    meanAbsoluteRelativeErrorPct, ...
    'VariableNames', {'field','rmse','normalized_rmse', ...
    'mean_absolute_error','mean_absolute_relative_error_pct'});
end

function evaluation = local_evaluate_transient_test_as_steady( ...
        route, engine, cfg, scaleReferenceData, testData, ...
        baselineModel, correctedModel, options, ...
        baselineTransientDiagnostic, correctedTransientDiagnostic)
% 用瞬态时刻模型已经收敛的7个气路共同工作变量，加上该点实测
% Np/Ng，组成9维稳态初值。该支路只评价独立测试集，不参与参数更新。
evaluation = struct('performed', false, ...
    'initializationSource', "", 'residualScales', table(), ...
    'baseline', struct(), 'corrected', struct(), ...
    'predictionTable', table(), 'seedTransferTable', table());
if isempty(testData) || ~strcmp(route, 'transient_instant') || ...
        ~options.evaluateSteadyTestFromTransient
    return;
end
if ~all(baselineTransientDiagnostic.solutionAvailable) || ...
        ~all(correctedTransientDiagnostic.solutionAvailable)
    error('SHT:SteadyAdaptV2:TransientSeedUnavailable', ...
        '存在未收敛的瞬态测试点，不能构造完整稳态初值。');
end

% 归一化尺度由训练集冻结，测试集只负责评价，不能反向定义指标尺度。
steadyScales = local_residual_scales( ...
    'steady', cfg, scaleReferenceData, options);
[baselinePrediction, baselineValid, baselineSteadyDiagnostic] = ...
    local_evaluate_dataset('steady', engine, cfg, testData, ...
    baselineModel, options, baselineTransientDiagnostic.solutionSeed);
[correctedPrediction, correctedValid, correctedSteadyDiagnostic] = ...
    local_evaluate_dataset('steady', engine, cfg, testData, ...
    correctedModel, options, correctedTransientDiagnostic.solutionSeed);

baselineMetrics = local_dataset_metrics( ...
    'steady', testData, baselinePrediction, steadyScales);
correctedMetrics = local_dataset_metrics( ...
    'steady', testData, correctedPrediction, steadyScales);
predictionTable = local_prediction_detail_table( ...
    'steady', testData, baselinePrediction, correctedPrediction, ...
    steadyScales);
seedTransferTable = local_transient_to_steady_seed_table( ...
    testData, baselineTransientDiagnostic, baselineSteadyDiagnostic, ...
    baselinePrediction, correctedTransientDiagnostic, ...
    correctedSteadyDiagnostic, correctedPrediction);

evaluation.performed = true;
evaluation.initializationSource = ...
    "各测试点瞬态时刻模型收敛共同工作变量";
evaluation.residualScales = steadyScales;
evaluation.baseline = struct( ...
    'transientConvergedSeed', baselineTransientDiagnostic.solutionSeed, ...
    'steadyPrediction', baselinePrediction, ...
    'steadyValid', baselineValid, 'steadyMetrics', baselineMetrics, ...
    'steadyDiagnostic', baselineSteadyDiagnostic);
evaluation.corrected = struct( ...
    'transientConvergedSeed', correctedTransientDiagnostic.solutionSeed, ...
    'steadyPrediction', correctedPrediction, ...
    'steadyValid', correctedValid, 'steadyMetrics', correctedMetrics, ...
    'steadyDiagnostic', correctedSteadyDiagnostic);
evaluation.predictionTable = predictionTable;
evaluation.seedTransferTable = seedTransferTable;
end

function tbl = local_transient_to_steady_seed_table( ...
        data, baselineTransient, baselineSteady, baselinePrediction, ...
        correctedTransient, correctedSteady, correctedPrediction)
n = height(data);
modelVariant = [repmat("zero_correction", n, 1); ...
    repmat("estimated_correction", n, 1)];
pointId = [string(data.point_id); string(data.point_id)];
transientSeed = [baselineTransient.solutionSeed; ...
    correctedTransient.solutionSeed];
steadyInitialSeed = [baselineSteady.initialSeed; ...
    correctedSteady.initialSeed];
steadySolution = [baselineSteady.solutionSeed; ...
    correctedSteady.solutionSeed];
seedSource = [baselineSteady.seedSource; correctedSteady.seedSource];
steadyValid = [baselinePrediction.valid; correctedPrediction.valid];
steadyMaxResidual = [baselinePrediction.max_model_residual; ...
    correctedPrediction.max_model_residual];
seedTransferMaxAbsError = max(abs( ...
    steadyInitialSeed - transientSeed), [], 2);
seedScale = max(abs(transientSeed), [], 2);
seedTolerance = 1e-12 * max(1, seedScale);
if any(seedTransferMaxAbsError > seedTolerance)
    error('SHT:SteadyAdaptV2:TransientSeedTransferMismatch', ...
        '瞬态收敛解传入稳态初值时发生数值改变。');
end

tbl = table(modelVariant, pointId, seedSource, ...
    seedTransferMaxAbsError, steadyValid, steadyMaxResidual, ...
    'VariableNames', {'model_variant','point_id','seed_source', ...
    'seed_transfer_max_abs_error','steady_valid', ...
    'steady_max_model_residual'});
variableName = {'Win','Rline_AC','Rline_CC','PR_GT1','PR_GT2', ...
    'PR_PT1','PR_PT2','Np','Ng'};
for j = 1:numel(variableName)
    tbl.(['transient_' variableName{j}]) = transientSeed(:, j);
    tbl.(['steady_initial_' variableName{j}]) = steadyInitialSeed(:, j);
    tbl.(['steady_solution_' variableName{j}]) = steadySolution(:, j);
end
end

function local_write_steady_test_from_transient_excel(filePath, evaluation)
if ~evaluation.performed
    return;
end
writetable(evaluation.baseline.steadyMetrics.byField, filePath, ...
    'Sheet', 'steady_test_metric_base');
writetable(evaluation.corrected.steadyMetrics.byField, filePath, ...
    'Sheet', 'steady_test_metric_est');
writetable(evaluation.predictionTable, filePath, ...
    'Sheet', 'steady_test_prediction');
writetable(evaluation.seedTransferTable, filePath, ...
    'Sheet', 'steady_test_seed');
writetable(evaluation.residualScales, filePath, ...
    'Sheet', 'steady_test_scales');
end

function local_print_steady_test_from_transient(evaluation)
if ~evaluation.performed
    return;
end
fprintf(['测试集额外稳态回放（以对应瞬态收敛解为初值）NRMS：' ...
    '%.6g -> %.6g；有效：%d/%d。\n'], ...
    evaluation.baseline.steadyMetrics.overall_nrms, ...
    evaluation.corrected.steadyMetrics.overall_nrms, ...
    evaluation.baseline.steadyValid, evaluation.corrected.steadyValid);
comparison = table( ...
    evaluation.corrected.steadyMetrics.byField.field, ...
    evaluation.baseline.steadyMetrics.byField.normalized_rmse, ...
    evaluation.corrected.steadyMetrics.byField.normalized_rmse, ...
    evaluation.corrected.steadyMetrics.byField.mean_absolute_relative_error_pct, ...
    'VariableNames', {'field','baseline_normalized_rmse', ...
    'corrected_normalized_rmse','corrected_mean_abs_relative_error_pct'});
disp(comparison);
end

function tbl = local_parameter_result_table( ...
        parameters, stageAValue, groupResults, finalSchedule)
groupMatrix = zeros(numel(groupResults), numel(stageAValue));
for i = 1:numel(groupResults)
    groupMatrix(i, :) = groupResults(i).x(:).';
end
n = height(parameters);
cIndex = parameters.c_index;
name = parameters.name;
scheduled = parameters.scheduled;
stageA = stageAValue(1:n);
groupMean = mean(groupMatrix(:, 1:n), 1).';
groupMin = min(groupMatrix(:, 1:n), [], 1).';
groupMax = max(groupMatrix(:, 1:n), [], 1).';
finalDesignValue = nan(n, 1);
for i = 1:n
    if parameters.scheduled(i)
        entry = finalSchedule.healthEntries( ...
            [finalSchedule.healthEntries.cIndex] == cIndex(i));
        finalDesignValue(i) = entry.designValue;
    else
        finalDesignValue(i) = finalSchedule.h15;
    end
end
lowerBound = parameters.lower_bound;
upperBound = parameters.upper_bound;
tbl = table(cIndex, name, scheduled, stageA, groupMean, groupMin, ...
    groupMax, finalDesignValue, lowerBound, upperBound, ...
    'VariableNames', {'c_index','name','scheduled','stageA_constant', ...
    'group_mean','group_min','group_max','final_design_value', ...
    'lower_bound','upper_bound'});
end

function tbl = local_group_estimate_table( ...
        groups, groupResults, parameters, wfDesign)
nGroup = height(groups);
nParameter = height(parameters);
rows = nGroup * (nParameter + 1);
groupId = strings(rows, 1);
pointIds = strings(rows, 1);
parameter = strings(rows, 1);
cIndex = nan(rows, 1);
estimate = nan(rows, 1);
unit = strings(rows, 1);
cursor = 0;
for g = 1:nGroup
    x = groupResults(g).x;
    for p = 1:nParameter
        cursor = cursor + 1;
        groupId(cursor) = groups.group_id(g);
        pointIds(cursor) = groups.point_ids(g);
        parameter(cursor) = parameters.name(p);
        cIndex(cursor) = parameters.c_index(p);
        estimate(cursor) = x(p);
        unit(cursor) = "1";
    end
    cursor = cursor + 1;
    groupId(cursor) = groups.group_id(g);
    pointIds(cursor) = groups.point_ids(g);
    parameter(cursor) = "Wf_measurement_bias";
    cIndex(cursor) = NaN;
    estimate(cursor) = x(end);
    unit(cursor) = "kg/s";
end
estimateRelativeToDesignPct = estimate / wfDesign * 100;
estimateRelativeToDesignPct(~isnan(cIndex)) = NaN;
tbl = table(groupId, pointIds, parameter, cIndex, estimate, unit, ...
    estimateRelativeToDesignPct, ...
    'VariableNames', {'group_id','point_ids','parameter','c_index', ...
    'estimate','unit','wf_bias_relative_to_design_pct'});
end

function tbl = local_schedule_node_table(schedule)
record = repmat(struct('parameter', "", 'c_index', NaN, ...
    'axis_name', "", 'node_index', NaN, 'x', NaN, ...
    'effective_value', NaN, 'design_value', NaN, ...
    'zero_anchor', false, 'dll_execution_node', false, ...
    'dll_resampling_used', false), 0, 1);
for i = 1:numel(schedule.healthEntries)
    entry = schedule.healthEntries(i);
    for j = 1:numel(entry.xNodes)
        r = struct('parameter', string(entry.name), ...
            'c_index', entry.cIndex, 'axis_name', string(entry.axisName), ...
            'node_index', j, 'x', entry.xNodes(j), ...
            'effective_value', entry.kNodes(j), ...
            'design_value', entry.designValue, ...
            'zero_anchor', entry.pressureLoss && j == 1, ...
            'dll_execution_node', ~entry.dllResamplingUsed, ...
            'dll_resampling_used', entry.dllResamplingUsed);
        record(end + 1, 1) = r; %#ok<AGROW>
    end
    if entry.dllResamplingUsed
        for j = 1:numel(entry.xNodesDll)
            r = struct('parameter', string(entry.name) + "_DLL", ...
                'c_index', entry.cIndex, 'axis_name', string(entry.axisName), ...
                'node_index', j, 'x', entry.xNodesDll(j), ...
                'effective_value', entry.kNodesDll(j), ...
                'design_value', entry.designValue, ...
                'zero_anchor', entry.pressureLoss && j == 1, ...
                'dll_execution_node', true, ...
                'dll_resampling_used', true);
            record(end + 1, 1) = r; %#ok<AGROW>
        end
    end
end
for j = 1:numel(schedule.fuelBias.xNodes)
    r = struct('parameter', "Wf_measurement_bias", 'c_index', NaN, ...
        'axis_name', "measured_wf_ratio", 'node_index', j, ...
        'x', schedule.fuelBias.xNodes(j), ...
        'effective_value', schedule.fuelBias.biasNodes(j), ...
        'design_value', NaN, 'zero_anchor', false, ...
        'dll_execution_node', false, 'dll_resampling_used', false);
    record(end + 1, 1) = r; %#ok<AGROW>
end
tbl = struct2table(record);
end

function tbl = local_prediction_detail_table( ...
        route, data, baseline, finalPrediction, scales)
names = cellstr(scales.name);
record = repmat(struct('point_id', "", 'field', "", ...
    'measured', NaN, 'baseline_model', NaN, 'corrected_model', NaN, ...
    'baseline_error', NaN, 'corrected_error', NaN, ...
    'baseline_relative_error_pct', NaN, ...
    'corrected_relative_error_pct', NaN, ...
    'baseline_normalized_error', NaN, ...
    'corrected_normalized_error', NaN), ...
    height(data) * numel(names), 1);
cursor = 0;
for i = 1:height(data)
    for j = 1:numel(names)
        cursor = cursor + 1;
        target = local_target_vector(data(i, :), names{j});
        baselineError = baseline.(names{j})(i) - target;
        correctedError = finalPrediction.(names{j})(i) - target;
        record(cursor).point_id = data.point_id(i);
        record(cursor).field = string(names{j});
        record(cursor).measured = target;
        record(cursor).baseline_model = baseline.(names{j})(i);
        record(cursor).corrected_model = finalPrediction.(names{j})(i);
        record(cursor).baseline_error = baselineError;
        record(cursor).corrected_error = correctedError;
        if abs(target) > 1e-12
            record(cursor).baseline_relative_error_pct = ...
                baselineError / abs(target) * 100;
            record(cursor).corrected_relative_error_pct = ...
                correctedError / abs(target) * 100;
        end
        record(cursor).baseline_normalized_error = ...
            baselineError / scales.scale(j);
        record(cursor).corrected_normalized_error = ...
            correctedError / scales.scale(j);
    end
end
tbl = struct2table(record);
tbl.Properties.Description = [local_route_label(route) '模型输出对比'];
end

function local_write_result_excel(filePath, result)
if exist(filePath, 'file')
    delete(filePath);
end
writetable(result.parameterTable, filePath, 'Sheet', 'parameters');
writetable(result.groups(:, setdiff(result.groups.Properties.VariableNames, ...
    {'row_indices'})), filePath, 'Sheet', 'groups');
writetable(result.groupEstimateTable, filePath, 'Sheet', 'group_estimates');
writetable(result.scheduleNodeTable, filePath, 'Sheet', 'schedule_nodes');
writetable(result.stageA.history, filePath, 'Sheet', 'stageA_history');
writetable(result.stageRefine.history, filePath, 'Sheet', 'refine_history');
writetable(struct2table(result.timing), filePath, 'Sheet', 'timing');
writetable(result.baseline.trainingMetrics.byField, filePath, ...
    'Sheet', 'baseline_train_metric');
writetable(result.final.trainingMetrics.byField, filePath, ...
    'Sheet', 'final_train_metric');
writetable(result.predictionTrainingTable, filePath, ...
    'Sheet', 'training_prediction');
if result.input.testDataAvailable
    writetable(result.baseline.testMetrics.byField, filePath, ...
        'Sheet', 'baseline_test_metric');
    writetable(result.final.testMetrics.byField, filePath, ...
        'Sheet', 'final_test_metric');
    writetable(result.predictionTestTable, filePath, ...
        'Sheet', 'test_prediction');
end
local_write_steady_test_from_transient_excel( ...
    filePath, result.steadyTestFromTransient);
if isfield(result, 'inletPressureLossDirect') && ...
        ~isempty(fieldnames(result.inletPressureLossDirect))
    writetable(result.inletPressureLossDirect.trainingTable, filePath, ...
        'Sheet', 'inlet_kdp_training');
    inletNodeTable = table( ...
        result.inletPressureLossDirect.entry.xNodes, ...
        result.inletPressureLossDirect.entry.kNodes, ...
        'VariableNames', {'inlet_corrected_mass_flow','Inlet_K_dP'});
    writetable(inletNodeTable, filePath, 'Sheet', 'inlet_kdp_nodes');
end
end

function files = local_plot_result(result, paths, stamp)
files = strings(0, 1);
routeTag = local_route_tag(result.route);

fig1 = figure('Visible', result.options.figureVisible, ...
    'Color', 'w', 'Position', [100, 100, 1100, 480]);
fields = result.final.trainingMetrics.byField.field;
trainValues = [result.baseline.trainingMetrics.byField.normalized_rmse, ...
    result.final.trainingMetrics.byField.normalized_rmse];
if result.input.testDataAvailable
    subplot(1, 2, 1);
end
bar(trainValues);
set(gca, 'XTick', 1:numel(fields), 'XTickLabel', cellstr(fields));
xtickangle(35); grid on;
ylabel('归一化RMSE'); title('训练集');
legend({'零修正','估计修正'}, 'Location', 'best');
if result.input.testDataAvailable
    testValues = [result.baseline.testMetrics.byField.normalized_rmse, ...
        result.final.testMetrics.byField.normalized_rmse];
    subplot(1, 2, 2);
    bar(testValues);
    set(gca, 'XTick', 1:numel(fields), 'XTickLabel', cellstr(fields));
    xtickangle(35); grid on;
    ylabel('归一化RMSE'); title('独立测试集');
    legend({'零修正','估计修正'}, 'Location', 'best');
end
sgtitle([result.routeLabel '：模型修正前后输出误差']);
file1 = fullfile(paths.reportOutputDir, ...
    ['steady_model_adapt_v2_' routeTag '_' stamp '_prediction_error.png']);
saveas(fig1, file1); close(fig1);
files(end + 1, 1) = string(file1);

fig2 = figure('Visible', result.options.figureVisible, ...
    'Color', 'w', 'Position', [80, 40, 1250, 900]);
for i = 1:numel(result.finalSchedule.healthEntries)
    entry = result.finalSchedule.healthEntries(i);
    subplot(5, 2, i);
    plot(entry.xNodes, entry.kNodes, '-o', 'LineWidth', 1.3, ...
        'MarkerSize', 4);
    grid on; xlabel(strrep(entry.axisName, '_', '\_'));
    ylabel('K_{eff}'); title(sprintf('h%d %s', ...
        entry.cIndex, strrep(entry.name, '_', '\_')));
end
sgtitle([result.routeLabel '：10个估计健康调度函数']);
file2 = fullfile(paths.reportOutputDir, ...
    ['steady_model_adapt_v2_' routeTag '_' stamp '_health_schedules.png']);
saveas(fig2, file2); close(fig2);
files(end + 1, 1) = string(file2);

fig3 = figure('Visible', result.options.figureVisible, ...
    'Color', 'w', 'Position', [100, 100, 720, 460]);
plot(result.finalSchedule.fuelBias.xNodes, ...
    result.finalSchedule.fuelBias.biasNodes, '-o', ...
    'LineWidth', 1.5, 'MarkerSize', 5);
grid on; xlabel('Wf_{meas}/Wf_{des}'); ylabel('b_{Wf} (kg/s)');
title([result.routeLabel '：燃油测量偏置调度函数']);
file3 = fullfile(paths.reportOutputDir, ...
    ['steady_model_adapt_v2_' routeTag '_' stamp '_wf_bias_schedule.png']);
saveas(fig3, file3); close(fig3);
files(end + 1, 1) = string(file3);
end

function local_write_summary(filePath, result)
fid = fopen(filePath, 'w', 'n', 'UTF-8');
if fid < 0
    error('SHT:SteadyAdaptV2:SummaryWriteFailure', ...
        '无法写入摘要：%s。', filePath);
end
cleanupObject = onCleanup(@() fclose(fid));
fprintf(fid, '# 第二轮六部件稳态修正系数辨识结果摘要\n\n');
fprintf(fid, '- 路径：%s\n', result.routeLabel);
fprintf(fid, '- 生成时间：%s\n', result.createdAt);
fprintf(fid, '- 训练点/测试点：%d/%d\n', ...
    result.input.trainingPointCount, result.input.testPointCount);
fprintf(fid, '- AC转速分组数：%d\n', height(result.groups));
fprintf(fid, '- 阶段A正则化方法：%s\n', ...
    result.options.stageARegularizationMethod);
if strcmpi(result.options.stageARegularizationMethod, 'tsvd')
    fprintf(fid, '- 阶段A生效的TSVD步长模式：%s\n', ...
        result.options.stageATsvdStepMode);
    fprintf(fid, '- 阶段A截断/保留奇异方向：%d/%d\n', ...
        result.stageA.truncatedSingularValueCount, ...
        result.stageA.retainedSingularValueCount);
elseif strcmpi(result.options.stageARegularizationMethod, 'tikhonov')
    fprintf(fid, '- 阶段A生效的Tikhonov先验尺度统一倍率：%.8g\n', ...
        result.options.stageATikhonovPriorScale);
end
fprintf(fid, '- 阶段B正则化方法：%s\n', ...
    result.options.stageBRegularizationMethod);
if strcmpi(result.options.stageBRegularizationMethod, 'tikhonov')
    fprintf(fid, '- 阶段B生效的Tikhonov先验尺度统一倍率：%.8g\n', ...
        result.options.stageBTikhonovPriorScale);
elseif strcmpi(result.options.stageBRegularizationMethod, 'tsvd')
    fprintf(fid, '- 阶段B生效的无阻尼TSVD保留奇异方向：%d\n', ...
        result.options.stageBTsvdRetainedCount);
end
fprintf(fid, '- 阶段D正则化方法：%s\n', ...
    result.options.stageDRegularizationMethod);
if strcmpi(result.options.stageDRegularizationMethod, 'tikhonov')
    fprintf(fid, '- 阶段D生效的Tikhonov先验尺度统一倍率：%.8g\n', ...
        result.options.stageDTikhonovPriorScale);
elseif strcmpi(result.options.stageDRegularizationMethod, 'tsvd')
    fprintf(fid, '- 阶段D生效的无阻尼TSVD保留奇异方向：%d\n', ...
        result.options.stageDTsvdRetainedCount);
end
fprintf(fid, '- 阶段D最大迭代次数：%d\n', ...
    result.options.maxIterationRefine);
fprintf(fid, '- 阶段D差分步长倍率：%.8g\n', ...
    result.options.stageDDifferenceStepScale);
fprintf(fid, '- 阶段D初值偏移二范数：%.8g\n', ...
    norm(result.stageRefine.initialOffset));
fprintf(fid, '- 阶段A代价：%.8g -> %.8g\n', ...
    result.stageA.costInitial, result.stageA.costFinal);
fprintf(fid, '- 联合微调代价：%.8g -> %.8g\n', ...
    result.stageRefine.costInitial, result.stageRefine.costFinal);
fprintf(fid, '- 辨识与验证计算耗时：%.3f s\n', ...
    result.timing.estimationSeconds);
fprintf(fid, '- 训练集总体NRMS：%.8g -> %.8g\n', ...
    result.baseline.trainingMetrics.overall_nrms, ...
    result.final.trainingMetrics.overall_nrms);
if result.input.testDataAvailable
    fprintf(fid, '- 测试集总体NRMS：%.8g -> %.8g\n', ...
        result.baseline.testMetrics.overall_nrms, ...
        result.final.testMetrics.overall_nrms);
else
    fprintf(fid, '- 测试集：未在参数辨识入口中读取\n');
end
if result.steadyTestFromTransient.performed
    fprintf(fid, ['- 测试集额外稳态模型NRMS（以对应瞬态收敛解为初值）：' ...
        '%.8g -> %.8g\n'], ...
        result.steadyTestFromTransient.baseline.steadyMetrics.overall_nrms, ...
        result.steadyTestFromTransient.corrected.steadyMetrics.overall_nrms);
    fprintf(fid, '- 额外稳态模型零修正/估计修正回放有效：%d/%d\n', ...
        result.steadyTestFromTransient.baseline.steadyValid, ...
        result.steadyTestFromTransient.corrected.steadyValid);
end
if result.input.testDataAvailable
    fprintf(fid, '- 训练/测试有效：%d/%d\n\n', ...
        result.final.trainingValid, result.final.testValid);
else
    fprintf(fid, '- 训练有效：%d\n\n', result.final.trainingValid);
end
fprintf(fid, '- A/B/D阶段收敛：%d/%d/%d\n', ...
    result.acceptance.stageAConverged, ...
    result.acceptance.stageBAllConverged, ...
    result.acceptance.stageDConverged);
fprintf(fid, '- 正式验收状态：%d\n\n', ...
    result.acceptance.formalAccepted);
fprintf(fid, '参数估计程序未读取隐藏真值。参数真值和燃油偏置真值只能由独立对比程序读取。\n');
clear cleanupObject;
end

function output = local_evaluate_saved_schedule(result, data)
% 供后续公开数据回放使用；不读取另一条路径或隐藏真值。
if ~isstruct(result) || ~isfield(result, 'finalSchedule')
    error('SHT:SteadyAdaptV2:BadSavedResult', ...
        'result不包含可用finalSchedule。');
end
options = local_complete_options(result.options, result.route);
cfg = sht_default_config(struct('engine', struct('modelMode', 1)));
engine = sht_engine_open(cfg.engine);
cleanupObject = onCleanup(@() sht_engine_close(engine));
[prediction, valid] = local_evaluate_dataset(result.route, engine, cfg, ...
    data, local_schedule_model(result.finalSchedule), options);
output = struct('prediction', prediction, 'valid', valid);
clear cleanupObject;
end

function output = local_evaluate_saved_constant(result, data)
%LOCAL_EVALUATE_SAVED_CONSTANT 独立回放已保存的阶段A常值估计。
% 该接口只使用result.stageA和公开测量表，不读取隐藏真值，也不使用
% 阶段B/D结果，便于在调整阶段A正则化后直接评价训练集或测试集。
if ~isstruct(result) || ~isfield(result, 'stageA') || ...
        ~isfield(result.stageA, 'x') || ...
        ~isfield(result, 'parameterDefinition')
    error('SHT:SteadyAdaptV2:BadStageAResult', ...
        'result不包含可用于常值回放的stageA和parameterDefinition。');
end
parameters = result.parameterDefinition;
x = result.stageA.x(:);
if numel(x) ~= height(parameters) + 1
    error('SHT:SteadyAdaptV2:BadStageAParameterCount', ...
        'stageA参数数目%d与定义数目%d不一致。', ...
        numel(x), height(parameters) + 1);
end
options = local_complete_options(result.options, result.route);
cfg = sht_default_config(struct('engine', struct('modelMode', 1)));
engine = sht_engine_open(cfg.engine);
cleanupObject = onCleanup(@() sht_engine_close(engine));
model = local_constant_model(parameters, x(1:height(parameters)), x(end));
[prediction, valid] = local_evaluate_dataset(result.route, engine, cfg, ...
    data, model, options);
output = struct('prediction', prediction, 'valid', valid);
clear cleanupObject;
end

function output = local_evaluate_offset_batch( ...
        result, trainingData, testData, offsetMatrix)
%LOCAL_EVALUATE_OFFSET_BATCH 批量精确回放最终调度附近的参数偏移。
% 每列offsetMatrix表示相对result.finalSchedule的11维增量。DLL在整批
% 候选间只打开一次，避免工程可辨识性验证重复加载库和配置环境。
required = {'route','options','parameterDefinition','finalSchedule'};
if ~isstruct(result) || ~all(isfield(result, required))
    error('SHT:SteadyAdaptV2:BadOffsetBatchResult', ...
        'result缺少批量偏移回放所需字段。');
end
local_validate_input_table(trainingData, '批量回放训练集');
local_validate_input_table(testData, '批量回放测试集');
parameters = result.parameterDefinition;
parameterCount = height(parameters) + 1;
if ~isnumeric(offsetMatrix) || size(offsetMatrix, 1) ~= parameterCount || ...
        any(~isfinite(offsetMatrix(:)))
    error('SHT:SteadyAdaptV2:BadOffsetMatrix', ...
        'offsetMatrix必须为%d行的有限数值矩阵。', parameterCount);
end

options = local_complete_options(result.options, result.route);
% 批量回放只评价候选，不触发正式结果保存门控。
options.requireConvergedStages = false;
options.requireValidFinalReplay = false;
cfg = sht_default_config(struct('engine', struct('modelMode', 1)));
engine = sht_engine_open(cfg.engine);
cleanupObject = onCleanup(@() sht_engine_close(engine));

candidateCount = size(offsetMatrix, 2);
candidate = repmat(struct('offset', [], 'schedule', struct(), ...
    'trainingPrediction', table(), 'trainingValid', false, ...
    'testPrediction', table(), 'testValid', false), candidateCount, 1);
for i = 1:candidateCount
    schedule = local_apply_schedule_offsets( ...
        result.finalSchedule, offsetMatrix(:, i), parameters);
    model = local_schedule_model(schedule);
    [trainingPrediction, trainingValid] = local_evaluate_dataset( ...
        result.route, engine, cfg, trainingData, model, options);
    [testPrediction, testValid] = local_evaluate_dataset( ...
        result.route, engine, cfg, testData, model, options);
    candidate(i).offset = offsetMatrix(:, i);
    candidate(i).schedule = schedule;
    candidate(i).trainingPrediction = trainingPrediction;
    candidate(i).trainingValid = trainingValid;
    candidate(i).testPrediction = testPrediction;
    candidate(i).testValid = testValid;
end
output = struct('route', result.route, ...
    'parameterCount', parameterCount, ...
    'candidateCount', candidateCount, 'candidate', candidate);
clear cleanupObject;
end

function output = local_evaluate_offset_batch_dataset(result, data, offsetMatrix)
%LOCAL_EVALUATE_OFFSET_BATCH_DATASET 只对一个显式给定的数据集批量回放。
% 该接口用于2.4贝叶斯不确定性量化。推断阶段只传入训练集，避免原批量
% 接口在每个候选处顺带计算测试集而造成信息泄漏和无效DLL开销。
required = {'route','options','parameterDefinition','finalSchedule'};
if ~isstruct(result) || ~all(isfield(result, required))
    error('SHT:SteadyAdaptV2:BadDatasetBatchResult', ...
        'result缺少单数据集批量偏移回放所需字段。');
end
local_validate_input_table(data, '单数据集批量回放输入');
parameters = result.parameterDefinition;
parameterCount = height(parameters) + 1;
if ~isnumeric(offsetMatrix) || size(offsetMatrix, 1) ~= parameterCount || ...
        any(~isfinite(offsetMatrix(:)))
    error('SHT:SteadyAdaptV2:BadDatasetOffsetMatrix', ...
        'offsetMatrix必须为%d行的有限数值矩阵。', parameterCount);
end

options = local_complete_options(result.options, result.route);
options.requireConvergedStages = false;
options.requireValidFinalReplay = false;
cfg = sht_default_config(struct('engine', struct('modelMode', 1)));
engine = sht_engine_open(cfg.engine);
cleanupObject = onCleanup(@() sht_engine_close(engine));

candidateCount = size(offsetMatrix, 2);
candidate = repmat(struct('offset', [], 'schedule', struct(), ...
    'prediction', table(), 'valid', false), candidateCount, 1);
for i = 1:candidateCount
    schedule = local_apply_schedule_offsets( ...
        result.finalSchedule, offsetMatrix(:, i), parameters);
    model = local_schedule_model(schedule);
    [prediction, valid] = local_evaluate_dataset( ...
        result.route, engine, cfg, data, model, options);
    candidate(i).offset = offsetMatrix(:, i);
    candidate(i).schedule = schedule;
    candidate(i).prediction = prediction;
    candidate(i).valid = valid;
end
output = struct('route', result.route, ...
    'parameterCount', parameterCount, 'pointCount', height(data), ...
    'candidateCount', candidateCount, 'candidate', candidate);
clear cleanupObject;
end

function output = local_evaluate_schedule_batch_dataset( ...
        result, data, schedules, batchOptions)
%LOCAL_EVALUATE_SCHEDULE_BATCH_DATASET 批量回放显式给定的完整调度结构。
% 该接口服务节点级贝叶斯UQ。调度节点由上游概率合同恢复，本函数只负责
% 在一次DLL加载中逐候选精确回放，不解释参数向量，也不读取隐藏真值。
if nargin < 4 || isempty(batchOptions)
    batchOptions = struct();
end
required = {'route','options','parameterDefinition','finalSchedule'};
if ~isstruct(result) || ~all(isfield(result, required))
    error('SHT:SteadyAdaptV2:BadScheduleBatchResult', ...
        'result缺少完整调度批量回放所需字段。');
end
local_validate_input_table(data, '完整调度批量回放输入');
if iscell(schedules)
    if isempty(schedules) || ~all(cellfun(@isstruct, schedules))
        error('SHT:SteadyAdaptV2:BadScheduleBatch', ...
            'schedules元胞必须非空且每个元素均为调度结构。');
    end
    scheduleCell = schedules(:);
elseif isstruct(schedules) && ~isempty(schedules)
    scheduleCell = arrayfun(@(item) item, schedules(:), ...
        'UniformOutput', false);
else
    error('SHT:SteadyAdaptV2:BadScheduleBatch', ...
        'schedules必须为非空结构数组或结构元胞数组。');
end

evaluationRoute = result.route;
if isfield(batchOptions,'routeOverride') && ...
        ~isempty(batchOptions.routeOverride)
    evaluationRoute = local_validate_route(batchOptions.routeOverride);
end
options = local_complete_options(result.options, evaluationRoute);
options.requireConvergedStages = false;
options.requireValidFinalReplay = false;
if isfield(batchOptions, 'useRobustTransientFallback') && ...
        ~isempty(batchOptions.useRobustTransientFallback)
    value = batchOptions.useRobustTransientFallback;
    if ~islogical(value) || ~isscalar(value)
        error('SHT:SteadyAdaptV2:BadBatchTransientFallbackSwitch', ...
            '批量回放useRobustTransientFallback必须为逻辑标量。');
    end
    options.useRobustTransientFallback = value;
end
if isfield(batchOptions, 'maxModelResidual') && ...
        ~isempty(batchOptions.maxModelResidual)
    value = batchOptions.maxModelResidual;
    if ~isnumeric(value) || ~isscalar(value) || ...
            ~isfinite(value) || value <= 0
        error('SHT:SteadyAdaptV2:BadBatchResidualThreshold', ...
            '批量回放maxModelResidual必须为有限正标量。');
    end
    options.maxModelResidual = value;
end
if isfield(batchOptions, 'steadyLoadBoundaryMode') && ...
        ~isempty(batchOptions.steadyLoadBoundaryMode)
    value = lower(string(batchOptions.steadyLoadBoundaryMode));
    if ~isscalar(value) || ~ismember(value, ["fixed_power", "torque"])
        error('SHT:SteadyAdaptV2:BadBatchSteadyLoadBoundaryMode', ...
            '批量回放steadyLoadBoundaryMode必须为fixed_power或torque。');
    end
    options.steadyLoadBoundaryMode = char(value);
end
cfg = sht_default_config(struct('engine', struct('modelMode', 1)));
engine = sht_engine_open(cfg.engine);
cleanupObject = onCleanup(@() sht_engine_close(engine));

candidateCount = numel(scheduleCell);
initialSeed = repmat({[]}, candidateCount, 1);
if isfield(batchOptions, 'initialSeedMatrices') && ...
        ~isempty(batchOptions.initialSeedMatrices)
    seedInput = batchOptions.initialSeedMatrices;
    if isnumeric(seedInput)
        if ~isequal(size(seedInput), [height(data), 9]) || ...
                any(~isfinite(seedInput(:)))
            error('SHT:SteadyAdaptV2:BadSharedBatchSeed', ...
                '共享批量初值必须为测试点数x9的有限矩阵。');
        end
        initialSeed(:) = {seedInput};
    elseif iscell(seedInput) && numel(seedInput) == candidateCount
        for i = 1:candidateCount
            value = seedInput{i};
            if ~isequal(size(value), [height(data), 9]) || ...
                    any(~isfinite(value(:)))
                error('SHT:SteadyAdaptV2:BadCandidateBatchSeed', ...
                    '候选%d的批量初值必须为测试点数x9的有限矩阵。', i);
            end
            initialSeed{i} = value;
        end
    else
        error('SHT:SteadyAdaptV2:BadBatchSeedContainer', ...
            ['initialSeedMatrices必须为共享测试点数x9矩阵，或与候选数' ...
             '一致的矩阵元胞数组。']);
    end
end
candidate = repmat(struct('schedule', struct(), ...
    'prediction', table(), 'valid', false, ...
    'diagnostic', struct()), candidateCount, 1);
for i = 1:candidateCount
    schedule = scheduleCell{i};
    if ~isfield(schedule, 'healthEntries') || ...
            ~isfield(schedule, 'fuelBias') || ~isfield(schedule, 'h15')
        error('SHT:SteadyAdaptV2:IncompleteSchedule', ...
            '候选%d不是完整的健康参数调度结构。', i);
    end
    model = local_schedule_model(schedule);
    [prediction, valid, diagnostic] = local_evaluate_dataset( ...
        evaluationRoute, engine, cfg, data, model, options, initialSeed{i});
    candidate(i).schedule = schedule;
    candidate(i).prediction = prediction;
    candidate(i).valid = valid;
    candidate(i).diagnostic = diagnostic;
end
output = struct('route', evaluationRoute, ...
    'pointCount', height(data), 'candidateCount', candidateCount, ...
    'robustTransientFallbackEnabled', ...
    options.useRobustTransientFallback, ...
    'candidate', candidate);
clear cleanupObject;
end

function output = local_evaluate_dataset_variants( ...
        result, dataVariants, offset, variantOptions)
%LOCAL_EVALUATE_DATASET_VARIANTS 在一次DLL加载内回放多份数据扰动。
% 每个元胞是一份满足2.4输入合同的数据表，所有变体使用同一组11维
% 参数偏移。可通过variantOptions显式指定回放路径和共同工作初值；
% 省略该参数时保持原有行为。该接口专门服务输入误差有限差分传播。
if nargin < 4 || isempty(variantOptions)
    variantOptions = struct();
end
if ~isstruct(variantOptions) || ~isscalar(variantOptions)
    error('SHT:SteadyAdaptV2:BadVariantOptions', ...
        'variantOptions必须为标量结构体。');
end
required = {'route','options','parameterDefinition','finalSchedule'};
if ~isstruct(result) || ~all(isfield(result, required))
    error('SHT:SteadyAdaptV2:BadVariantResult', ...
        'result缺少数据变体回放所需字段。');
end
if ~iscell(dataVariants) || isempty(dataVariants)
    error('SHT:SteadyAdaptV2:BadDataVariants', ...
        'dataVariants必须是非空表格元胞数组。');
end
parameters = result.parameterDefinition;
parameterCount = height(parameters) + 1;
if ~isnumeric(offset) || numel(offset) ~= parameterCount || ...
        any(~isfinite(offset(:)))
    error('SHT:SteadyAdaptV2:BadVariantOffset', ...
        'offset必须为%d维有限向量。', parameterCount);
end
for i = 1:numel(dataVariants)
    local_validate_input_table(dataVariants{i}, sprintf('数据变体%d', i));
end

evaluationRoute = result.route;
if isfield(variantOptions, 'routeOverride') && ...
        ~isempty(variantOptions.routeOverride)
    evaluationRoute = local_validate_route(variantOptions.routeOverride);
end
options = local_complete_options(result.options, evaluationRoute);
options.requireConvergedStages = false;
options.requireValidFinalReplay = false;
if isfield(variantOptions, 'useRobustTransientFallback') && ...
        ~isempty(variantOptions.useRobustTransientFallback)
    value = variantOptions.useRobustTransientFallback;
    if ~islogical(value) || ~isscalar(value)
        error('SHT:SteadyAdaptV2:BadVariantFallbackSwitch', ...
            '数据变体useRobustTransientFallback必须为逻辑标量。');
    end
    options.useRobustTransientFallback = value;
end
if isfield(variantOptions, 'maxModelResidual') && ...
        ~isempty(variantOptions.maxModelResidual)
    value = variantOptions.maxModelResidual;
    if ~isnumeric(value) || ~isscalar(value) || ...
            ~isfinite(value) || value <= 0
        error('SHT:SteadyAdaptV2:BadVariantResidualThreshold', ...
            '数据变体maxModelResidual必须为有限正标量。');
    end
    options.maxModelResidual = value;
end
if isfield(variantOptions, 'steadyLoadBoundaryMode') && ...
        ~isempty(variantOptions.steadyLoadBoundaryMode)
    value = lower(string(variantOptions.steadyLoadBoundaryMode));
    if ~isscalar(value) || ~ismember(value, ["fixed_power", "torque"])
        error('SHT:SteadyAdaptV2:BadVariantSteadyLoadBoundaryMode', ...
            '数据变体steadyLoadBoundaryMode必须为fixed_power或torque。');
    end
    options.steadyLoadBoundaryMode = char(value);
end
initialSeedMatrix = [];
if isfield(variantOptions, 'initialSeedMatrix') && ...
        ~isempty(variantOptions.initialSeedMatrix)
    initialSeedMatrix = variantOptions.initialSeedMatrix;
    if ~isnumeric(initialSeedMatrix) || ...
            ~isequal(size(initialSeedMatrix), [height(dataVariants{1}), 9]) || ...
            any(~isfinite(initialSeedMatrix(:)))
        error('SHT:SteadyAdaptV2:BadVariantInitialSeed', ...
            '数据变体共同工作初值必须为测试点数x9的有限矩阵。');
    end
end
cfg = sht_default_config(struct('engine', struct('modelMode', 1)));
engine = sht_engine_open(cfg.engine);
cleanupObject = onCleanup(@() sht_engine_close(engine));
schedule = local_apply_schedule_offsets( ...
    result.finalSchedule, offset(:), parameters);
model = local_schedule_model(schedule);

variant = repmat(struct('prediction', table(), 'valid', false, ...
    'diagnostic', struct()), ...
    numel(dataVariants), 1);
for i = 1:numel(dataVariants)
    [variant(i).prediction, variant(i).valid, variant(i).diagnostic] = ...
        local_evaluate_dataset(evaluationRoute, engine, cfg, ...
        dataVariants{i}, model, options, initialSeedMatrix);
end
output = struct('route', evaluationRoute, ...
    'variantCount', numel(dataVariants), ...
    'offset', offset(:), 'variant', variant);
clear cleanupObject;
end

function output = local_validate_saved_schedule(result, testData)
%LOCAL_VALIDATE_SAVED_SCHEDULE 用冻结辨识结果独立验证真实测试集。
% 测试数据只用于回放和误差统计，不参与参数更新，也不读取参数真值。
requiredResult = {'route','options','parameterDefinition', ...
    'finalSchedule','residualScales'};
if ~isstruct(result) || ~all(isfield(result, requiredResult))
    error('SHT:SteadyAdaptV2:BadValidationResult', ...
        '辨识结果缺少测试验证所需字段。');
end
local_validate_input_table(testData, '测试集');

options = local_complete_options(result.options, result.route);
options.requireConvergedStages = false;
options.requireValidFinalReplay = false;
options.evaluateTestSet = false;
options.fuelInputSemantics = 'measured';
cfg = sht_default_config(struct('engine', struct('modelMode', 1)));
engine = sht_engine_open(cfg.engine);
cleanupObject = onCleanup(@() sht_engine_close(engine));

zeroModel = local_constant_model(result.parameterDefinition, ...
    zeros(height(result.parameterDefinition), 1), 0);
finalModel = local_schedule_model(result.finalSchedule);
[baselinePrediction, baselineValid, baselineDiagnostic] = ...
    local_evaluate_dataset(result.route, engine, cfg, testData, ...
    zeroModel, options);
[correctedPrediction, correctedValid, correctedDiagnostic] = ...
    local_evaluate_dataset(result.route, engine, cfg, testData, ...
    finalModel, options);

baselineMetrics = local_dataset_metrics(result.route, testData, ...
    baselinePrediction, result.residualScales);
correctedMetrics = local_dataset_metrics(result.route, testData, ...
    correctedPrediction, result.residualScales);
predictionTable = local_prediction_detail_table(result.route, testData, ...
    baselinePrediction, correctedPrediction, result.residualScales);

steadyFromTransient = struct('performed', false, ...
    'skipReason', "辨识结果不是瞬态时刻路径", ...
    'initializationSource', "", 'residualScales', table(), ...
    'baseline', struct(), 'corrected', struct(), ...
    'predictionTable', table(), 'seedTransferTable', table());
if strcmp(result.route, 'transient_instant')
    trainingData = table();
    if isfield(result, 'input') && isfield(result.input, 'trainingFile') && ...
            exist(result.input.trainingFile, 'file') == 2
        trainingData = local_read_measurement_table( ...
            result.input.trainingFile, '原辨识训练集');
    end
    if isempty(trainingData)
        steadyFromTransient.skipReason = ...
            "找不到原辨识训练集，不能冻结稳态误差归一化尺度";
    else
        steadyOptions = options;
        steadyOptions.evaluateSteadyTestFromTransient = true;
        steadyFromTransient = local_evaluate_transient_test_as_steady( ...
            result.route, engine, cfg, trainingData, testData, ...
            zeroModel, finalModel, steadyOptions, ...
            baselineDiagnostic, correctedDiagnostic);
        steadyFromTransient.skipReason = "";
    end
end

output = struct();
output.schemaVersion = 'SHT_STEADY_MODEL_TEST_VALIDATION_V1';
output.route = result.route;
output.createdAt = datestr(now, 31);
output.testData = testData;
output.baseline = struct('prediction', baselinePrediction, ...
    'valid', baselineValid, 'metrics', baselineMetrics, ...
    'diagnostic', baselineDiagnostic);
output.corrected = struct('prediction', correctedPrediction, ...
    'valid', correctedValid, 'metrics', correctedMetrics, ...
    'diagnostic', correctedDiagnostic);
output.predictionTable = predictionTable;
output.steadyFromTransient = steadyFromTransient;
output.testDataUsedForInference = false;
output.truthWasRead = false;
output.passed = correctedValid && ...
    (~steadyFromTransient.performed || ...
    steadyFromTransient.corrected.steadyValid);
clear cleanupObject;
end

function output = local_predict_saved_schedule(result, predictionInput)
%LOCAL_PREDICT_SAVED_SCHEDULE 对指定物理输入执行无测量输出稳态预测。
% Wf_model是模型物理输入，不应用辨识得到的燃油传感器偏置；修正系数
% 调度和进气道压损调度仍使用冻结的最终个体模型。
requiredResult = {'options','parameterDefinition','finalSchedule'};
if ~isstruct(result) || ~all(isfield(result, requiredResult))
    error('SHT:SteadyAdaptV2:BadPredictionResult', ...
        '辨识结果缺少输入驱动预测所需字段。');
end

cfg = sht_default_config(struct('engine', struct('modelMode', 1)));
[inputTable, internalData, inletBoundaryMode] = local_normalize_prediction_input( ...
    predictionInput, cfg);
options = local_complete_options(result.options, 'steady');
options.inletBoundaryMode = inletBoundaryMode;
options.steadyLoadBoundaryMode = 'torque';
options.fuelInputSemantics = 'physical_model';
options.evaluateTestSet = false;
options.evaluateSteadyTestFromTransient = false;
options.requireConvergedStages = false;
options.requireValidFinalReplay = false;

engine = sht_engine_open(cfg.engine);
cleanupObject = onCleanup(@() sht_engine_close(engine));
zeroModel = local_constant_model(result.parameterDefinition, ...
    zeros(height(result.parameterDefinition), 1), 0);
finalModel = local_schedule_model(result.finalSchedule);
[baselinePrediction, baselineValid, baselineDiagnostic] = ...
    local_evaluate_dataset('steady', engine, cfg, internalData, ...
    zeroModel, options);
[correctedPrediction, correctedValid, correctedDiagnostic] = ...
    local_evaluate_dataset('steady', engine, cfg, internalData, ...
    finalModel, options);

predictionTable = local_input_driven_prediction_table( ...
    inputTable, baselinePrediction, correctedPrediction);
output = struct();
output.schemaVersion = 'SHT_STEADY_INPUT_DRIVEN_PREDICTION_V2';
output.createdAt = datestr(now, 31);
if inletBoundaryMode == 2
    requiredFields = {'Pamb','Tamb','Mach','Wf_model','Mkp','Mkg'};
    optionalFields = {'point_id','Altitude','Np_initial','Ng_initial', ...
        'inletBoundaryMode'};
    environmentDefinition = 'Pamb_Tamb_Mach';
else
    requiredFields = {'Altitude','Tamb','Mach','Wf_model','Mkp','Mkg'};
    optionalFields = {'point_id','Np_initial','Ng_initial', ...
        'inletBoundaryMode'};
    environmentDefinition = 'Altitude_Tamb_Mach';
end
output.inputContract = struct( ...
    'requiredFields', {requiredFields}, ...
    'optionalFields', {optionalFields}, ...
    'inletBoundaryMode', inletBoundaryMode, ...
    'environmentDefinition', environmentDefinition, ...
    'altitudeUsedForAtmosphere', inletBoundaryMode == 3, ...
    'ambientPressureProvided', inletBoundaryMode == 2, ...
    'fuelInputSemantics', 'physical_model', ...
    'controlLoopUsed', false);
output.input = inputTable;
% 后验传播需要与确定性预测完全一致的内部工况表。该表只包含用户
% 指定边界及数值求解初值，不包含测量输出或参数真值。
output.internalData = internalData;
output.baseline = struct('prediction', baselinePrediction, ...
    'valid', baselineValid, 'diagnostic', baselineDiagnostic);
output.corrected = struct('prediction', correctedPrediction, ...
    'valid', correctedValid, 'diagnostic', correctedDiagnostic);
output.predictionTable = predictionTable;
output.measurementDataUsed = false;
output.truthWasRead = false;
output.passed = correctedValid;
clear cleanupObject;
end

function [inputTable, internalData, inletBoundaryMode] = ...
        local_normalize_prediction_input(input, cfg)
if isstruct(input) && isscalar(input)
    input = struct2table(input, 'AsArray', true);
end
if ~istable(input) || height(input) < 1
    error('SHT:SteadyAdaptV2:BadPredictionInput', ...
        '预测输入必须是非空表或标量结构体。');
end

n = height(input);
names = input.Properties.VariableNames;
hasExplicitMode = ismember('inletBoundaryMode', names);
hasPamb = ismember('Pamb', names);
hasAltitude = ismember('Altitude', names);
if hasExplicitMode
    modeValue = input.inletBoundaryMode;
    if ~isnumeric(modeValue) || ~iscolumn(modeValue) || ...
            numel(modeValue) ~= n || any(~isfinite(modeValue)) || ...
            any(modeValue ~= round(modeValue)) || ...
            any(~ismember(modeValue, [2, 3])) || numel(unique(modeValue)) ~= 1
        error('SHT:SteadyAdaptV2:BadPredictionInletMode', ...
            'inletBoundaryMode必须为整列一致的2或3。');
    end
    inletBoundaryMode = double(modeValue(1));
elseif hasPamb && ~hasAltitude
    inletBoundaryMode = 2;
elseif hasAltitude && ~hasPamb
    inletBoundaryMode = 3;
elseif hasPamb && hasAltitude
    error('SHT:SteadyAdaptV2:AmbiguousPredictionInletMode', ...
        ['预测输入同时包含Pamb和Altitude。请显式给定' ...
         'inletBoundaryMode=2或3，避免环境定义歧义。']);
else
    error('SHT:SteadyAdaptV2:MissingPredictionEnvironment', ...
        '预测输入必须给定Pamb（模式2）或Altitude（模式3）。');
end

commonRequired = {'Tamb','Mach','Wf_model','Mkp','Mkg'};
if inletBoundaryMode == 2
    required = [{'Pamb'}, commonRequired];
else
    required = [{'Altitude'}, commonRequired];
end
missing = setdiff(required, input.Properties.VariableNames);
if ~isempty(missing)
    error('SHT:SteadyAdaptV2:BadPredictionSchema', ...
        '预测输入缺少字段：%s。', strjoin(missing, ', '));
end
for i = 1:numel(required)
    value = input.(required{i});
    if ~isnumeric(value) || ~iscolumn(value) || numel(value) ~= n || ...
            any(~isfinite(value))
        error('SHT:SteadyAdaptV2:BadPredictionValue', ...
            '预测输入字段%s必须是有限数值列。', required{i});
    end
end
if any(input.Tamb <= 0 | input.Wf_model <= 0 | ...
        input.Mach < 0 | input.Mkp < 0 | input.Mkg < 0) || ...
        (inletBoundaryMode == 2 && any(input.Pamb <= 0))
    error('SHT:SteadyAdaptV2:PredictionInputOutOfRange', ...
        ['Tamb、Wf_model必须为正，Mach、Mkp和Mkg必须非负；' ...
         '模式2的Pamb还必须为正。']);
end

if ~ismember('point_id', input.Properties.VariableNames)
    input.point_id = "PRED_" + compose('%03d', (1:n).');
else
    input.point_id = string(input.point_id);
end
if numel(unique(input.point_id)) ~= n
    error('SHT:SteadyAdaptV2:DuplicatePredictionPointId', ...
        '预测输入point_id必须唯一。');
end
input = local_add_optional_prediction_column(input, 'Altitude', zeros(n, 1));
input = local_add_optional_prediction_column(input, 'Pamb', nan(n, 1));
input = local_add_optional_prediction_column(input, 'Np_initial', ...
    repmat(cfg.engine.initial.Np0, n, 1));
input = local_add_optional_prediction_column(input, 'Ng_initial', ...
    repmat(cfg.engine.initial.Ng0, n, 1));

optionalNumeric = {'Altitude','Np_initial','Ng_initial'};
for i = 1:numel(optionalNumeric)
    value = input.(optionalNumeric{i});
    if ~isnumeric(value) || ~iscolumn(value) || numel(value) ~= n || ...
            any(~isfinite(value))
        error('SHT:SteadyAdaptV2:BadPredictionOptionalValue', ...
            '预测输入字段%s必须是有限数值列。', optionalNumeric{i});
    end
end
if any(input.Np_initial <= 0 | input.Ng_initial <= 0)
    error('SHT:SteadyAdaptV2:BadPredictionInitialSpeed', ...
        'Np_initial和Ng_initial必须为正。');
end
input.inletBoundaryMode = repmat(inletBoundaryMode, n, 1);

internalData = table(input.point_id, input.Np_initial, input.Ng_initial, ...
    input.Wf_model, nan(n,1), nan(n,1), input.Mkp, input.Mkg, ...
    nan(n,1), nan(n,1), nan(n,1), nan(n,1), input.Pamb, input.Tamb, ...
    input.Altitude, input.Mach, ...
    'VariableNames', {'point_id','Np_mean','Ng_mean','Wf_mean', ...
    'Tt45_mean','Pt45_mean','Mkp_mean','Mkg_mean','Pt2_mean', ...
    'Tt1_mean','Pt3_mean','Tt3_mean','Pamb_mean','Tamb_mean', ...
    'Altitude_mean','Mach_mean'});
inputTable = input(:, {'point_id','inletBoundaryMode','Altitude','Pamb','Tamb','Mach', ...
    'Wf_model','Mkp','Mkg','Np_initial','Ng_initial'});
end

function tbl = local_add_optional_prediction_column(tbl, name, defaultValue)
if ~ismember(name, tbl.Properties.VariableNames)
    tbl.(name) = defaultValue;
end
end

function tbl = local_input_driven_prediction_table( ...
        input, baseline, corrected)
tbl = table(input.point_id, input.inletBoundaryMode, input.Altitude, ...
    input.Pamb, input.Tamb, input.Mach, input.Wf_model, input.Mkp, input.Mkg, ...
    baseline.Np, corrected.Np, baseline.Ng, corrected.Ng, ...
    corrected.Pamb, corrected.Tamb, corrected.Tt1, ...
    corrected.Pt1_internal, corrected.Pt2, ...
    corrected.Pt3, corrected.Tt3, corrected.Tt45, corrected.Pt45, ...
    corrected.max_model_residual, corrected.return_code, ...
    corrected.converge_tag, corrected.valid, corrected.error_message, ...
    'VariableNames', {'point_id','inlet_boundary_mode','Altitude_m', ...
    'input_Pamb_Pa','input_Tamb_K','Mach','Wf_model_kg_s','Mkp_Nm','Mkg_Nm','baseline_Np_rpm', ...
    'corrected_Np_rpm','baseline_Ng_rpm','corrected_Ng_rpm', ...
    'model_Pamb_Pa','model_Tamb_K','corrected_Tt1_K', ...
    'corrected_Pt1_Pa','corrected_Pt2_Pa', ...
    'corrected_Pt3_Pa','corrected_Tt3_K','corrected_Tt45_K', ...
    'corrected_Pt45_Pa','max_model_residual','return_code', ...
    'converge_tag','valid','error_message'});
end
