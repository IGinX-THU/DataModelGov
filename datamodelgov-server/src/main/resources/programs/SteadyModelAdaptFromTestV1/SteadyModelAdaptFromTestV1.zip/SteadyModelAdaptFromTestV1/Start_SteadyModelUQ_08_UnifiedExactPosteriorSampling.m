function result = Start_SteadyModelUQ_08_UnifiedExactPosteriorSampling(userCfg)
%START_STEADYMODELUQ_08_UNIFIEDEXACTPOSTERIORSAMPLING 正式精确SMC后验。
% 从零中心相关先验逐层升温，不预设单峰或正态。阶段D和先导结果只
% 用于防御性独立提议及pCN尺度，不进入先验，也不替代精确DLL似然。

if nargin < 1, userCfg = struct(); end
timer = tic;
manifest = sht_steady_model_uq_io('resolve',userCfg);
step1 = sht_steady_model_uq_io('loadstep',manifest,1);
step5 = sht_steady_model_uq_io('loadstep',manifest,5);
step6 = sht_steady_model_uq_io('loadstep',manifest,6);
step7 = sht_steady_model_uq_io('loadstep',manifest,7);
contract = step1.contract;

cfg = step7.smcConfig;
cfg.particleCount = contract.config.formalSampleCount;
cfg.randomSeed = contract.config.randomSeed+8001;
cfg.useCache = contract.config.useCache;
cfg.verbose = contract.config.verbose;
formal = sht_steady_model_uq_smc(contract,step1.prior, ...
    step5.likelihood,step7.proposal,cfg);
formal.logRawWeight = log(max(formal.weights,realmin));
formal.logProposal = nan(size(formal.weights));
formal.method = 'exact_adaptive_tempered_smc_with_anisotropic_pcn';

minimumEss = max(contract.config.minimumEffectiveSampleSize, ...
    contract.config.minimumEffectiveSampleFraction*cfg.particleCount);
maximumWeight = max(formal.weights);
finalPcnAcceptance = formal.stage(end).pcn_acceptance;
distinctFraction = local_distinct_fraction(formal.theta,contract.priorSigma);
pilotCenter = step6.theta*step6.weights(:);
formalCenter = formal.theta*formal.weights(:);
centerDifference = norm((formalCenter-pilotCenter)./step1.prior.sigma) / ...
    sqrt(contract.parameterCount);
passed = formal.finalBeta == 1 && ...
    formal.diagnostic.effectiveSampleSize >= minimumEss && ...
    maximumWeight <= contract.config.maximumNormalizedWeight && ...
    finalPcnAcceptance >= 0.01 && distinctFraction >= 0.25 && ...
    all(isfinite(formalCenter));
acceptanceCriteria = struct('minimumEss',minimumEss, ...
    'maximumWeight',contract.config.maximumNormalizedWeight, ...
    'minimumFinalPcnAcceptance',0.01,'minimumDistinctFraction',0.25, ...
    'distinctFractionIsSevereCollapseGuardNotAccuracyCriterion',true, ...
    'pilotFormalCenterDistanceReportedNotGated',true);
formal.passed = passed;
formal.maximumNormalizedWeight = maximumWeight;
formal.finalPcnAcceptance = finalPcnAcceptance;
formal.distinctParticleFraction = distinctFraction;
formal.pilotFormalCenterDistancePriorScale = centerDifference;
result = struct('formal',formal,'method',formal.method, ...
    'pilot',step6,'completedRound',1,'passed',passed, ...
    'acceptanceCriteria',acceptanceCriteria, ...
    'truthRead',false,'testDataRead',false);
runtime = toc(timer);
[manifest,file] = sht_steady_model_uq_io( ...
    'savestep',manifest,8,'unified_exact_smc_posterior',result,runtime);
fprintf(['[2.4UQ.8] 正式精确SMC：N=%d, stage=%d, ESS=%.1f, maxW=%.4f, ' ...
    'final pCN=%.1f%%, distinct=%.1f%%, pilot距离=%.3f, pass=%d。\n'], ...
    cfg.particleCount,formal.stageCount,formal.diagnostic.effectiveSampleSize, ...
    maximumWeight,100*finalPcnAcceptance,100*distinctFraction, ...
    centerDifference,passed);
fprintf('[2.4UQ.8] 产物：%s\n',file);
if ~passed
    error('SHT:SteadyUQ:FormalPosteriorNotAccepted', ...
        '正式SMC未通过质量门限；检查点已保存：%s。',file);
end
result.manifest = manifest;
end

function fraction = local_distinct_fraction(theta,scale)
normalized = theta./max(scale(:),eps);
rounded = round(normalized*1e9)/1e9;
[~,uniqueIndex] = unique(rounded.','rows','stable');
fraction = numel(uniqueIndex)/size(theta,2);
end
