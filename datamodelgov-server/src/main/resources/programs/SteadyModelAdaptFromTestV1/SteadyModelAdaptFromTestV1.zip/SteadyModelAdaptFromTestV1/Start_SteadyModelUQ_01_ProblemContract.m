function result = Start_SteadyModelUQ_01_ProblemContract(userCfg)
%START_STEADYMODELUQ_01_PROBLEMCONTRACT 冻结2.4 UQ问题合同。
if nargin < 1, userCfg = struct(); end
timer = tic;
cfg = sht_steady_model_uq_common('defaultconfig', userCfg);
manifest = sht_steady_model_uq_io('createrun', cfg);
contract = sht_steady_model_uq_common('buildcontract', cfg);
prior = sht_steady_model_uq_sampler('buildprior', contract, contract.priorType);
selfTest = sht_steady_model_uq_sampler('selftest', contract);
if ~selfTest.passed
    error('SHT:SteadyUQ:SamplerSelfTestFailed', '先验/提议采样器自检未通过。');
end
result = struct('contract', contract, 'prior', prior, ...
    'samplerSelfTest', selfTest, 'truthRead', false, 'testDataRead', false);
runtime = toc(timer);
[manifest, file] = sht_steady_model_uq_io( ...
    'savestep', manifest, 1, 'problem_contract', result, runtime);
writetable(contract.parameterTable, sht_steady_model_uq_io( ...
    'reportfile', manifest, 'UQ01_parameter_contract.csv'));
groupFile = sht_steady_model_uq_io( ...
    'reportfile', manifest, 'UQ01_parameter_groups.csv');
writetable(contract.parameterGroupTable, groupFile);
fprintf('[2.4UQ.1] 合同完成：run=%s, 训练点=%d, 参数=%d, 观测维数=%d。\n', ...
    manifest.runId, contract.trainingPointCount, contract.parameterCount, ...
    contract.observationDimension);
fprintf('[2.4UQ.1] 参数结构：9x6发动机节点 + 6燃油偏置节点 + 1喷口常值；压损零锚点固定%d个。\n', ...
    contract.fixedPressureLossZeroAnchorCount);
fprintf('[2.4UQ.1] 产物：%s\n', file);
result.manifest = manifest;
end
