function result = Start_SteadyModelAdapt_V2_05_TestDataValidation( ...
        testDataFile, estimationResultFile)
%START_STEADYMODELADAPT_V2_05_TESTDATAVALIDATION 真实测试集独立验证入口。
%
% testDataFile为空或省略时读取TestData目录下默认测试集。若文件不存在，
% 程序给出提示并正常返回“未执行”，不会把缺少测试集误判为辨识失败。
% estimationResultFile为空时使用瞬态时刻路径最新辨识结果。测试集仅用于
% 冻结模型的外部验证，不更新修正系数或后验，也不读取参数真值。

paths = sht_steady_model_adapt_v2_common('paths');
if nargin < 1
    testDataFile = '';
end
if nargin < 2
    estimationResultFile = '';
end
testDataFile = sht_resolve_delivery_input_file( ...
    testDataFile, paths.testFile);
defaultResultFile = fullfile(paths.middleDataDir, ...
    'steady_model_adapt_v2_transient_instant_latest.mat');
estimationResultFile = sht_resolve_delivery_input_file( ...
    estimationResultFile, defaultResultFile);

if exist(testDataFile, 'file') ~= 2
    result = struct('schemaVersion','SHT_STEADY_MODEL_TEST_VALIDATION_V1', ...
        'program',mfilename,'createdAt',datestr(now,31), ...
        'performed',false,'status','skipped_no_test_data', ...
        'message',sprintf('测试集文件不存在，不执行测试集验证：%s。', ...
        testDataFile),'testDataFile',testDataFile, ...
        'estimationResultFile',estimationResultFile, ...
        'testDataUsedForInference',false,'truthWasRead',false);
    fprintf('\n%s\n', result.message);
    latestFile = fullfile(paths.middleDataDir, ...
        'steady_model_adapt_v2_test_validation_latest.mat');
    result.output = struct('latestMatFile',latestFile, ...
        'excelFile','', 'summaryFile','', 'figureFile','');
    save(latestFile, 'result', '-v7.3');
    assignin('base','SteadyModelAdaptV2TestValidationResult',result);
    return;
end
if exist(estimationResultFile, 'file') ~= 2
    error('SHT:SteadyAdaptV2Validation:MissingEstimationResult', ...
        '辨识结果文件不存在：%s。', estimationResultFile);
end

loaded = load(estimationResultFile, 'result');
if ~isfield(loaded, 'result') || ~isstruct(loaded.result)
    error('SHT:SteadyAdaptV2Validation:BadEstimationResult', ...
        '文件不包含有效辨识结果变量result：%s。', estimationResultFile);
end
if isfield(loaded.result, 'truthWasRead') && loaded.result.truthWasRead
    error('SHT:SteadyAdaptV2Validation:TruthContaminatedResult', ...
        '所选辨识结果读取过隐藏真值，不能用于实际交付测试验证。');
end
testData = sht_steady_model_adapt_v2_common( ...
    'readmeasurementtable', testDataFile, '测试集');
result = sht_steady_model_adapt_v2_common( ...
    'validatesavedschedule', loaded.result, testData);
result.program = mfilename;
result.performed = true;
result.status = 'completed';
result.testDataFile = testDataFile;
result.estimationResultFile = estimationResultFile;

stamp = datestr(now,'yyyymmdd_HHMMSS');
latestFile = fullfile(paths.middleDataDir, ...
    'steady_model_adapt_v2_test_validation_latest.mat');
excelFile = fullfile(paths.reportOutputDir, ...
    ['steady_model_adapt_v2_test_validation_' stamp '.xlsx']);
summaryFile = fullfile(paths.reportOutputDir, ...
    ['steady_model_adapt_v2_test_validation_' stamp '_summary.md']);
figureFile = fullfile(paths.reportOutputDir, ...
    ['steady_model_adapt_v2_test_validation_' stamp '.png']);
result.output = struct('latestMatFile',latestFile,'excelFile',excelFile, ...
    'summaryFile',summaryFile,'figureFile',figureFile);

local_write_excel(excelFile, result);
local_write_summary(summaryFile, result);
local_plot_validation(figureFile, result);
save(latestFile, 'result', '-v7.3');
assignin('base','SteadyModelAdaptV2TestValidationResult',result);

fprintf('\n=== 真实测试集独立验证完成 ===\n');
fprintf('测试点：%d，路线：%s，正式通过：%d。\n', ...
    height(testData), result.route, result.passed);
fprintf('修正模型测试NRMS：%.6g。\n', ...
    result.corrected.metrics.overall_nrms);
fprintf('测试集未用于参数辨识：%d；读取参数真值：%d。\n', ...
    ~result.testDataUsedForInference, result.truthWasRead);
fprintf('结果：\n  %s\n  %s\n  %s\n', ...
    latestFile, excelFile, summaryFile);
end

function local_write_excel(filePath, result)
if exist(filePath,'file') == 2
    delete(filePath);
end
writetable(result.baseline.metrics.byField,filePath, ...
    'Sheet','baseline_metrics');
writetable(result.corrected.metrics.byField,filePath, ...
    'Sheet','corrected_metrics');
writetable(result.predictionTable,filePath,'Sheet','primary_prediction');
if result.steadyFromTransient.performed
    writetable(result.steadyFromTransient.corrected.steadyMetrics.byField, ...
        filePath,'Sheet','steady_metrics');
    writetable(result.steadyFromTransient.predictionTable, ...
        filePath,'Sheet','steady_prediction');
    writetable(result.steadyFromTransient.seedTransferTable, ...
        filePath,'Sheet','steady_seed_transfer');
end
end

function local_write_summary(filePath, result)
fid = fopen(filePath,'w','n','UTF-8');
if fid < 0
    error('SHT:SteadyAdaptV2Validation:SummaryOpenFailure', ...
        '无法写入测试验证摘要：%s。', filePath);
end
cleanupObject = onCleanup(@() fclose(fid));
fprintf(fid,'# 真实试车测试集独立验证摘要\n\n');
fprintf(fid,'- 测试数据：`%s`\n',result.testDataFile);
fprintf(fid,'- 冻结辨识结果：`%s`\n',result.estimationResultFile);
fprintf(fid,'- 模型路线：%s\n',result.route);
fprintf(fid,'- 测试点数：%d\n',height(result.testData));
fprintf(fid,'- 测试集参与参数辨识：%d\n',result.testDataUsedForInference);
fprintf(fid,'- 参数真值被读取：%d\n',result.truthWasRead);
fprintf(fid,'- 零修正/修正模型NRMS：%.8g / %.8g\n', ...
    result.baseline.metrics.overall_nrms, ...
    result.corrected.metrics.overall_nrms);
fprintf(fid,'- 主路线零修正/修正回放有效：%d / %d\n', ...
    result.baseline.valid,result.corrected.valid);
if result.steadyFromTransient.performed
    fprintf(fid,'- 附加稳态修正模型NRMS：%.8g\n', ...
        result.steadyFromTransient.corrected.steadyMetrics.overall_nrms);
else
    fprintf(fid,'- 附加稳态回放：未执行（%s）\n', ...
        result.steadyFromTransient.skipReason);
end
fprintf(fid,'- 验证通过：%d\n',result.passed);
clear cleanupObject;
end

function local_plot_validation(filePath, result)
fields = string(result.corrected.metrics.byField.field);
baseline = result.baseline.metrics.byField.normalized_rmse;
corrected = result.corrected.metrics.byField.normalized_rmse;
fig = figure('Visible','off','Color','w','Position',[100 100 900 480]);
bar([baseline corrected]); grid on;
set(gca,'XTick',1:numel(fields),'XTickLabel',cellstr(fields));
xtickangle(30); ylabel('归一化RMSE');
legend({'零修正模型','冻结个体模型'},'Location','best');
title('真实测试集：修正前后预测误差');
saveas(fig,filePath); close(fig);
end
