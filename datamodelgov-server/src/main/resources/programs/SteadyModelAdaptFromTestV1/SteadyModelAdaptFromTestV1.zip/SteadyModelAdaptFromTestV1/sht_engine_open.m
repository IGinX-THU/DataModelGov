function engine = sht_engine_open(engineCfg)
%SHT_ENGINE_OPEN 加载并初始化 GTESS 涡轴发动机 DLL。
% engineCfg 来自 cfg.engine，DLL 目录、库名、头文件和结构体名称均放在 cfg.engine.interface 中。

interface = engineCfg.interface;
oldDir = pwd;
cd(interface.controlDir);
restoreDirectory = onCleanup(@() cd(oldDir));

if libisloaded(interface.libraryName)
    try
        calllib(interface.libraryName, 'DLL_SHT_Free');
    catch
    end
    unloadlibrary(interface.libraryName);
end

loadDiagnostics = sht_load_engine_library( ...
    interface.libraryName, interface.headerName);
modelMode = 0;
if isfield(engineCfg, 'modelMode') && ~isempty(engineCfg.modelMode)
    modelMode = engineCfg.modelMode;
end
status = calllib(interface.libraryName, 'DLL_SHT_InitialMode', modelMode);
if status ~= 0
    error('sht:engine:modelInitialization', ...
        'DLL_SHT_InitialMode(%d)失败，状态码=%d。', modelMode, status);
end

engPtrInit.eng = libstruct(interface.engineStructName);
engPtr = libstruct(interface.enginePointerName, engPtrInit);
stepInValue = zeros(interface.stepInLength, 1);
% 模式0的环境边界只在ConditionsInit读取。若调用方配置了非零高度、
% Mach或温差，必须在此处锁存；后续四个运行入口不再重复读取这些槽位。
inletMode = 0;
if isfield(engineCfg, 'boundary') && ...
        isfield(engineCfg.boundary, 'inletBoundaryMode') && ...
        ~isempty(engineCfg.boundary.inletBoundaryMode)
    inletMode = engineCfg.boundary.inletBoundaryMode;
end
if inletMode == 0 && isfield(engineCfg, 'boundary')
    stepInValue = sht_apply_inlet_boundary_stepin( ...
        stepInValue, engineCfg.boundary);
end
stepIn = libpointer('doublePtr', stepInValue);
stepOut = libpointer('doublePtr', zeros(interface.stepOutLength, 1));
status = calllib(interface.libraryName, ...
    'DLL_SHT_ConditionsInit', stepIn, stepOut, engPtr);
if status ~= 0
    error('sht:engine:conditionInitialization', ...
        'DLL_SHT_ConditionsInit失败，状态码=%d。', status);
end


engine = struct();
engine.libraryName = interface.libraryName;
engine.controlDir = interface.controlDir;
engine.engineStructName = interface.engineStructName;
engine.enginePointerName = interface.enginePointerName;
engine.stepInLength = interface.stepInLength;
engine.stepOutLength = interface.stepOutLength;
engine.healthLength = interface.healthLength;
engine.healthStartIndex = interface.healthStartIndex;
engine.healthScheduleEnableIndex = interface.healthScheduleEnableIndex;
engine.inletBoundaryModeIndex = interface.inletBoundaryModeIndex;
engine.modelMode = modelMode;
engine.loadLibraryDiagnostics = loadDiagnostics;
if isfield(engineCfg, 'modelConfiguration')
    engine.modelConfiguration = engineCfg.modelConfiguration;
else
    engine.modelConfiguration = '';
end

% 健康调度表是六部件模型的可选初始化资产。只有调用方
% 显式提供 healthScheduleProfile 时才写入DLL，因而历史三部件、
% 六部件常值修正以及零修正程序的运行路径均不变。将这一步
% 放在统一发动机打开入口，可保证稳态配平和闭环时域仿真
% 每次重新加载DLL后都使用同一批调度表。
if isfield(engineCfg, 'healthScheduleProfile') && ...
        ~isempty(engineCfg.healthScheduleProfile)
    if modelMode ~= 1
        try
            calllib(interface.libraryName, 'DLL_SHT_Free');
        catch
        end
        unloadlibrary(interface.libraryName);
        error('sht:engine:healthScheduleModelMode', ...
            '健康调度表只允许在六部件模式modelMode=1下初始化。');
    end

    designVector = [];
    if isfield(engineCfg, 'boundary') && ...
            isfield(engineCfg.boundary, 'health') && ...
            ~isempty(engineCfg.boundary.health)
        designVector = engineCfg.boundary.health;
    end
    try
        engine.healthScheduleInitialization = ...
            sht_health_schedule_initialize_dll( ...
                engine, engineCfg.healthScheduleProfile, designVector);
    catch scheduleError
        try
            calllib(interface.libraryName, 'DLL_SHT_Free');
        catch
        end
        if libisloaded(interface.libraryName)
            unloadlibrary(interface.libraryName);
        end
        rethrow(scheduleError);
    end
end
% 仅在调用方显式配置 P3 时增加该字段；默认 engine 结构保持原样。
if isfield(engineCfg, 'transientEffects') && ~isempty(engineCfg.transientEffects)
    engine.transientEffects = engineCfg.transientEffects;
end
engine.isOpen = true;
clear restoreDirectory;
end
