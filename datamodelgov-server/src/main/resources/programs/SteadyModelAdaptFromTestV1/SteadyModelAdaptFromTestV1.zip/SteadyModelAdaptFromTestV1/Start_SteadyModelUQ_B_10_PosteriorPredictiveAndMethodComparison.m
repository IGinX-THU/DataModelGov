function result = Start_SteadyModelUQ_B_10_PosteriorPredictiveAndMethodComparison(userCfg)
%START_STEADYMODELUQ_B_10_POSTERIORPREDICTIVEANDMETHODCOMPARISON
% 读取隔离真值和测试集，完成方法B预测验证，并在B后验冻结后比较A/B。
if nargin < 1, userCfg = struct(); end
timer = tic;
manifest = sht_steady_model_uq_b_io('resolve',userCfg);
step1 = sht_steady_model_uq_b_io('loadstep',manifest,1);
step4 = sht_steady_model_uq_b_io('loadstep',manifest,4);
step8 = sht_steady_model_uq_b_io('loadstep',manifest,8);
step9 = sht_steady_model_uq_b_io('loadstep',manifest,9);
contract = step1.contract;
formal = step8.formal;
testData = sht_steady_model_uq_b_common('loaddata',contract,'test');
% 直接使用正式SMC的全部带权粒子。有限次无权重重采样会给有效质量
% 引入额外Monte Carlo误差，甚至在小规模回归中掩盖真实外推失效比例。
thetaPredictive = formal.theta;
posteriorWeight = formal.weights(:).'/sum(formal.weights);
sampleCount = size(thetaPredictive,2);

trainingExact = sht_steady_model_uq_b_common('evaluate',contract, ...
    thetaPredictive,contract.trainingData, ...
    struct('useCache',false,'returnPredictions',true));
testExact = sht_steady_model_uq_b_common('evaluate',contract, ...
    thetaPredictive,testData, ...
    struct('useCache',false,'returnPredictions',true));
[trainingPrediction,trainingValid] = local_prediction_matrix( ...
    contract,trainingExact);
[testPrediction,testValid] = local_prediction_matrix(contract,testExact);
trainingValidMass = sum(posteriorWeight(trainingValid));
testValidMass = sum(posteriorWeight(testValid));
jointValidMass = sum(posteriorWeight(trainingValid & testValid));
trainingWeight = posteriorWeight(trainingValid);
trainingWeight = trainingWeight/sum(trainingWeight);
testWeight = posteriorWeight(testValid);
testWeight = testWeight/sum(testWeight);
trainingPrediction = trainingPrediction(:,trainingValid);
testPrediction = testPrediction(:,testValid);
if size(trainingPrediction,2) < 8 || size(testPrediction,2) < 8
    error('SHT:SteadyUQB:InsufficientPredictiveSamples', ...
        '方法B有效训练/测试预测样本只有%d/%d。', ...
        size(trainingPrediction,2),size(testPrediction,2));
end

testInput = sht_steady_model_uq_b_common( ...
    'inputcovariance',contract,testData);
testMeasurement = sht_steady_model_uq_b_common( ...
    'measurementcovariance',contract,testInput,testData);
rng(contract.config.randomSeed+10002,'twister');
trainingObservable = trainingPrediction + ...
    step4.measurement.selected.cholLower * ...
    randn(contract.observationDimension,size(trainingPrediction,2));
testObservable = testPrediction + testMeasurement.selected.cholLower * ...
    randn(6*height(testData),size(testPrediction,2));

[truthAvailable,truthFile,truthMetadata,truthTableSource] = ...
    local_find_matching_truth(testData);
if truthAvailable
    [parameterTruth,truthMinimum,truthMaximum,truthKind] = ...
        local_parameter_truth(contract,truthMetadata,truthTableSource);
    trainingTruth = local_output_truth( ...
        contract,truthTableSource,contract.trainingData.point_id);
    testTruth = local_output_truth(contract,truthTableSource,testData.point_id);
else
    parameterTruth = nan(contract.parameterCount,1);
    truthMinimum = parameterTruth;
    truthMaximum = parameterTruth;
    truthKind = repmat("unavailable",contract.parameterCount,1);
    trainingTruth = nan(contract.observationDimension,1);
    testTruth = nan(6*height(testData),1);
end

trainingTable = local_prediction_detail(contract,contract.trainingData, ...
    trainingPrediction,trainingObservable,trainingTruth,trainingWeight);
testTable = local_prediction_detail(contract,testData, ...
    testPrediction,testObservable,testTruth,testWeight);
trainingSummary = local_channel_summary(trainingTable,truthAvailable);
testSummary = local_channel_summary(testTable,truthAvailable);
parameterTable = step9.summaryTable;
parameterTable.truth_target = parameterTruth;
parameterTable.truth_minimum = truthMinimum;
parameterTable.truth_maximum = truthMaximum;
parameterTable.truth_target_kind = truthKind;
parameterTable.truth_target_inside_95 = ...
    parameterTruth>=parameterTable.q025 & parameterTruth<=parameterTable.q975;
parameterTable.truth_range_intersects_95 = ...
    truthMaximum>=parameterTable.q025 & truthMinimum<=parameterTable.q975;
parameterTable.deterministic_estimate = contract.deterministicEstimate;
parameterTable.deterministic_estimate_available = ...
    isfinite(contract.deterministicEstimate);
parameterTable = local_add_plot_index(parameterTable);

[methodAComparison,methodAAvailable] = local_method_a_comparison( ...
    contract,manifest,parameterTable,trainingSummary,testSummary,formal);
testValidityAblation = local_test_validity_ablation(contract, ...
    thetaPredictive,posteriorWeight,testData,testValid);
[testFailureDetail,testFailureSummary] = local_test_failure_diagnostics( ...
    testExact,posteriorWeight,testData);
ordered = all(trainingTable.model_q025<=trainingTable.model_median & ...
    trainingTable.model_median<=trainingTable.model_q975) && ...
    all(testTable.model_q025<=testTable.model_median & ...
    testTable.model_median<=testTable.model_q975);
acceptance = struct('formalPosteriorPassed',step8.passed, ...
    'minimumValidPosteriorMass',0.95, ...
    'trainingValidPosteriorMass',trainingValidMass, ...
    'testValidPosteriorMass',testValidMass, ...
    'jointValidPosteriorMass',jointValidMass, ...
    'predictionIntervalsOrdered',ordered, ...
    'methodAComparisonAvailable',methodAAvailable, ...
    'truthNotUsedAsGate',true);
acceptance.predictiveValidityPassed = trainingValidMass>=0.95 && ...
    testValidMass>=0.95;
acceptance.passed = step8.passed && acceptance.predictiveValidityPassed && ...
    ordered && methodAAvailable;
assessmentReportFile = sht_steady_model_uq_b_io( ...
    'reportfile',manifest,'UQB10_method_b_assessment.md');
result = struct('schemaVersion','steady_model_uq_method_b_result_v1', ...
    'sampleCount',sampleCount,'thetaPredictive',thetaPredictive, ...
    'posteriorWeight',posteriorWeight,'trainingValid',trainingValid, ...
    'testValid',testValid,'trainingConditionalWeight',trainingWeight, ...
    'testConditionalWeight',testWeight, ...
    'trainingPrediction',trainingPrediction,'testPrediction',testPrediction, ...
    'trainingTable',trainingTable,'testTable',testTable, ...
    'trainingSummary',trainingSummary,'testSummary',testSummary, ...
    'parameterTable',parameterTable,'methodAComparison',methodAComparison, ...
    'testValidityAblation',testValidityAblation, ...
    'testFailureDetail',testFailureDetail, ...
    'testFailureSummary',testFailureSummary, ...
    'testInputUncertainty',testInput,'testMeasurement',testMeasurement, ...
    'truthAvailable',truthAvailable,'truthRead',truthAvailable, ...
    'truthFile',truthFile,'testDataRead',true,'acceptance',acceptance, ...
    'passed',acceptance.passed,'assessmentReportFile',assessmentReportFile);
runtime = toc(timer);
[manifest,file] = sht_steady_model_uq_b_io( ...
    'savestep',manifest,10,'posterior_predictive_method_comparison', ...
    result,runtime);
writetable(parameterTable,sht_steady_model_uq_b_io( ...
    'reportfile',manifest,'UQB10_parameter_truth_comparison.csv'));
writetable(trainingTable,sht_steady_model_uq_b_io( ...
    'reportfile',manifest,'UQB10_training_prediction_intervals.csv'));
writetable(testTable,sht_steady_model_uq_b_io( ...
    'reportfile',manifest,'UQB10_test_prediction_intervals.csv'));
writetable(trainingSummary,sht_steady_model_uq_b_io( ...
    'reportfile',manifest,'UQB10_training_channel_summary.csv'));
writetable(testSummary,sht_steady_model_uq_b_io( ...
    'reportfile',manifest,'UQB10_test_channel_summary.csv'));
writetable(testValidityAblation,sht_steady_model_uq_b_io( ...
    'reportfile',manifest,'UQB10_test_validity_block_ablation.csv'));
writetable(testFailureDetail,sht_steady_model_uq_b_io( ...
    'reportfile',manifest,'UQB10_test_failure_diagnostics.csv'));
writetable(testFailureSummary,sht_steady_model_uq_b_io( ...
    'reportfile',manifest,'UQB10_test_failure_summary_by_point.csv'));
if methodAAvailable
    writetable(methodAComparison.commonParameterTable, ...
        sht_steady_model_uq_b_io('reportfile',manifest, ...
        'UQB10_method_a_b_common_parameter_comparison.csv'));
    writetable(methodAComparison.trainingPredictionTable, ...
        sht_steady_model_uq_b_io('reportfile',manifest, ...
        'UQB10_method_a_b_training_prediction_comparison.csv'));
    writetable(methodAComparison.testPredictionTable, ...
        sht_steady_model_uq_b_io('reportfile',manifest, ...
        'UQB10_method_a_b_test_prediction_comparison.csv'));
end
local_plot_parameter_truth(parameterTable,contract,manifest,truthAvailable);
local_plot_prediction(trainingTable,contract,manifest,'training');
local_plot_prediction(testTable,contract,manifest,'test');
if methodAAvailable
    local_plot_method_comparison(methodAComparison,contract,manifest);
end
local_write_assessment(assessmentReportFile,result,step8,step9,manifest);
fprintf(['[2.4UQ-B.10] 预测验证：训练有效质量=%.1f%%，测试有效质量=%.1f%%，' ...
    'A/B对比=%d，truth=%d，pass=%d。\n'],100*trainingValidMass, ...
    100*testValidMass,methodAAvailable,truthAvailable,acceptance.passed);
if truthAvailable
    fprintf('[2.4UQ-B.10] 参数目标覆盖=%d/%d；测试模型/可观测真值覆盖=%d/%d、%d/%d。\n', ...
        nnz(parameterTable.truth_target_inside_95),height(parameterTable), ...
        nnz(testTable.truth_inside_model_95),height(testTable), ...
        nnz(testTable.truth_inside_observable_95),height(testTable));
end
fprintf('[2.4UQ-B.10] 步骤产物：%s\n',file);
fprintf('[2.4UQ-B.10] 评估报告：%s\n',assessmentReportFile);
fprintf('[2.4UQ-B.10] 训练可观测区间图：%s\n', ...
    sht_steady_model_uq_b_io('reportfile',manifest, ...
    'UQB10_training_prediction_intervals.png'));
fprintf('[2.4UQ-B.10] 测试可观测区间图：%s\n', ...
    sht_steady_model_uq_b_io('reportfile',manifest, ...
    'UQB10_test_prediction_intervals.png'));
result.manifest = manifest;
end

function tbl = local_test_validity_ablation( ...
        contract,theta,weight,testData,fullValid)
% 只作后验解释，不改变后验权重，也不使用测试集重新筛选参数。
caseName = ["full";"local_zero";"bleed_zero";"aggregate_only"];
description = ["完整方法B后验"; ...
    "仅将12个六部件局部常值置零"; ...
    "仅将20个物理引气常值置零"; ...
    "将局部与引气参数同时置零，仅保留总体参数"];
validMass = nan(numel(caseName),1);
invalidParticleCount = zeros(numel(caseName),1);
validMass(1) = sum(weight(fullValid));
invalidParticleCount(1) = nnz(~fullValid);
candidate = repmat({theta},numel(caseName),1);
candidate{2}(contract.parameterBlockIndex{2},:) = 0;
candidate{3}(contract.parameterBlockIndex{3},:) = 0;
candidate{4}([contract.parameterBlockIndex{2}; ...
    contract.parameterBlockIndex{3}],:) = 0;
for i = 2:numel(caseName)
    exact = sht_steady_model_uq_b_common('evaluate',contract, ...
        candidate{i},testData,struct('useCache',true));
    validMass(i) = sum(weight(exact.valid));
    invalidParticleCount(i) = nnz(~exact.valid);
end
tbl = table(caseName,description,validMass,invalidParticleCount, ...
    'VariableNames',{'case_name','description', ...
    'test_valid_posterior_mass','invalid_particle_count'});
end

function [detail,summary] = local_test_failure_diagnostics( ...
        exact,weight,testData)
% 将“粒子无效”拆成具体测试点、DLL返回码和共同工作残差，避免把
% 正常返回但残差超限误写成DLL崩溃。
residualThreshold = 1e-2;
particleIndex = zeros(0,1); posteriorWeight = zeros(0,1);
pointId = strings(0,1); returnCode = zeros(0,1);
convergeTag = zeros(0,1); maxModelResidual = zeros(0,1);
failureReason = strings(0,1); errorMessage = strings(0,1);
for particle = 1:numel(exact.prediction)
    prediction = exact.prediction{particle};
    if isempty(prediction) || ~istable(prediction), continue; end
    failedRows = find(~prediction.valid);
    for row = failedRows(:).'
        particleIndex(end+1,1) = particle; %#ok<AGROW>
        posteriorWeight(end+1,1) = weight(particle); %#ok<AGROW>
        pointId(end+1,1) = string(prediction.point_id(row)); %#ok<AGROW>
        returnCode(end+1,1) = prediction.return_code(row); %#ok<AGROW>
        convergeTag(end+1,1) = prediction.converge_tag(row); %#ok<AGROW>
        maxModelResidual(end+1,1) = ...
            prediction.max_model_residual(row); %#ok<AGROW>
        errorMessage(end+1,1) = string(prediction.error_message(row)); %#ok<AGROW>
        if prediction.return_code(row) ~= 0
            reason = "dll_return_code_nonzero";
        elseif ~isfinite(prediction.max_model_residual(row))
            reason = "nonfinite_common_work_residual";
        elseif prediction.max_model_residual(row) > residualThreshold
            reason = "common_work_residual_exceeded";
        else
            reason = "nonfinite_output_or_other";
        end
        failureReason(end+1,1) = reason; %#ok<AGROW>
    end
end
detail = table(particleIndex,posteriorWeight,pointId,returnCode, ...
    convergeTag,maxModelResidual,repmat(residualThreshold, ...
    numel(particleIndex),1),failureReason,errorMessage, ...
    'VariableNames',{'particle_index','posterior_weight','point_id', ...
    'return_code','converge_tag','max_model_residual', ...
    'residual_acceptance_threshold','failure_reason','error_message'});

pointId = string(testData.point_id);
n = numel(pointId);
invalidParticleCount = zeros(n,1); invalidPosteriorMass = zeros(n,1);
dllReturnFailureCount = zeros(n,1); residualThresholdFailureCount = zeros(n,1);
nonfiniteResidualCount = zeros(n,1); minimumInvalidResidual = nan(n,1);
maximumInvalidResidual = nan(n,1);
for i = 1:n
    use = detail.point_id == pointId(i);
    if ~any(use), continue; end
    particles = unique(detail.particle_index(use));
    invalidParticleCount(i) = numel(particles);
    invalidPosteriorMass(i) = sum(weight(particles));
    dllReturnFailureCount(i) = nnz(detail.return_code(use) ~= 0);
    residualThresholdFailureCount(i) = nnz( ...
        detail.failure_reason(use) == "common_work_residual_exceeded");
    nonfiniteResidualCount(i) = nnz( ...
        detail.failure_reason(use) == "nonfinite_common_work_residual");
    residual = detail.max_model_residual(use);
    residual = residual(isfinite(residual));
    if ~isempty(residual)
        minimumInvalidResidual(i) = min(residual);
        maximumInvalidResidual(i) = max(residual);
    end
end
summary = table(pointId,invalidParticleCount,invalidPosteriorMass, ...
    dllReturnFailureCount,residualThresholdFailureCount, ...
    nonfiniteResidualCount,minimumInvalidResidual,maximumInvalidResidual, ...
    'VariableNames',{'point_id','invalid_particle_count', ...
    'invalid_posterior_mass','dll_return_failure_count', ...
    'residual_threshold_failure_count','nonfinite_residual_count', ...
    'minimum_invalid_residual','maximum_invalid_residual'});
end

function [matrix,valid] = local_prediction_matrix(contract,exact)
valid = exact.valid(:).';
matrix = nan(size(exact.residual));
for i = 1:numel(valid)
    if ~valid(i) || isempty(exact.prediction{i}), continue; end
    matrix(:,i) = sht_steady_model_uq_b_common( ...
        'predictionvector',contract.route,exact.prediction{i});
    valid(i) = all(isfinite(matrix(:,i)));
end
end

function tbl = local_prediction_detail( ...
        contract,data,model,observable,truth,weight)
[measured,label,unit] = sht_steady_model_uq_b_common( ...
    'observation',contract,data);
modelQ = local_weighted_quantile_rows(model,weight,[0.025,0.5,0.975]);
observableQ = local_weighted_quantile_rows( ...
    observable,weight,[0.025,0.5,0.975]);
pointId = strings(6*height(data),1);
output = strings(6*height(data),1);
for p = 1:height(data)
    rows = (p-1)*6+(1:6);
    pointId(rows) = string(data.point_id(p));
    output(rows) = string(contract.residualOrder(:));
end

tbl = table(pointId,output,unit,label,measured,modelQ(:,1),modelQ(:,2), ...
    modelQ(:,3),observableQ(:,1),observableQ(:,2),observableQ(:,3), ...
    modelQ(:,3)-modelQ(:,1),observableQ(:,3)-observableQ(:,1), ...
    measured>=modelQ(:,1)&measured<=modelQ(:,3), ...
    measured>=observableQ(:,1)&measured<=observableQ(:,3),truth(:), ...
    truth(:)>=modelQ(:,1)&truth(:)<=modelQ(:,3), ...
    truth(:)>=observableQ(:,1)&truth(:)<=observableQ(:,3), ...
    'VariableNames',{'point_id','output','unit','label','measured_value', ...
    'model_q025','model_median','model_q975','observable_q025', ...
    'observable_median','observable_q975','model_width_95', ...
    'observable_width_95','measured_inside_model_95', ...
    'measured_inside_observable_95','truth_value', ...
    'truth_inside_model_95','truth_inside_observable_95'});
end

function output = local_weighted_quantile_rows(value,weight,probability)
weight = weight(:).'/sum(weight);
if size(value,2) ~= numel(weight)
    error('SHT:SteadyUQB:PredictiveWeightDimension', ...
        '预测矩阵列数与后验权重数不一致。');
end
output = nan(size(value,1),numel(probability));
for row = 1:size(value,1)
    [sortedValue,order] = sort(value(row,:));
    sortedWeight = weight(order);
    cumulative = cumsum(sortedWeight);
    cumulative(end) = 1;
    for q = 1:numel(probability)
        index = find(cumulative>=probability(q),1);
        output(row,q) = sortedValue(index);
    end
end
end

function summary = local_channel_summary(detail,truthAvailable)
names = unique(detail.output,'stable');
n = numel(names);
meanModelWidth = zeros(n,1); meanObservableWidth = zeros(n,1);
measuredModelCoverage = zeros(n,1); measuredObservableCoverage = zeros(n,1);
truthModelCoverage = nan(n,1); truthObservableCoverage = nan(n,1);
for i = 1:n
    use = detail.output==names(i);
    meanModelWidth(i) = mean(detail.model_width_95(use));
    meanObservableWidth(i) = mean(detail.observable_width_95(use));
    measuredModelCoverage(i) = mean(detail.measured_inside_model_95(use));
    measuredObservableCoverage(i) = ...
        mean(detail.measured_inside_observable_95(use));
    if truthAvailable
        truthModelCoverage(i) = mean(detail.truth_inside_model_95(use));
        truthObservableCoverage(i) = ...
            mean(detail.truth_inside_observable_95(use));
    end
end
summary = table(names,meanModelWidth,meanObservableWidth, ...
    measuredModelCoverage,measuredObservableCoverage,truthModelCoverage, ...
    truthObservableCoverage,'VariableNames',{'output','mean_model_width_95', ...
    'mean_observable_width_95','measured_model_coverage', ...
    'measured_observable_coverage','truth_model_coverage', ...
    'truth_observable_coverage'});
end

function [available,file,metadata,dataTable] = local_find_matching_truth(testData)
available = false; file = ''; metadata = struct(); dataTable = table();
folder = fullfile(fileparts(mfilename('fullpath')),'TestData', ...
    'test_data_generation');
listing = dir(fullfile(folder,'steady_bench_substitute_*.mat'));
if isempty(listing), return; end
[~,order] = sort([listing.datenum],'descend'); listing = listing(order);
for i = 1:numel(listing)
    candidate = fullfile(listing(i).folder,listing(i).name);
    s = load(candidate,'metadata','dataTable');
    if ~isfield(s,'metadata') || ~isfield(s,'dataTable'), continue; end
    if local_truth_table_matches(s.dataTable,testData)
        available = true; file = candidate;
        metadata = s.metadata; dataTable = s.dataTable;
        return;
    end
end
end

function matched = local_truth_table_matches(source,testData)
matched = true; id = string(source.point_id);
names = {'Np','Ng','Wf','Pt2','Tt1','Pt3','Tt3','Tt45','Pt45'};
for i = 1:height(testData)
    row = find(id==string(testData.point_id(i)),1);
    if isempty(row), matched = false; return; end
    for j = 1:numel(names)
        excelName = [names{j} '_mean'];
        if ~ismember(names{j},source.Properties.VariableNames) || ...
                ~ismember(excelName,testData.Properties.VariableNames)
            matched = false; return;
        end
        a = source.(names{j})(row); b = testData.(excelName)(i);
        if abs(a-b)>1e-9*max([1,abs(a),abs(b)])
            matched = false; return;
        end
    end
end
end

function [target,minimum,maximum,kind] = ...
        local_parameter_truth(contract,metadata,dataTable)
target = nan(contract.parameterCount,1);
minimum = target; maximum = target;
kind = repmat("exact",contract.parameterCount,1);
profile = metadata.truthHealthScheduleProfile;
parameter = profile.parameters;
tbl = contract.parameterTable;
wfDesign = contract.scheduleTemplate.fuelBias.wfDesign;
fuelX = dataTable.Wf/wfDesign;
fuelBias = dataTable.Wf-dataTable.Wf_true;
[fuelX,order] = sort(fuelX(:)); fuelBias = fuelBias(order);
[fuelX,~,group] = unique(fuelX); fuelBias = accumarray(group,fuelBias,[],@mean);
trainingIds = string(contract.trainingPointIds);
operating = profile.anchorOperatingPoints;
for j = 1:contract.parameterCount
    groupKind = string(tbl.group_kind(j));
    if groupKind=="health_schedule"
        entry = local_truth_parameter(parameter,tbl.base_name(j));
        query = local_clamp(tbl.coordinate(j),entry.xNodes);
        target(j) = interp1(entry.xNodes,entry.kNodes,query,'linear');
        minimum(j) = target(j); maximum(j) = target(j);
    elseif groupKind=="fuel_bias"
        query = local_clamp(tbl.coordinate(j),fuelX);
        target(j) = interp1(fuelX,fuelBias,query,'linear');
        minimum(j) = target(j); maximum(j) = target(j);
    elseif groupKind=="constant"
        entry = local_truth_parameter(parameter,tbl.base_name(j));
        target(j) = entry.designValue;
        minimum(j) = target(j); maximum(j) = target(j);
    elseif groupKind=="health_constant"
        entry = local_truth_parameter(parameter,tbl.base_name(j));
        if ismember(tbl.c_index(j),[71,72,74,75,77,78,80,81,83,84,86,87])
            coordinate = local_operating_coordinate(operating,entry.axisName, ...
                trainingIds);
            value = interp1(entry.xNodes,entry.kNodes, ...
                min(max(coordinate,min(entry.xNodes)),max(entry.xNodes)), ...
                'linear');
            target(j) = mean(value);
            minimum(j) = min(value); maximum(j) = max(value);
            kind(j) = "training_effective_mean_of_scheduled_truth";
        else
            target(j) = entry.designValue;
            minimum(j) = target(j); maximum(j) = target(j);
        end
    else
        error('SHT:SteadyUQB:UnknownTruthGroupKind', ...
            '未知方法B真值组类型%s。',groupKind);
    end
end
end

function entry = local_truth_parameter(parameter,name)
index = find(strcmp({parameter.name},char(name)),1);
if isempty(index)
    error('SHT:SteadyUQB:MissingParameterTruth', ...
        '隔离真值缺少参数%s。',name);
end
entry = parameter(index);
end

function coordinate = local_operating_coordinate(operating,axisName,pointIds)
switch char(axisName)
    case 'ac_corrected_speed', field = 'acRelativeCorrectedSpeed';
    case 'cc_corrected_speed', field = 'ccRelativeCorrectedSpeed';
    case 'gt_total_pressure_ratio', field = 'gtTotalPressureRatio';
    case 'pt_total_pressure_ratio', field = 'ptTotalPressureRatio';
    otherwise
        error('SHT:SteadyUQB:UnsupportedLocalTruthAxis', ...
            '局部常值真值不支持调度轴%s。',axisName);
end
coordinate = nan(numel(pointIds),1);
sourceId = string(operating.pointId);
for i = 1:numel(pointIds)
    row = find(sourceId==pointIds(i),1);
    if isempty(row)
        error('SHT:SteadyUQB:MissingTruthOperatingPoint', ...
            '局部真值缺少训练工况%s。',pointIds(i));
    end
    coordinate(i) = operating.(field)(row);
end
end

function value = local_clamp(value,nodes)
value = min(max(value,min(nodes)),max(nodes));
end

function vector = local_output_truth(contract,source,pointIds)
names = string(contract.residualOrder(:));
vector = nan(6*numel(pointIds),1);
sourceId = string(source.point_id);
for p = 1:numel(pointIds)
    row = find(sourceId==string(pointIds(p)),1);
    if isempty(row)
        error('SHT:SteadyUQB:MissingOutputTruth', ...
            '隐藏真值缺少工况%s。',string(pointIds(p)));
    end
    for k = 1:6
        field = char(names(k));
        switch field
            case {'Pt3','Tt3','Tt45','Pt45'}
                truthField = [field '_true'];
                vector((p-1)*6+k) = source.(truthField)(row);
            case {'dNp_dt','dNg_dt'}
                vector((p-1)*6+k) = 0;
            otherwise
                error('SHT:SteadyUQB:UnsupportedTruthOutput', ...
                    '不支持输出真值%s。',field);
        end
    end
end
end

function [comparison,available] = local_method_a_comparison( ...
        contract,bManifest,bParameter,bTraining,bTest,bFormal)
available = false; comparison = struct();
aPaths = sht_steady_model_uq_io('paths');
if isempty(contract.config.methodARunId)
    manifestFile = aPaths.latestFile;
else
    manifestFile = fullfile(aPaths.middleRoot, ...
        contract.config.methodARunId,'manifest.mat');
end
if exist(manifestFile,'file') ~= 2, return; end
s = load(manifestFile,'manifest'); aManifest = s.manifest;
if aManifest.completedStep < 10, return; end
a1 = sht_steady_model_uq_io('loadstep',aManifest,1);
a8 = sht_steady_model_uq_io('loadstep',aManifest,8);
a9 = sht_steady_model_uq_io('loadstep',aManifest,9);
a10 = sht_steady_model_uq_io('loadstep',aManifest,10);
if ~strcmp(a1.contract.route,contract.route) || ...
        ~strcmp(sht_steady_model_uq_common('filehash',a1.contract.trainingFile), ...
        sht_steady_model_uq_common('filehash',contract.trainingFile))
    error('SHT:SteadyUQB:MethodAContractMismatch', ...
        '方法A与B的路线或训练数据不一致，禁止直接比较。');
end
aParameter = a9.summaryTable;
if ~all(string(aParameter.name)==string(bParameter.name(1:61)))
    error('SHT:SteadyUQB:MethodAParameterMismatch', ...
        '方法A的61维参数顺序与方法B共同参数不一致。');
end
commonParameterTable = table(string(aParameter.name), ...
    aParameter.posterior_mean,bParameter.posterior_mean(1:61), ...
    bParameter.posterior_mean(1:61)-aParameter.posterior_mean, ...
    aParameter.posterior_std,bParameter.posterior_std(1:61), ...
    aParameter.credible_width,bParameter.credible_width(1:61), ...
    bParameter.credible_width(1:61)./aParameter.credible_width, ...
    'VariableNames',{'name','method_a_mean','method_b_mean', ...
    'b_minus_a_mean','method_a_std','method_b_std','method_a_width_95', ...
    'method_b_width_95','b_to_a_width_ratio'});
trainingPredictionTable = local_compare_channel_summary( ...
    a10.trainingSummary,bTraining);
testPredictionTable = local_compare_channel_summary(a10.testSummary,bTest);
comparison = struct('methodARunId',aManifest.runId, ...
    'methodBRunId',bManifest.runId,'commonParameterTable',commonParameterTable, ...
    'trainingPredictionTable',trainingPredictionTable, ...
    'testPredictionTable',testPredictionTable, ...
    'methodAParameterCount',a1.contract.parameterCount, ...
    'methodBParameterCount',contract.parameterCount, ...
    'methodAEss',a8.formal.diagnostic.effectiveSampleSize, ...
    'methodBEss',bFormal.diagnostic.effectiveSampleSize, ...
    'methodARuntime_s',sum(aManifest.stepRuntime_s,'omitnan'), ...
    'methodBRuntime_s',sum(bManifest.stepRuntime_s,'omitnan'), ...
    'methodAPassed',a10.passed,'methodBPassed',bFormal.passed);
available = true;
end

function tbl = local_compare_channel_summary(a,b)
if ~all(string(a.output)==string(b.output))
    error('SHT:SteadyUQB:MethodAOutputMismatch', ...
        '方法A/B预测汇总输出顺序不一致。');
end
tbl = table(string(a.output),a.mean_model_width_95,b.mean_model_width_95, ...
    b.mean_model_width_95./a.mean_model_width_95, ...
    a.mean_observable_width_95,b.mean_observable_width_95, ...
    a.truth_model_coverage,b.truth_model_coverage, ...
    a.truth_observable_coverage,b.truth_observable_coverage, ...
    'VariableNames',{'output','method_a_model_width_95', ...
    'method_b_model_width_95','b_to_a_model_width_ratio', ...
    'method_a_observable_width_95','method_b_observable_width_95', ...
    'method_a_truth_model_coverage','method_b_truth_model_coverage', ...
    'method_a_truth_observable_coverage', ...
    'method_b_truth_observable_coverage'});
end

function tbl = local_add_plot_index(tbl)
% 参数区间图按块使用局部序号；CSV同时保存局部序号与参数名称，便于
% 从密集图中的序号追溯到具体修正系数和调度节点。
tbl.plot_block_local_index = zeros(height(tbl),1);
blocks = ["aggregate","local","bleed"];
for i = 1:numel(blocks)
    rows = find(tbl.block_name == blocks(i));
    tbl.plot_block_local_index(rows) = (1:numel(rows)).';
end
end

function local_plot_parameter_truth(tbl,contract,manifest,truthAvailable)
figureHandle = figure('Visible',contract.config.figureVisible, ...
    'Name','Method B parameter truth','Position',[100,100,1450,900]);
blocks = ["aggregate","local","bleed"];
titles = {'总体参数（61维）','六部件局部常值（12维）', ...
    '物理引气常值：10路流量+10路总温（20维）'};
for b = 1:3
    subplot(3,1,b); use = find(tbl.block_name==blocks(b)); x = 1:numel(use);
    sigma = contract.priorSigma(use);
    lo = tbl.q025(use)./sigma; hi = tbl.q975(use)./sigma;
    mu = tbl.posterior_mean(use)./sigma;
    for i = 1:numel(use)
        plot([x(i),x(i)],[lo(i),hi(i)],'b-','LineWidth',1.1); hold on;
        if truthAvailable
            plot([x(i),x(i)],[tbl.truth_minimum(use(i)), ...
                tbl.truth_maximum(use(i))]./sigma(i),'r-','LineWidth',2);
        end
    end
    plot(x,mu,'ko','MarkerSize',3,'MarkerFaceColor','k');
    deterministic = tbl.deterministic_estimate(use)./sigma;
    deterministicAvailable = isfinite(deterministic);
    if any(deterministicAvailable)
        plot(x(deterministicAvailable),deterministic(deterministicAvailable), ...
            'd','Color',[0.10,0.55,0.20],'MarkerFaceColor',[0.10,0.75,0.30], ...
            'MarkerSize',4);
    end
    if truthAvailable
        plot(x,tbl.truth_target(use)./sigma,'rp','MarkerSize',6);
    end
    yline(0,'--'); grid on; title(titles{b});
    ylabel('参数/先验标准差'); xlim([0.5,numel(use)+0.5]);
    if b == 1
        hInterval = plot(nan,nan,'b-','LineWidth',1.1);
        hMean = plot(nan,nan,'ko','MarkerFaceColor','k','MarkerSize',3);
        hEstimate = plot(nan,nan,'d','Color',[0.10,0.55,0.20], ...
            'MarkerFaceColor',[0.10,0.75,0.30],'MarkerSize',4);
        hTruth = plot(nan,nan,'rp','MarkerSize',6);
        hTruthRange = plot(nan,nan,'r-','LineWidth',2);
        legend([hInterval,hMean,hEstimate,hTruth,hTruthRange], ...
            {'95%后验可信区间','后验均值','2.4 D阶段辨识结果', ...
            '参数真值/有效均值','工况相关真值范围'}, ...
            'Location','best','NumColumns',3);
    end
end
xlabel(['块内参数序号；序号、参数名称、C端h编号及辨识值见' ...
    ' UQB10_parameter_truth_comparison.csv']);
saveas(figureHandle,sht_steady_model_uq_b_io( ...
    'reportfile',manifest,'UQB10_parameter_truth_intervals.png'));
close(figureHandle);
end

function local_plot_prediction(tbl,contract,manifest,role)
figureHandle = figure('Visible',contract.config.figureVisible, ...
    'Name',['Method B ' role ' prediction'],'Position',[100,100,1250,760]);
names = unique(tbl.output,'stable');
for i = 1:numel(names)
    subplot(2,3,i); use = find(tbl.output==names(i)); x = 1:numel(use);
    hObservable = fill([x,fliplr(x)],[tbl.observable_q025(use).', ...
        fliplr(tbl.observable_q975(use).')],[0.85,0.91,1.0], ...
        'EdgeColor','none'); hold on;
    hModel = fill([x,fliplr(x)],[tbl.model_q025(use).', ...
        fliplr(tbl.model_q975(use).')],[0.55,0.72,0.92], ...
        'EdgeColor','none');
    hMedian = plot(x,tbl.model_median(use),'b-o','LineWidth',1);
    hMeasured = plot(x,tbl.measured_value(use),'ks','MarkerFaceColor','k');
    hTruth = gobjects(0);
    if all(isfinite(tbl.truth_value(use)))
        hTruth = plot(x,tbl.truth_value(use),'rp','MarkerFaceColor','r');
    end
    grid on; title(char(names(i))); xlabel('工况点');
    xticks(x); xticklabels(cellstr(tbl.point_id(use))); xtickangle(25);
    if i == 1
        handles = [hObservable,hModel,hMedian,hMeasured];
        labels = {'95%可观测区间','95%模型输出区间', ...
            '模型输出中位数','测量值'};
        if ~isempty(hTruth)
            handles(end+1) = hTruth;
            labels{end+1} = '无测量误差真值';
        end
        legend(handles,labels,'Location','best');
    end
end
saveas(figureHandle,sht_steady_model_uq_b_io( ...
    'reportfile',manifest,['UQB10_' role '_prediction_intervals.png']));
close(figureHandle);
end

function local_plot_method_comparison(comparison,contract,manifest)
tbl = comparison.commonParameterTable;
figureHandle = figure('Visible',contract.config.figureVisible, ...
    'Name','Method A B comparison','Position',[100,100,1200,620]);
subplot(2,1,1); plot(tbl.b_to_a_width_ratio,'o-'); yline(1,'--'); grid on;
ylabel('B/A可信区间宽度'); title('共同61个参数的A/B后验宽度对比');
subplot(2,1,2); plot(tbl.b_minus_a_mean./contract.priorSigma(1:61),'o-');
yline(0,'--'); grid on; ylabel('(B-A)/先验标准差'); xlabel('共同参数序号');
saveas(figureHandle,sht_steady_model_uq_b_io( ...
    'reportfile',manifest,'UQB10_method_a_b_parameter_comparison.png'));
close(figureHandle);
end

function local_write_assessment(file,result,step8,step9,manifest)
line = {};
line{end+1} = '# 2.4稳态贝叶斯不确定性量化方法B执行结果';
line{end+1} = '';
line{end+1} = sprintf('- 运行编号：`%s`',manifest.runId);
line{end+1} = sprintf('- 参数维数：93（总体61、局部12、引气20）');
line{end+1} = sprintf('- 正式粒子数：%d',size(step8.formal.theta,2));
line{end+1} = sprintf('- SMC层数：%d',step8.formal.stageCount);
line{end+1} = sprintf('- ESS：%.2f',step8.formal.diagnostic.effectiveSampleSize);
line{end+1} = sprintf('- DLL新计算次数：%d',step8.formal.dllEvaluationCount);
line{end+1} = sprintf('- DLL累计时间：%.2f s',step8.formal.dllRuntime_s);
line{end+1} = sprintf('- 四类核接受率：%.2f%% / %.2f%% / %.2f%% / %.2f%%', ...
    100*step8.formal.blockAcceptance);
line{end+1} = sprintf(['- 经局部零导数、全边界精确扰动和先验独立性' ...
    '三重审计后，解析保留先验的参数：%d个。'], ...
    numel(step8.formal.priorOnlyParameterIndex));
line{end+1} = sprintf('- 最佳训练Mahalanobis距离平方：%.4f', ...
    step9.bestMahalanobisSquared);
line{end+1} = sprintf(['- 高后验参考点与正式样本最大对数后验差：' ...
    '%.4f（门限%.4f）。'],step8.formal.referenceDominanceGap, ...
    step8.formal.maximumReferenceDominanceGap);
line{end+1} = sprintf('- 弱信息潜空间标准差中位数/q10：%.3f / %.3f。', ...
    step8.formal.subspaceMixingDiagnostic.medianNullLatentStd, ...
    step8.formal.subspaceMixingDiagnostic.q10NullLatentStd);
line{end+1} = sprintf('- 统计后验采样验收：`%d`。', ...
    result.acceptance.formalPosteriorPassed);
line{end+1} = '';
line{end+1} = '## 参数块信息收缩';
line{end+1} = '';
for i = 1:height(step9.blockTable)
    row = step9.blockTable(i,:);
    line{end+1} = sprintf(['- `%s`：参数%d个，平均后验/先验区间宽度比%.3f，' ...
        '收缩不小于20%%的参数%d个。'],row.block_name,row.parameter_count, ...
        row.mean_posterior_to_prior_width_ratio, ...
        row.count_shrinkage_ge_20_percent);
end
line{end+1} = '';
line{end+1} = '## 真值与预测验证';
line{end+1} = '';
line{end+1} = sprintf('- 训练集有效后验质量：%.2f%%。', ...
    100*result.acceptance.trainingValidPosteriorMass);
line{end+1} = sprintf('- 测试集有效后验质量：%.2f%%（门限%.2f%%）。', ...
    100*result.acceptance.testValidPosteriorMass, ...
    100*result.acceptance.minimumValidPosteriorMass);
line{end+1} = sprintf('- 外推工程可行性验收：`%d`。', ...
    result.acceptance.predictiveValidityPassed);
line{end+1} = sprintf('- 测试集无效粒子：%d/%d；无效后验质量：%.2f%%。', ...
    nnz(~result.testValid),result.sampleCount, ...
    100*(1-result.acceptance.testValidPosteriorMass));
line{end+1} = sprintf('- DLL非零返回码失效记录：%d条；共同工作残差超限记录：%d条。', ...
    nnz(result.testFailureDetail.return_code~=0), ...
    nnz(result.testFailureDetail.failure_reason== ...
    "common_work_residual_exceeded"));
for i = 1:height(result.testFailureSummary)
    row = result.testFailureSummary(i,:);
    if row.invalid_particle_count == 0
        line{end+1} = sprintf('- 测试点 `%s`：无失效粒子。',row.point_id);
    else
        line{end+1} = sprintf(['- 测试点 `%s`：无效粒子%d个，后验质量%.3f%%，' ...
            'DLL返回失败%d个，残差超限%d个，失效残差范围[%.6g, %.6g]。'], ...
            row.point_id,row.invalid_particle_count, ...
            100*row.invalid_posterior_mass,row.dll_return_failure_count, ...
            row.residual_threshold_failure_count,row.minimum_invalid_residual, ...
            row.maximum_invalid_residual);
    end
end
if result.truthAvailable
    line{end+1} = sprintf('- 参数目标落入95%%区间：%d/%d。', ...
        nnz(result.parameterTable.truth_target_inside_95), ...
        height(result.parameterTable));
    line{end+1} = sprintf('- 测试集模型区间真值覆盖：%d/%d。', ...
        nnz(result.testTable.truth_inside_model_95),height(result.testTable));
    line{end+1} = sprintf('- 测试集可观测区间真值覆盖：%d/%d。', ...
        nnz(result.testTable.truth_inside_observable_95),height(result.testTable));
    line{end+1} = sprintf('- 隔离真值文件：`%s`',result.truthFile);
else
    line{end+1} = '- 未找到与测试表严格匹配的隔离真值文件。';
end
line{end+1} = sprintf('- 参数真值、辨识结果与后验区间图：`%s`', ...
    sht_steady_model_uq_b_io('reportfile',manifest, ...
    'UQB10_parameter_truth_intervals.png'));
line{end+1} = sprintf('- 训练集模型/可观测区间图：`%s`', ...
    sht_steady_model_uq_b_io('reportfile',manifest, ...
    'UQB10_training_prediction_intervals.png'));
line{end+1} = sprintf('- 测试集模型/可观测区间图：`%s`', ...
    sht_steady_model_uq_b_io('reportfile',manifest, ...
    'UQB10_test_prediction_intervals.png'));
line{end+1} = '';
line{end+1} = '### 测试可行性块消融';
line{end+1} = '';
for i = 1:height(result.testValidityAblation)
    row = result.testValidityAblation(i,:);
    line{end+1} = sprintf('- `%s`：有效后验质量%.2f%%，无效粒子%d个。', ...
        row.case_name,100*row.test_valid_posterior_mass, ...
        row.invalid_particle_count);
end
line{end+1} = ['- 块消融只用于定位外推风险，不改变正式后验权重，' ...
    '也不允许使用测试集反向裁剪后验。'];
line{end+1} = '';
line{end+1} = '## 方法A/B对比';
line{end+1} = '';
if result.acceptance.methodAComparisonAvailable
    c = result.methodAComparison;
    line{end+1} = sprintf('- 方法A运行：`%s`；方法B运行：`%s`。', ...
        c.methodARunId,c.methodBRunId);
    line{end+1} = sprintf('- 方法A/B参数维数：%d / %d。', ...
        c.methodAParameterCount,c.methodBParameterCount);
    line{end+1} = sprintf('- 共同参数B/A区间宽度比中位数：%.3f。', ...
        median(c.commonParameterTable.b_to_a_width_ratio));
else
    line{end+1} = '- 未找到合同一致且完成十步的方法A结果。';
end
line{end+1} = '';
line{end+1} = '## 解释边界';
line{end+1} = '';
line{end+1} = ['- 42维观测不能独立约束93个方向。新增参数区间接近先验并非' ...
    '采样失败，而是现有数据对该方向信息不足。'];
line{end+1} = ['- K_PRec在当前发动机C程序中不起作用，已固定为0并从方法B参数空间、' ...
    '后验分析和绘图中删除，未以“保留先验”的方式占用粒子维数。'];
line{end+1} = ['- 局部六部件参数在方法B中是常值；其真值目标为七个训练工况' ...
    '调度真值的有效均值，同时另报最小值和最大值。'];
line{end+1} = ['- 方法B没有使用方法A后验构造先验、初值、提议或边界；A只在' ...
    'B后验冻结后参与对比。'];
if result.acceptance.formalPosteriorPassed && ...
        ~result.acceptance.predictiveValidityPassed
    line{end+1} = ['- 本次统计后验已经通过采样验收，但测试工况有效后验质量未达' ...
        '工程门限；这属于外推可行性风险，不应误判为采样算法失败，也不能' ...
        '通过降低门限或测试集筛样本予以掩盖。'];
end
line{end+1} = '';
line{end+1} = sprintf('- 最终程序验收状态：`%d`。',result.passed);
sht_steady_model_uq_b_io('writetext',file,strjoin(line,newline));
end
