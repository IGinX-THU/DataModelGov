function runtime = sht_prepare_control_model_runtime(sourceDir)
%SHT_PREPARE_CONTROL_MODEL_RUNTIME 构造六部件闭环仿真的独立运行目录。
%
% 六部件设计文件 Turboshaft-TS-Split.mdl 必须继续保持
% offDesignMode=0，供 RunModelSHT_V2_2DP 独立执行设计点求解。闭环仿真
% 需要 offDesignMode=2 及已经折算好的部件缩放系数，因此不能直接修改或
% 临时覆盖设计文件。本函数读取 V2 设计状态，在 MiddleData 下生成一份
% 可重复构造的运行副本，并复制 DLL、头文件和六部件特性图。
%
% 输出 runtime.controlDir 可直接写入 cfg.engine.interface.controlDir；C 端
% 仍按固定文件名 Turboshaft-TS-Split.mdl 加载配置，但运行目录与设计目录
% 已物理隔离。

if nargin < 1 || isempty(sourceDir)
    sourceDir = fileparts(mfilename('fullpath'));
end
sourceDir = char(sourceDir);

sourceModel = fullfile(sourceDir, 'Turboshaft-TS-Split.mdl');
designStateFile = fullfile(sourceDir, 'MiddleData', ...
    'RunModelSHT_V2_design_state.mat');
runtimeDir = fullfile(sourceDir, 'MiddleData', ...
    'control_model_runtime', 'mode1');
runtimeModel = fullfile(runtimeDir, 'Turboshaft-TS-Split.mdl');

assert(isfile(sourceModel), '缺少六部件设计配置：%s', sourceModel);
assert(isfile(designStateFile), '缺少V2设计状态：%s', designStateFile);

loaded = load(designStateFile, 'designState');
assert(isfield(loaded, 'designState'), ...
    'V2设计状态文件不含 designState：%s', designStateFile);
designState = loaded.designState;
local_validate_design_state(designState, designStateFile);

if ~isfolder(runtimeDir)
    mkdir(runtimeDir);
end

modelText = fileread(sourceModel);
runtimeText = local_apply_design_state(modelText, designState.design);
local_write_text(runtimeModel, runtimeText);

% DLL加载依赖和特性图全部复制到独立目录。只复制配置实际引用的MAP，
% 防止运行目录逐渐演变成第二套来源不明的程序工程。
supportFiles = {'GTESS.dll', 'GTESS.h', 'blockAndFunctions.h', ...
    'types_TMATS.H'};
mapFiles = local_collect_map_paths(runtimeText);
allFiles = [supportFiles, mapFiles];
for i = 1:numel(allFiles)
    source = fullfile(sourceDir, allFiles{i});
    destination = fullfile(runtimeDir, allFiles{i});
    assert(isfile(source), '六部件运行依赖不存在：%s', source);
    [ok, message] = copyfile(source, destination, 'f');
    assert(ok, '复制六部件运行依赖失败：%s', message);
end

runtime = struct();
runtime.modelMode = 1;
runtime.controlDir = runtimeDir;
runtime.modelFile = runtimeModel;
runtime.sourceModel = sourceModel;
runtime.designStateFile = designStateFile;
runtime.mapFiles = mapFiles(:);
runtime.generatedAt = datestr(now, 31);
runtime.designStateGeneratedAt = designState.generatedAt;
save(fullfile(runtimeDir, 'runtime_manifest.mat'), 'runtime', '-v7');
end

function local_validate_design_state(designState, path)
assert(isfield(designState, 'schemaVersion') && ...
    designState.schemaVersion >= 3, ...
    'V2设计状态版本过旧：%s', path);
assert(isfield(designState, 'modelMode') && designState.modelMode == 1, ...
    'V2设计状态不是六部件模型：%s', path);
assert(isfield(designState, 'design') && ...
    isfield(designState.design, 'commonVariables') && ...
    numel(designState.design.commonVariables) == 9 && ...
    isfield(designState.design, 'scalars'), ...
    'V2设计状态缺少九维共同工作变量或六部件缩放系数：%s', path);

componentNames = {'AC', 'CC', 'GT1', 'GT2', 'PT1', 'PT2'};
for i = 1:numel(componentNames)
    name = componentNames{i};
    assert(isfield(designState.design.scalars, name) && ...
        numel(designState.design.scalars.(name)) == 4 && ...
        all(isfinite(designState.design.scalars.(name))), ...
        'V2设计状态中的%s缩放系数无效：%s', name, path);
end
end

function text = local_apply_design_state(text, design)
lines = regexp(text, '\r\n|\n|\r', 'split');
lines = local_replace_global(lines, 'offDesignMode', '2');
lines = local_replace_global(lines, 'varStartVecDime', '9');
lines = local_replace_global(lines, 'varStartVec', ...
    local_format_vector(design.commonVariables));

compressorKeys = {'s_C_Nc_in', 's_C_Wc_in', 's_C_PR_in', 's_C_Eff_in'};
turbineKeys = {'s_T_Nc', 's_T_Wc', 's_T_PR', 's_T_Eff'};
for name = {'AC', 'CC'}
    values = design.scalars.(name{1});
    lines = local_replace_component_values( ...
        lines, name{1}, compressorKeys, values);
end
for name = {'GT1', 'GT2', 'PT1', 'PT2'}
    values = design.scalars.(name{1});
    lines = local_replace_component_values( ...
        lines, name{1}, turbineKeys, values);
end
text = strjoin(lines, newline);
end

function lines = local_replace_global(lines, key, value)
matches = find(cellfun(@(line) local_has_key(line, key), lines));
assert(numel(matches) == 1, ...
    '配置文件中的全局字段 %s 应恰好出现一次，实际为%d次。', ...
    key, numel(matches));
lines{matches} = local_replace_line(lines{matches}, key, value);
end

function lines = local_replace_component_values(lines, component, keys, values)
headers = find(strcmp(strtrim(lines), ['[componentName]=', component]));
assert(numel(headers) == 1, ...
    '配置文件中的部件 %s 应恰好出现一次。', component);
sectionEnd = numel(lines);
nextHeader = find(startsWith(strtrim(lines(headers + 1:end)), ...
    '[componentName]='), 1, 'first');
if ~isempty(nextHeader)
    sectionEnd = headers + nextHeader - 1;
end

for i = 1:numel(keys)
    localIndex = find(cellfun(@(line) local_has_key(line, keys{i}), ...
        lines(headers:sectionEnd)));
    assert(numel(localIndex) == 1, ...
        '部件%s中的字段%s应恰好出现一次。', component, keys{i});
    index = headers + localIndex - 1;
    lines{index} = local_replace_line( ...
        lines{index}, keys{i}, sprintf('%.17g', values(i)));
end
end

function tf = local_has_key(line, key)
tf = ~isempty(regexp(line, ...
    ['^[ \t]*', regexptranslate('escape', key), '[ \t]*='], 'once'));
end

function line = local_replace_line(oldLine, key, value)
indent = regexp(oldLine, '^[ \t]*', 'match', 'once');
line = sprintf('%s%s=%s', indent, key, value);
end

function value = local_format_vector(vector)
parts = arrayfun(@(x) sprintf('%.17g', x), vector(:).', ...
    'UniformOutput', false);
value = strjoin(parts, '   ');
end

function paths = local_collect_map_paths(modelText)
tokens = regexp(modelText, ...
    '(?m)^[ \t]*mapPath[ \t]*=[ \t]*([^\r\n]+?)[ \t]*$', ...
    'tokens');
paths = cellfun(@(token) strtrim(token{1}), tokens, ...
    'UniformOutput', false);
paths = unique(paths, 'stable');
assert(numel(paths) == 4, ...
    '六部件M1配置应引用4种MAP文件，实际识别到%d种。', numel(paths));
end

function local_write_text(path, text)
fileId = fopen(path, 'w');
assert(fileId >= 0, '无法写入六部件运行配置：%s', path);
cleanup = onCleanup(@() fclose(fileId));
count = fwrite(fileId, text, 'char');
assert(count == numel(text), '六部件运行配置写入不完整：%s', path);
clear cleanup;
end
