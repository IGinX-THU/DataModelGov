function result = Start_SteadyModelAdapt_V2_03_TransientInstantEstimation(trainingDataFile)
%START_STEADYMODELADAPT_V2_03_TRANSIENTINSTANTESTIMATION
% 第二轮六部件稳态修正系数估计入口二：瞬态时刻模型路径。
%
% 输入：Np、Ng、修正后Wf、Mkp、Mkg、Pamb、Tamb、Mach、测量Tt1
% 和测量Pt2。模式4由DLL重构Pt1，以测量Pt2直接作为AC进口压力，
% 并按进口模型方程逐工况反算Inlet_K_dP。联合估计只包含其余10个
% 发动机修正系数和1个燃油偏置，残差为Pt3、Tt3、Tt45、Pt45、
% dNp/dt和dNg/dt；稳态窗口的两个轴加速度目标均为0。
% trainingDataFile为空或省略时使用TestData目录下的默认训练集。
% 参数辨识只读取训练集；测试集验证由独立交付入口执行。
%
% 本程序不读取稳态模型路径结果，也不读取隐藏真值。两条路径的参数、
% 分组、初值和结果文件全部独立。

if nargin < 1
    trainingDataFile = '';
end
trainingDataFile = local_optional_file_name(trainingDataFile, ...
    'trainingDataFile');

options = sht_steady_model_adapt_v2_common( ...
    'defaultOptions', 'transient_instant');

% --------------------------- 入口配置 ---------------------------
options.clusterSpan = 0.010;
options.maxIterationA = 12;
options.maxIterationGroup = 4;
options.maxIterationRefine = 10; % 阶段D联合微调上限
options.maxModelResidual = 1e-2;
options.figureVisible = 'off';
options.verbose = true;
options.inletBoundaryMode = 4;
options.includePt2Residual = false;
options.estimateInletPressureLoss = false;
% A阶段方法开关：'tsvd'或'tikhonov'。
% 默认使用无阻尼TSVD r=6，即11个参数中严格截断5个方向；切换为
% Tikhonov时使用下方s=1.00。
options.stageARegularizationMethod = 'tsvd';
options.stageATikhonovPriorScale = 1.00;
options.stageATsvdTruncatedCount = 5;
options.stageATsvdRetainedCount = [];
options.stageATsvdStepMode = 'direct_inverse';
% B阶段方法开关：'tsvd'或'tikhonov'。
% 默认采用Tikhonov s=0.75；切换为无阻尼TSVD时保留r=5。
options.stageBRegularizationMethod = 'tikhonov';
options.stageBTikhonovPriorScale = 0.75;
options.stageBTsvdRetainedCount = 5;
% D阶段方法开关：'tsvd'或'tikhonov'。
% 默认采用Tikhonov s=1.00；切换为无阻尼TSVD时保留r=6。
options.stageDRegularizationMethod = 'tikhonov';
options.stageDTikhonovPriorScale = 1.0;
options.stageDTsvdRetainedCount = 6; % 仅切回TSVD研究模式时生效
options.stageDDifferenceStepScale = 0.5;
options.stageDInitialOffset = [];
options.stageAOnly = false;         % 运行阶段A、B、C和D完整辨识流程
options.evaluateSteadyTestFromTransient = false;
% 正式入口使用无后缀latest文件，供04独立真值验证和后续程序统一读取。
options.outputTag = '';
options.requireConvergedStages = true;
options.requireValidFinalReplay = true;
options.trainingFile = trainingDataFile;
options.evaluateTestSet = false;
options.testFile = '';
% ----------------------------------------------------------------

result = sht_steady_model_adapt_v2_common( ...
    'run', 'transient_instant', options);
estimatedParameterCount = height(result.parameterDefinition) + 1;
if estimatedParameterCount ~= 11
    error('SHT:SteadyAdaptV2Transient:BadParameterCount', ...
        ['正式瞬态路径必须估计10个发动机修正参数和1个燃油偏置，' ...
         '当前结果为%d个参数。'], estimatedParameterCount);
end
result.program = mfilename;
save(result.output.latestMatFile, 'result', '-v7.3');
if options.saveStampedResult
    save(result.output.stampedMatFile, 'result', '-v7.3');
end
assignin('base', 'SteadyModelAdaptV2TransientInstantResult', result);
end

function value = local_optional_file_name(value, name)
value = string(value);
if ~isscalar(value)
    error('SHT:SteadyAdaptV2Transient:BadFileName', ...
        '%s必须是字符向量或字符串标量。', name);
end
value = char(value);
end
