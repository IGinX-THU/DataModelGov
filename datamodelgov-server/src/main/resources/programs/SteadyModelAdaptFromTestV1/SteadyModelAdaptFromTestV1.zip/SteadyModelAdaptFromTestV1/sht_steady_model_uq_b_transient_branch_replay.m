function result = sht_steady_model_uq_b_transient_branch_replay( ...
        contract, theta, data, userOptions)
%SHT_STEADY_MODEL_UQ_B_TRANSIENT_BRANCH_REPLAY
% 对方法B后验粒子执行分层瞬态共同工作回放，并返回可直接用于稳态
% 模型的逐粒子、逐工况收敛初值。
%
% 求解顺序固定为：
%   1. 每个工况先求一次零修正模型共同工作解；
%   2. 全部粒子从零修正初值直接回放；
%   3. 仅对失败粒子从同一零初值启用稳健七维回退；
%   4. 仅对仍失败粒子执行0.25步长参数同伦；
%   5. 对粗同伦失败粒子从零重新执行0.1步长参数同伦。
%
% 本函数不改变参数、粒子权重或后验分布。参数同伦只用于沿连续
% 非线性共同工作分支构造目标参数下的数值初值。

if nargin < 4 || isempty(userOptions), userOptions = struct(); end
timer = tic;
if size(theta,1) ~= contract.parameterCount
    error('SHT:SteadyUQB:BranchReplayThetaDimension', ...
        '粒子矩阵必须为%d行。',contract.parameterCount);
end
if ~istable(data) || isempty(data)
    error('SHT:SteadyUQB:BranchReplayData', ...
        '分层回放数据必须为非空表。');
end
coarseGamma = local_option(userOptions,'coarseGamma',[0.25,0.50,0.75,1.00]);
fineGamma = local_option(userOptions,'fineGamma',0.1:0.1:1.0);
local_validate_gamma(coarseGamma,'coarseGamma');
local_validate_gamma(fineGamma,'fineGamma');

nParticle = size(theta,2);
nPoint = height(data);
valid = false(1,nParticle);
classification = repmat("failed",1,nParticle);
solutionSeed = cell(nParticle,1);
maximumResidual = nan(1,nParticle);
stagePath = strings(0,1);
stageGamma = nan(0,1);
evaluatedCount = zeros(0,1);
passedCount = zeros(0,1);

% 零修正解只求一次。允许稳健回退，避免把零模型自身的初值不足
% 混入后验粒子的分支诊断。
zero = sht_steady_model_uq_b_common('evaluate',contract, ...
    zeros(contract.parameterCount,1),data, ...
    struct('useCache',false,'returnPredictions',true, ...
    'returnDiagnostics',true,'useRobustTransientFallback',true));
if ~zero.valid(1) || any(~zero.diagnostic{1}.solutionAvailable)
    error('SHT:SteadyUQB:BranchReplayZeroModelInvalid', ...
        '零修正模型不能在全部回放工况提供共同工作初值。');
end
zeroSeed = zero.diagnostic{1}.solutionSeed;
if ~isequal(size(zeroSeed),[nPoint,9]) || any(~isfinite(zeroSeed(:)))
    error('SHT:SteadyUQB:BranchReplayZeroSeed', ...
        '零修正模型初值必须为工况数x9的有限矩阵。');
end

% 一级：零修正初值直接跳到完整粒子参数。
allIndex = 1:nParticle;
direct = local_evaluate(contract,theta,data,allIndex,zeroSeed,false);
directPass = local_complete_valid(direct);
[valid,classification,solutionSeed,maximumResidual] = local_store_success( ...
    valid,classification,solutionSeed,maximumResidual,allIndex, ...
    direct,directPass,"zero_seed_direct");
[stagePath,stageGamma,evaluatedCount,passedCount] = local_add_stage( ...
    stagePath,stageGamma,evaluatedCount,passedCount, ...
    "zero_seed_direct",NaN,numel(allIndex),nnz(directPass));

% 二级：只对直接回放失败粒子启用稳健局部求解。
robustIndex = allIndex(~directPass);
if ~isempty(robustIndex)
    robust = local_evaluate(contract,theta,data,robustIndex,zeroSeed,true);
    robustPass = local_complete_valid(robust);
    [valid,classification,solutionSeed,maximumResidual] = ...
        local_store_success(valid,classification,solutionSeed, ...
        maximumResidual,robustIndex,robust,robustPass, ...
        "zero_seed_robust");
else
    robustPass = false(1,0);
end
[stagePath,stageGamma,evaluatedCount,passedCount] = local_add_stage( ...
    stagePath,stageGamma,evaluatedCount,passedCount, ...
    "zero_seed_robust",NaN,numel(robustIndex),nnz(robustPass));

% 三级：只对两级直接求解都失败的粒子做粗参数同伦。
continuationIndex = robustIndex(~robustPass);
[coarseSuccess,coarseSeed,coarseResidual,coarseStage] = ...
    local_continuation(contract,theta,data,continuationIndex,zeroSeed, ...
    coarseGamma,"homotopy_coarse");
for i = 1:numel(coarseSuccess)
    index = coarseSuccess(i);
    valid(index) = true;
    classification(index) = "homotopy_coarse";
    solutionSeed{index} = coarseSeed{i};
    maximumResidual(index) = coarseResidual(i);
end
[stagePath,stageGamma,evaluatedCount,passedCount] = ...
    local_append_stage(stagePath,stageGamma,evaluatedCount,passedCount, ...
    coarseStage);

% 四级：粗同伦失败粒子从零初值重新按0.1步长推进。
fineIndex = setdiff(continuationIndex,coarseSuccess,'stable');
[fineSuccess,fineSeed,fineResidual,fineStage] = ...
    local_continuation(contract,theta,data,fineIndex,zeroSeed, ...
    fineGamma,"homotopy_fine");
for i = 1:numel(fineSuccess)
    index = fineSuccess(i);
    valid(index) = true;
    classification(index) = "homotopy_fine";
    solutionSeed{index} = fineSeed{i};
    maximumResidual(index) = fineResidual(i);
end
[stagePath,stageGamma,evaluatedCount,passedCount] = ...
    local_append_stage(stagePath,stageGamma,evaluatedCount,passedCount, ...
    fineStage);

stageTable = table(stagePath,stageGamma,evaluatedCount,passedCount, ...
    evaluatedCount-passedCount,'VariableNames',{'path','gamma', ...
    'evaluated_particle_count','passed_particle_count', ...
    'failed_particle_count'});
classTable = local_class_summary(classification);
result = struct('schemaVersion', ...
    'steady_uq_b_transient_branch_replay_v1', ...
    'particleCount',nParticle,'pointCount',nPoint, ...
    'valid',valid,'validParticleCount',nnz(valid), ...
    'classification',classification,'solutionSeed',{solutionSeed}, ...
    'maximumResidual',maximumResidual,'zeroSeed',zeroSeed, ...
    'coarseGamma',coarseGamma,'fineGamma',fineGamma, ...
    'stageTable',stageTable,'classTable',classTable, ...
    'runtime_s',toc(timer),'posteriorWasModified',false);
end

function exact = local_evaluate(contract,theta,data,index,seed,robust)
if isempty(index)
    exact = struct('valid',false(1,0),'prediction',{{}},'diagnostic',{{}});
    return;
end
seedCell = repmat({seed},numel(index),1);
exact = sht_steady_model_uq_b_common('evaluate',contract,theta(:,index), ...
    data,struct('useCache',false,'returnPredictions',true, ...
    'returnDiagnostics',true,'useRobustTransientFallback',robust, ...
    'initialSeedMatrices',{seedCell}));
end

function pass = local_complete_valid(exact)
pass = logical(exact.valid(:).');
for i = find(pass)
    diagnostic = exact.diagnostic{i};
    pass(i) = ~isempty(diagnostic) && ...
        all(diagnostic.solutionAvailable) && ...
        isequal(size(diagnostic.solutionSeed,2),9) && ...
        all(isfinite(diagnostic.solutionSeed(:)));
end
end

function [valid,classification,seed,residual] = local_store_success( ...
        valid,classification,seed,residual,index,exact,pass,label)
for i = find(pass)
    globalIndex = index(i);
    valid(globalIndex) = true;
    classification(globalIndex) = label;
    seed{globalIndex} = exact.diagnostic{i}.solutionSeed;
    residual(globalIndex) = max(exact.prediction{i}.max_model_residual);
end
end

function [successIndex,successSeed,successResidual,stage] = ...
        local_continuation(contract,theta,data,candidateIndex,zeroSeed, ...
        gammaGrid,path)
stage = table(strings(0,1),nan(0,1),zeros(0,1),zeros(0,1), ...
    'VariableNames',{'path','gamma','evaluated','passed'});
successIndex = zeros(1,0);
successSeed = cell(0,1);
successResidual = zeros(1,0);
if isempty(candidateIndex), return; end

activeIndex = candidateIndex(:).';
activeSeed = repmat({zeroSeed},numel(activeIndex),1);
for g = 1:numel(gammaGrid)
    gamma = gammaGrid(g);
    seedCell = activeSeed;
    exact = sht_steady_model_uq_b_common('evaluate',contract, ...
        gamma*theta(:,activeIndex),data, ...
        struct('useCache',false,'returnPredictions',true, ...
        'returnDiagnostics',true,'useRobustTransientFallback',true, ...
        'initialSeedMatrices',{seedCell}));
    pass = local_complete_valid(exact);
    stage(end+1,:) = {path,gamma,numel(activeIndex),nnz(pass)}; %#ok<AGROW>
    passedLocal = find(pass);
    if gamma == 1
        successIndex = activeIndex(pass);
        successSeed = cell(numel(successIndex),1);
        successResidual = nan(1,numel(successIndex));
        for i = 1:numel(passedLocal)
            localIndex = passedLocal(i);
            successSeed{i} = exact.diagnostic{localIndex}.solutionSeed;
            successResidual(i) = ...
                max(exact.prediction{localIndex}.max_model_residual);
        end
        return;
    end
    if ~any(pass), return; end
    nextSeed = cell(nnz(pass),1);
    for i = 1:numel(passedLocal)
        nextSeed{i} = exact.diagnostic{passedLocal(i)}.solutionSeed;
    end
    activeIndex = activeIndex(pass);
    activeSeed = nextSeed;
end
end

function tableOut = local_class_summary(classification)
name = unique(classification(:),'stable');
count = zeros(numel(name),1);
for i = 1:numel(name)
    count(i) = nnz(classification==name(i));
end
tableOut = table(name,count,'VariableNames', ...
    {'classification','particle_count'});
end

function [path,gamma,evaluated,passed] = local_add_stage( ...
        path,gamma,evaluated,passed,newPath,newGamma,newEvaluated,newPassed)
path(end+1,1) = newPath;
gamma(end+1,1) = newGamma;
evaluated(end+1,1) = newEvaluated;
passed(end+1,1) = newPassed;
end

function [path,gamma,evaluated,passed] = local_append_stage( ...
        path,gamma,evaluated,passed,stage)
if isempty(stage), return; end
path = [path;stage.path]; %#ok<AGROW>
gamma = [gamma;stage.gamma]; %#ok<AGROW>
evaluated = [evaluated;stage.evaluated]; %#ok<AGROW>
passed = [passed;stage.passed]; %#ok<AGROW>
end

function local_validate_gamma(value,name)
if ~isnumeric(value) || isempty(value) || any(~isfinite(value)) || ...
        any(value<=0) || any(value>1) || any(diff(value)<=0) || value(end)~=1
    error('SHT:SteadyUQB:BranchReplayGamma', ...
        '%s必须为严格递增、终点等于1的(0,1]有限向量。',name);
end
end

function value = local_option(options,name,defaultValue)
if isstruct(options) && isfield(options,name) && ~isempty(options.(name))
    value = options.(name);
else
    value = defaultValue;
end
end
