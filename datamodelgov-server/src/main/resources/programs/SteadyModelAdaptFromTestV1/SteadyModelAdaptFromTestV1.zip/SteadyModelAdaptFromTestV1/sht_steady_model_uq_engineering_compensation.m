function result = sht_steady_model_uq_engineering_compensation( ...
        contract,formal,likelihood,differenceStep,~)
%SHT_STEADY_MODEL_UQ_ENGINEERING_COMPENSATION 精确多参数工程补偿检验。
%
% 统计相关不能证明工程补偿。本函数在最高精确后验样本处重新计算
% 61维非线性模型的白化雅可比，在工程尺度归一化坐标中寻找最弱右
% 奇异方向，再沿每个候选方向连续取5点调用精确DLL。只有达到工程
% 幅值、预测仍在误差尺度内且精确后验仍支持时才认定补偿成立。

prior = sht_steady_model_uq_sampler('buildprior',contract,contract.priorType);
[~,anchorIndex] = max(formal.logLikelihood+formal.logPrior);
anchorTheta = formal.theta(:,anchorIndex);
anchorLogPosterior = formal.logLikelihood(anchorIndex)+formal.logPrior(anchorIndex);

[jacobian,whiteJacobian,step,retryCount,anchorResidual] = ...
    local_exact_jacobian(contract,likelihood,anchorTheta,differenceStep);
d = contract.parameterCount;
isFuel = contract.parameterTable.unit == "kg/s";
engineeringScale = 0.01*ones(d,1);
engineeringScale(isFuel) = 0.01*contract.scheduleTemplate.fuelBias.wfDesign;
scaledJacobian = whiteJacobian*diag(engineeringScale);
[~,S,V] = svd(scaledJacobian);
singularValue = zeros(d,1);
diagonal = diag(S);
singularValue(1:numel(diagonal)) = diagonal;

directionCount = min(12,d);
column = (d:-1:d-directionCount+1).';
pathCoordinate = [-0.5;-0.25;0;0.25;0.5];
maximumWhiteRms = 1.0;
maximumLogPosteriorDrop = 1.920729410347062; % 0.5*chi2inv(0.95,1)
direction = repmat(local_empty_direction(),directionCount,1);
allTheta = anchorTheta;
for k = 1:directionCount
    v = V(:,column(k));
    v = v/max(abs(v));
    physicalDirection = engineeringScale.*v;
    feasibleHalf = local_symmetric_bound_scale( ...
        anchorTheta,physicalDirection,contract.lowerBound,contract.upperBound);
    feasible = feasibleHalf >= 0.5;
    if feasible
        pathTheta = anchorTheta+physicalDirection*pathCoordinate.';
        evaluationRows = size(allTheta,2)+(1:numel(pathCoordinate));
        allTheta(:,end+1:end+numel(pathCoordinate)) = pathTheta; %#ok<AGROW>
    else
        pathTheta = nan(d,numel(pathCoordinate));
        evaluationRows = [];
    end
    [~,order] = sort(abs(v),'descend');
    dominant = order(1:min(5,d));
    direction(k) = struct('rank',k,'svd_column',column(k), ...
        'singular_value',singularValue(column(k)), ...
        'normalized_direction',v,'physical_direction',physicalDirection, ...
        'feasible_half_scale',feasibleHalf,'engineering_span_feasible',feasible, ...
        'path_theta',pathTheta,'evaluation_rows',evaluationRows, ...
        'dominant_parameter_index',dominant(:).', ...
        'dominant_parameter_name',{cellstr(contract.parameterTable.name(dominant).')}, ...
        'maximum_whitened_output_rms',NaN, ...
        'maximum_exact_log_posterior_drop',NaN, ...
        'all_path_points_valid',false,'prediction_equivalent',false, ...
        'posterior_supported',false,'compensation_supported',false, ...
        'interpretation','未执行：工程幅值受参数边界限制');
end

[uniqueTheta,~,inverse] = unique(allTheta.','rows');
uniqueTheta = uniqueTheta.';
exact = sht_steady_model_uq_common('evaluate',contract,uniqueTheta, ...
    contract.trainingData,struct('useCache',true));
logLikelihood = sht_steady_model_uq_likelihood( ...
    'evaluate',likelihood,exact.residual,exact.valid);
logPrior = sht_steady_model_uq_sampler('logprior',prior,uniqueTheta);
logPosterior = logLikelihood+logPrior;
pathRecord = repmat(local_empty_path(),0,1);
for k = 1:directionCount
    if ~direction(k).engineering_span_feasible, continue; end
    row = inverse(direction(k).evaluation_rows);
    whiteDifference = likelihood.cholLower\ ...
        (exact.residual(:,row)-anchorResidual);
    whiteRms = sqrt(mean(whiteDifference.^2,1));
    logDrop = anchorLogPosterior-logPosterior(row);
    valid = exact.valid(row)&isfinite(logPosterior(row));
    predictionEquivalent = all(whiteRms<=maximumWhiteRms);
    posteriorSupported = all(logDrop<=maximumLogPosteriorDrop);
    supported = all(valid)&&predictionEquivalent&&posteriorSupported;
    if supported
        interpretation = '精确路径证明存在工程量级多参数补偿';
    elseif ~all(valid)
        interpretation = '路径包含无效DLL工作点';
    elseif ~predictionEquivalent
        interpretation = '工程量级变化已超过冻结输出误差尺度';
    elseif ~posteriorSupported
        interpretation = '工程量级路径离开精确后验支持区域';
    else
        interpretation = '当前局部路径未证明工程补偿';
    end
    direction(k).maximum_whitened_output_rms = max(whiteRms);
    direction(k).maximum_exact_log_posterior_drop = max(logDrop);
    direction(k).all_path_points_valid = all(valid);
    direction(k).prediction_equivalent = predictionEquivalent;
    direction(k).posterior_supported = posteriorSupported;
    direction(k).compensation_supported = supported;
    direction(k).interpretation = interpretation;
    for p = 1:numel(pathCoordinate)
        pathRecord(end+1) = struct('direction_rank',k, ... %#ok<AGROW>
            'path_coordinate',pathCoordinate(p), ...
            'valid',valid(p),'whitened_output_rms',whiteRms(p), ...
            'exact_log_posterior_drop',logDrop(p));
    end
end

directionTable = local_direction_table(direction,contract);
if isempty(pathRecord)
    pathTable = struct2table(repmat(local_empty_path(),0,1));
else
    pathTable = struct2table(pathRecord);
end
result = struct('method','exact_multivariate_weak_svd_profiles', ...
    'anchorTheta',anchorTheta,'anchorSampleIndex',anchorIndex, ...
    'anchorLogPosterior',anchorLogPosterior,'jacobian',jacobian, ...
    'whitenedJacobian',whiteJacobian,'scaledWhitenedJacobian',scaledJacobian, ...
    'differenceStep',step,'differenceRetryCount',retryCount, ...
    'engineeringScale',engineeringScale,'singularValues',singularValue, ...
    'pathCoordinate',pathCoordinate,'maximumWhitenedOutputRms',maximumWhiteRms, ...
    'maximumLogPosteriorDrop',maximumLogPosteriorDrop, ...
    'direction',direction,'directionTable',directionTable, ...
    'pathTable',pathTable,'testedDirectionCount',directionCount, ...
    'feasibleDirectionCount',nnz(directionTable.engineering_span_feasible), ...
    'supportedDirectionCount',nnz(directionTable.compensation_supported), ...
    'exactUniquePointCount',size(uniqueTheta,2), ...
    'exactDllReplayCount',exact.dllEvaluationCount, ...
    'statisticalCorrelationUsedAsProof',false, ...
    'scope',['未通过只否定当前局部直线弱方向；不排除更远的非线性流形，' ...
        '通过则已由精确DLL证明局部工程量级补偿'], ...
    'passed',all(~directionTable.engineering_span_feasible | ...
        directionTable.path_points_valid));
end

function [J,Jwhite,step,retryCount,anchorResidual] = ...
        local_exact_jacobian(contract,likelihood,anchor,initialStep)
d = contract.parameterCount;
step = min(initialStep(:),0.20*min( ...
    anchor-contract.lowerBound,contract.upperBound-anchor));
retryCount = zeros(d,1);
for retry = 0:8
    candidate = zeros(d,1+2*d);
    candidate(:,1) = anchor;
    for j = 1:d
        candidate(:,2*j) = anchor;
        candidate(j,2*j) = candidate(j,2*j)+step(j);
        candidate(:,2*j+1) = anchor;
        candidate(j,2*j+1) = candidate(j,2*j+1)-step(j);
    end
    exact = sht_steady_model_uq_common('evaluate',contract,candidate, ...
        contract.trainingData,struct('useCache',true));
    failed = false(d,1);
    for j = 1:d
        failed(j) = ~(exact.valid(2*j)&&exact.valid(2*j+1));
    end
    if ~any(failed), break; end
    step(failed) = 0.5*step(failed);
    retryCount(failed) = retryCount(failed)+1;
end
if any(failed) || ~exact.valid(1)
    error('SHT:SteadyUQ:EngineeringJacobianReplay', ...
        '递减差分后工程补偿锚点仍存在无效候选。');
end
anchorResidual = exact.residual(:,1);
J = zeros(contract.observationDimension,d);
for j = 1:d
    J(:,j) = (exact.residual(:,2*j)-exact.residual(:,2*j+1))/(2*step(j));
end
Jwhite = likelihood.cholLower\J;
end

function scale = local_symmetric_bound_scale(theta,direction,lower,upper)
scale = inf;
for j = 1:numel(theta)
    if direction(j)>0
        candidate = min((upper(j)-theta(j))/direction(j), ...
            (theta(j)-lower(j))/direction(j));
    elseif direction(j)<0
        candidate = min((theta(j)-lower(j))/(-direction(j)), ...
            (upper(j)-theta(j))/(-direction(j)));
    else
        continue;
    end
    scale = min(scale,candidate);
end
if ~isfinite(scale), scale = 0; end
scale = max(0,0.999*scale);
end

function value = local_empty_direction()
value = struct('rank',NaN,'svd_column',NaN,'singular_value',NaN, ...
    'normalized_direction',[],'physical_direction',[], ...
    'feasible_half_scale',NaN,'engineering_span_feasible',false, ...
    'path_theta',[],'evaluation_rows',[], ...
    'dominant_parameter_index',[],'dominant_parameter_name',{{}}, ...
    'maximum_whitened_output_rms',NaN, ...
    'maximum_exact_log_posterior_drop',NaN, ...
    'all_path_points_valid',false,'prediction_equivalent',false, ...
    'posterior_supported',false,'compensation_supported',false, ...
    'interpretation','');
end

function value = local_empty_path()
value = struct('direction_rank',NaN,'path_coordinate',NaN, ...
    'valid',false,'whitened_output_rms',NaN, ...
    'exact_log_posterior_drop',NaN);
end

function tableOut = local_direction_table(direction,contract)
n = numel(direction);
rankValue = zeros(n,1); singular = zeros(n,1); feasibleHalf = zeros(n,1);
feasible = false(n,1); whiteRms = nan(n,1); logDrop = nan(n,1);
valid = false(n,1); prediction = false(n,1); posterior = false(n,1);
supported = false(n,1); dominant = strings(n,1); interpretation = strings(n,1);
for i = 1:n
    item = direction(i);
    rankValue(i) = item.rank;
    singular(i) = item.singular_value;
    feasibleHalf(i) = item.feasible_half_scale;
    feasible(i) = item.engineering_span_feasible;
    whiteRms(i) = item.maximum_whitened_output_rms;
    logDrop(i) = item.maximum_exact_log_posterior_drop;
    valid(i) = item.all_path_points_valid;
    prediction(i) = item.prediction_equivalent;
    posterior(i) = item.posterior_supported;
    supported(i) = item.compensation_supported;
    dominantCount = min(5,numel(item.dominant_parameter_index));
    dominant(i) = strjoin(cellstr(contract.parameterTable.name( ...
        item.dominant_parameter_index(1:dominantCount))),', ');
    interpretation(i) = string(item.interpretation);
end
tableOut = table(rankValue,singular,feasibleHalf,feasible,whiteRms,logDrop, ...
    valid,prediction,posterior,supported,dominant,interpretation, ...
    'VariableNames',{'direction_rank','local_scaled_singular_value', ...
    'feasible_half_scale','engineering_span_feasible', ...
    'maximum_whitened_output_rms','maximum_exact_log_posterior_drop', ...
    'path_points_valid','prediction_equivalent','posterior_supported', ...
    'compensation_supported','dominant_parameters','interpretation'});
end
