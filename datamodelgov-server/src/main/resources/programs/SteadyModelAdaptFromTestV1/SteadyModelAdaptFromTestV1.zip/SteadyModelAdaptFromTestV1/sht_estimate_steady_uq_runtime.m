function result = sht_estimate_steady_uq_runtime(method, userCfg)
%SHT_ESTIMATE_STEADY_UQ_RUNTIME 轻量估计2.4稳态UQ正式运行时间。
%
% result = sht_estimate_steady_uq_runtime('A', cfg)
% result = sht_estimate_steady_uq_runtime('B', cfg)
%
% 本函数只建立概率合同并执行少量单候选DLL试算。若存在同方法历史正式
% 运行，则按粒子配置、训练工况数量和当前试算速度缩放历史墙钟时间；
% 否则采用保守工作量模型。函数不会启动SMC或完整后验预测。

if nargin < 1 || isempty(method), method = 'B'; end
if nargin < 2 || isempty(userCfg), userCfg = struct(); end
if ~ischar(method) && ~(isstring(method) && isscalar(method))
    error('SHT:SteadyUQRuntime:BadMethod', 'method必须为A或B。');
end
if ~isstruct(userCfg) || ~isscalar(userCfg)
    error('SHT:SteadyUQRuntime:BadConfig', ...
        'userCfg必须为标量结构体。');
end
method = upper(char(method));
if ~ismember(method, {'A','B'})
    error('SHT:SteadyUQRuntime:BadMethod', 'method必须为A或B。');
end

timer = tic;
probePointCountRequested = local_option(userCfg, 'probePointCount', 2);
probeRepeatCount = local_option(userCfg, 'probeRepeatCount', 2);
local_positive_integer(probePointCountRequested, 'probePointCount');
local_positive_integer(probeRepeatCount, 'probeRepeatCount');

[cfg, contract, data, referenceTheta] = ...
    local_contract(method, userCfg);
probePointCount = min(probePointCountRequested, height(data));
probeData = data(1:probePointCount, :);
probeTheta = repmat(referenceTheta(:), 1, probeRepeatCount);
probeTimer = tic;
if strcmp(method, 'A')
    probe = sht_steady_model_uq_common('evaluate', contract, ...
        probeTheta, probeData, struct('useCache', false));
else
    probe = sht_steady_model_uq_b_common('evaluate', contract, ...
        probeTheta, probeData, struct('useCache', false, ...
        'useRobustTransientFallback', true));
end
probeWallTime = toc(probeTimer);
if ~any(probe.valid)
    error('SHT:SteadyUQRuntime:ProbeFailed', ...
        '少量DLL试算全部失败，不能形成可信运行时间估计。');
end
probeDllTime = probe.dllRuntime_s;
if ~isfinite(probeDllTime) || probeDllTime <= 0
    probeDllTime = probeWallTime;
end
secondsPerCandidatePoint = probeDllTime / ...
    (probeRepeatCount * probePointCount);

history = local_history(method);
if history.available
    currentWork = local_work_units( ...
        method, cfg, contract.parameterCount, history.stageCount);
    historicalWork = local_work_units( ...
        method, history.config, history.parameterCount, ...
        history.stageCount);
    workRatio = currentWork / historicalWork;
    pointRatio = height(data) / history.trainingPointCount;
    speedRatio = secondsPerCandidatePoint / ...
        history.secondsPerCandidatePoint;
    speedRatio = min(max(speedRatio, 0.50), 2.00);
    centerSeconds = history.totalRuntime_s * ...
        workRatio * pointRatio * speedRatio;
    source = 'latest_compatible_history_scaled_by_current_dll_probe';
    estimatedDllEvaluationCount = round( ...
        history.dllEvaluationCount * workRatio);
else
    stageCount = local_default_stage_count(method);
    work = local_work_units(method, cfg, contract.parameterCount, stageCount);
    overheadFactor = local_default_overhead_factor(method);
    centerSeconds = secondsPerCandidatePoint * height(data) * ...
        work * overheadFactor;
    source = 'conservative_workload_model_calibrated_by_current_dll_probe';
    estimatedDllEvaluationCount = round(work);
    workRatio = NaN;
    pointRatio = NaN;
    speedRatio = NaN;
end

lowerSeconds = 0.70 * centerSeconds;
upperSeconds = 1.50 * centerSeconds;
result = struct();
result.schemaVersion = 'SHT_STEADY_UQ_RUNTIME_ESTIMATE_V1';
result.createdAt = datestr(now, 31);
result.method = method;
result.source = source;
result.estimatedCenter_s = centerSeconds;
result.estimatedLower_s = lowerSeconds;
result.estimatedUpper_s = upperSeconds;
result.estimatedCenterText = local_duration_text(centerSeconds);
result.estimatedRangeText = sprintf('%s 至 %s', ...
    local_duration_text(lowerSeconds), local_duration_text(upperSeconds));
result.trainingPointCount = height(data);
result.parameterCount = contract.parameterCount;
result.pilotSampleCount = cfg.pilotSampleCount;
result.pilotReplicateCount = cfg.pilotReplicateCount;
result.formalSampleCount = cfg.formalSampleCount;
result.posteriorPredictiveSampleCount = ...
    cfg.posteriorPredictiveSampleCount;
result.estimatedDllEvaluationCount = estimatedDllEvaluationCount;
result.probe = struct('pointCount', probePointCount, ...
    'repeatCount', probeRepeatCount, ...
    'validCount', nnz(probe.valid), ...
    'wallTime_s', probeWallTime, 'dllTime_s', probeDllTime, ...
    'secondsPerCandidatePoint', secondsPerCandidatePoint);
result.history = history;
result.scaling = struct('workRatio', workRatio, ...
    'pointRatio', pointRatio, 'speedRatio', speedRatio);
result.fullUqExecuted = false;
result.runtime_s = toc(timer);

fprintf('\n=== 稳态UQ运行时间轻量预估 ===\n');
fprintf('方法：%s；训练工况：%d；参数：%d。\n', ...
    method, result.trainingPointCount, result.parameterCount);
fprintf('DLL试算：%d个工况 x %d次，%.3f s。\n', ...
    probePointCount, probeRepeatCount, probeDllTime);
fprintf('预计正式运行：%s（中心估计%s）。\n', ...
    result.estimatedRangeText, result.estimatedCenterText);
fprintf('估算来源：%s；完整UQ执行：0。\n', source);
end

function [cfg, contract, data, referenceTheta] = ...
        local_contract(method, userCfg)
if strcmp(method, 'A')
    cfg = sht_steady_model_uq_common('defaultconfig', userCfg);
    contract = sht_steady_model_uq_common('buildcontract', cfg);
else
    cfg = sht_steady_model_uq_b_common('defaultconfig', userCfg);
    contract = sht_steady_model_uq_b_common('buildcontract', cfg);
end
data = contract.trainingData;
if strcmp(method, 'A')
    % 方法A以D阶段辨识结果为合同内的代表点；方法B的独立零中心
    % 先验则显式提供referencePoint。这里只选少量DLL计时点，不参与推断。
    referenceTheta = contract.thetaHat;
else
    referenceTheta = contract.referencePoint;
end
end

function history = local_history(method)
history = struct('available', false, 'runId', '', ...
    'totalRuntime_s', NaN, 'trainingPointCount', NaN, ...
    'parameterCount', NaN, 'stageCount', NaN, ...
    'dllEvaluationCount', NaN, 'dllRuntime_s', NaN, ...
    'secondsPerCandidatePoint', NaN, 'config', struct());
try
    if strcmp(method, 'A')
        manifest = sht_steady_model_uq_io('resolve', struct());
        step1 = sht_steady_model_uq_io('loadstep', manifest, 1);
        step8 = sht_steady_model_uq_io('loadstep', manifest, 8);
    else
        manifest = sht_steady_model_uq_b_io('resolve', struct());
        step1 = sht_steady_model_uq_b_io('loadstep', manifest, 1);
        step8 = sht_steady_model_uq_b_io('loadstep', manifest, 8);
    end
    formal = step8.formal;
    totalRuntime = sum(manifest.stepRuntime_s(isfinite( ...
        manifest.stepRuntime_s)));
    perCandidatePoint = formal.dllRuntime_s / ...
        (formal.dllEvaluationCount * step1.contract.trainingPointCount);
    valid = totalRuntime > 0 && formal.stageCount > 0 && ...
        formal.dllEvaluationCount > 0 && isfinite(perCandidatePoint) && ...
        perCandidatePoint > 0;
    if valid
        history.available = true;
        history.runId = manifest.runId;
        history.totalRuntime_s = totalRuntime;
        history.trainingPointCount = step1.contract.trainingPointCount;
        history.parameterCount = step1.contract.parameterCount;
        history.stageCount = formal.stageCount;
        history.dllEvaluationCount = formal.dllEvaluationCount;
        history.dllRuntime_s = formal.dllRuntime_s;
        history.secondsPerCandidatePoint = perCandidatePoint;
        history.config = step1.contract.config;
    end
catch exception
    history.errorIdentifier = exception.identifier;
    history.errorMessage = exception.message;
end
end

function work = local_work_units(method, cfg, parameterCount, stageCount)
if strcmp(method, 'A')
    moveSweeps = 2;
else
    moveSweeps = 1;
end
setup = 1 + 2 * parameterCount;
pilot = cfg.pilotSampleCount * cfg.pilotReplicateCount * ...
    (1 + max(1, 0.5 * stageCount));
formal = cfg.formalSampleCount * (1 + moveSweeps * stageCount);
prediction = cfg.posteriorPredictiveSampleCount;
work = setup + pilot + formal + prediction;
end

function count = local_default_stage_count(method)
if strcmp(method, 'A')
    count = 24;
else
    count = 26;
end
end

function factor = local_default_overhead_factor(method)
if strcmp(method, 'A')
    factor = 3.2;
else
    factor = 4.8;
end
end

function text = local_duration_text(seconds)
if seconds < 60
    text = sprintf('%.1f s', seconds);
elseif seconds < 3600
    text = sprintf('%.1f min', seconds / 60);
else
    text = sprintf('%.2f h', seconds / 3600);
end
end

function local_positive_integer(value, name)
if ~isscalar(value) || ~isfinite(value) || value < 1 || ...
        value ~= round(value)
    error('SHT:SteadyUQRuntime:BadInteger', ...
        '%s必须为正整数。', name);
end
end

function value = local_option(options, name, defaultValue)
value = defaultValue;
if isfield(options, name) && ~isempty(options.(name))
    value = options.(name);
end
end
