function result = Start_SteadyModelUQ_05_ExactLikelihoodVerification(userCfg)
%START_STEADYMODELUQ_05_EXACTLIKELIHOODVERIFICATION 验证似然并构造局部提议尺度。
if nargin < 1, userCfg = struct(); end
timer = tic;
manifest = sht_steady_model_uq_io('resolve', userCfg);
step1 = sht_steady_model_uq_io('loadstep', manifest, 1);
step4 = sht_steady_model_uq_io('loadstep', manifest, 4);
contract = step1.contract;
likelihood = sht_steady_model_uq_likelihood('build', step4.measurement);

step = contract.parameterTable.difference_step;
step = min(step, 0.20*min(contract.thetaHat-contract.lowerBound, ...
    contract.upperBound-contract.thetaHat));
if any(step <= 0)
    error('SHT:SteadyUQ:BadLikelihoodDifferenceStep', '似然差分步长非正。');
end
retryCount = zeros(contract.parameterCount,1);
[candidate,exact] = local_evaluate_axis_pairs(contract,step);
for retry = 1:8
    failed = false(contract.parameterCount,1);
    for j = 1:contract.parameterCount
        failed(j) = ~(exact.valid(2*j) && exact.valid(2*j+1));
    end
    if ~any(failed), break; end
    step(failed) = 0.5*step(failed);
    retryCount(failed) = retryCount(failed)+1;
    [candidate,exact] = local_evaluate_axis_pairs(contract,step);
end
[logLikelihood, detail] = sht_steady_model_uq_likelihood( ...
    'evaluate', likelihood, exact.residual, exact.valid);
if any(~isfinite(logLikelihood))
    error('SHT:SteadyUQ:LikelihoodAxisVerificationFailed', ...
        '递减中心差分后仍有锚点或轴向候选的精确似然无效。');
end
J = zeros(contract.observationDimension, contract.parameterCount);
for j = 1:contract.parameterCount
    J(:,j) = (exact.residual(:,2*j) - exact.residual(:,2*j+1)) / (2*step(j));
end
whitenedJ = likelihood.cholLower \ J;
priorPrecision = contract.priorCovariance \ eye(contract.parameterCount);
priorPrecision = 0.5*(priorPrecision+priorPrecision.');
precision = whitenedJ.'*whitenedJ + priorPrecision;
precision = 0.5*(precision+precision.');
[V,D] = eig(precision);
eigenvalue = max(real(diag(D)), 1e-10*max(real(diag(D))));
localCovariance = V*diag(1./eigenvalue)*V.';
localCovariance = 0.5*(localCovariance+localCovariance.');
[latentTransformJacobian,thetaHatLatent] = ...
    local_prior_latent_jacobian(step1.prior,contract.thetaHat);
latentWhitenedJacobian = whitenedJ*latentTransformJacobian;
[~,latentSingularMatrix,latentBasis] = svd(latentWhitenedJacobian);
latentSingularValues = diag(latentSingularMatrix);
latentInformedRank = rank(latentWhitenedJacobian);
gradient = J.'*(likelihood.covariance\exact.residual(:,1)) + ...
    priorPrecision*contract.thetaHat;
thetaLaplace = contract.thetaHat - localCovariance*gradient;
margin = 1e-8*(contract.upperBound-contract.lowerBound);
thetaLaplace = min(max(thetaLaplace,contract.lowerBound+margin), ...
    contract.upperBound-margin);
laplaceExact = sht_steady_model_uq_common('evaluate', contract, thetaLaplace, ...
    contract.trainingData, struct('useCache', true));
[laplaceLogLikelihood, laplaceDetail] = sht_steady_model_uq_likelihood( ...
    'evaluate', likelihood, laplaceExact.residual, laplaceExact.valid);
anchorLogPrior = sht_steady_model_uq_sampler( ...
    'logprior',step1.prior,contract.thetaHat);
laplaceLogPrior = sht_steady_model_uq_sampler( ...
    'logprior',step1.prior,thetaLaplace);
rawThetaLaplace = thetaLaplace;
rawLaplaceExact = laplaceExact;
rawLaplaceLogLikelihood = laplaceLogLikelihood;
rawLaplaceMahalanobisSquared = laplaceDetail.mahalanobisSquared;
if ~laplaceExact.valid || ...
        laplaceLogLikelihood+laplaceLogPrior < logLikelihood(1)+anchorLogPrior
    thetaLaplace = contract.thetaHat;
    laplaceExact = local_exact_column(exact,1);
    laplaceLogLikelihood = logLikelihood(1);
    laplaceDetail.mahalanobisSquared = detail.mahalanobisSquared(1);
    selectedAnchorSource = 'stage_d_exact_anchor';
else
    selectedAnchorSource = 'one_step_local_update';
end

zeroResidualLog = sht_steady_model_uq_likelihood( ...
    'evaluate', likelihood, zeros(contract.observationDimension,1), true);
analyticZero = likelihood.logNormalizingConstant;
passed = abs(zeroResidualLog-analyticZero) <= 1e-10 && ...
    all(isfinite(J(:))) && laplaceExact.valid;
if ~passed
    error('SHT:SteadyUQ:LikelihoodVerificationFailed', ...
        '高斯解析值、局部雅可比或局部锚点验收失败。');
end
result = struct('likelihood', likelihood, 'differenceStep', step, ...
    'differenceRetryCount',retryCount, ...
    'anchorCandidates', candidate, 'anchorExact', exact, ...
    'anchorLogLikelihood', logLikelihood, 'anchorDetail', detail, ...
    'jacobian', J, 'whitenedJacobian', whitenedJ, ...
    'localPrecision', precision, 'localCovariance', localCovariance, ...
    'priorPrecisionApproximation',priorPrecision, ...
    'whitenedJacobianSingularValues',svd(whitenedJ,'econ'), ...
    'whitenedJacobianRank',rank(whitenedJ), ...
    'thetaHatIndependentPriorLatent',thetaHatLatent, ...
    'latentTransformJacobian',latentTransformJacobian, ...
    'latentWhitenedJacobian',latentWhitenedJacobian, ...
    'latentSingularValues',latentSingularValues, ...
    'latentPcnBasis',latentBasis, ...
    'latentInformedRank',latentInformedRank, ...
    'thetaLaplace', thetaLaplace, 'laplaceExact', laplaceExact, ...
    'laplaceLogLikelihood', laplaceLogLikelihood, ...
    'laplaceMahalanobisSquared', laplaceDetail.mahalanobisSquared, ...
    'selectedAnchorSource',selectedAnchorSource, ...
    'rawThetaLaplace',rawThetaLaplace, ...
    'rawLaplaceExact',rawLaplaceExact, ...
    'rawLaplaceLogLikelihood',rawLaplaceLogLikelihood, ...
    'rawLaplaceMahalanobisSquared',rawLaplaceMahalanobisSquared, ...
    'zeroResidualAnalyticCheckError', abs(zeroResidualLog-analyticZero), ...
    'passed', passed, 'truthRead', false, 'testDataRead', false);
runtime = toc(timer);
[manifest, file] = sht_steady_model_uq_io( ...
    'savestep', manifest, 5, 'exact_likelihood_verification', result, runtime);
fprintf('[2.4UQ.5] 似然验收通过：锚点Mahalanobis^2=%.3f，局部建议点=%.3f。\n', ...
    detail.mahalanobisSquared(1), laplaceDetail.mahalanobisSquared);
fprintf('[2.4UQ.5] 提议锚点来源：%s。\n',selectedAnchorSource);
fprintf('[2.4UQ.5] 信息结构：J=%dx%d，数值秩=%d，中心差分候选=%d。\n', ...
    size(J,1),size(J,2),rank(whitenedJ),size(candidate,2));
if any(retryCount>0)
    fprintf('[2.4UQ.5] %d个节点缩小过差分步长，最大重试%d次。\n', ...
        nnz(retryCount>0),max(retryCount));
end
fprintf('[2.4UQ.5] 产物：%s\n', file);
result.manifest = manifest;
end

function [candidate,exact] = local_evaluate_axis_pairs(contract,step)
candidate = zeros(contract.parameterCount,1+2*contract.parameterCount);
candidate(:,1) = contract.thetaHat;
for j = 1:contract.parameterCount
    candidate(:,2*j) = contract.thetaHat;
    candidate(j,2*j) = candidate(j,2*j)+step(j);
    candidate(:,2*j+1) = contract.thetaHat;
    candidate(j,2*j+1) = candidate(j,2*j+1)-step(j);
end
exact = sht_steady_model_uq_common('evaluate',contract,candidate, ...
    contract.trainingData,struct('useCache',true));
end

function output = local_exact_column(exact,index)
output = exact;
output.theta = exact.theta(:,index);
output.residual = exact.residual(:,index);
output.valid = exact.valid(index);
output.prediction = exact.prediction(index);
output.insideBounds = exact.insideBounds(index);
output.candidateCount = 1;
output.cacheHitCount = double(index<=exact.cacheHitCount);
output.dllEvaluationCount = 0;
end

function [transform,latent] = local_prior_latent_jacobian(prior,theta)
% 高斯Copula潜变量到有界节点参数的局部精确导数，仅用于设计pCN基。
latent = sht_steady_model_uq_sampler('thetatolatent',prior,theta);
correlatedLatent = prior.cholCorrelation*latent;
zMarginal = (theta-prior.mean)./prior.sigma;
phiCorrelated = exp(-0.5*correlatedLatent.^2)/sqrt(2*pi);
phiMarginal = max(exp(-0.5*zMarginal.^2)/sqrt(2*pi),realmin);
diagonal = prior.sigma.*prior.normalization.*phiCorrelated./phiMarginal;
transform = diag(diagonal)*prior.cholCorrelation;
end
