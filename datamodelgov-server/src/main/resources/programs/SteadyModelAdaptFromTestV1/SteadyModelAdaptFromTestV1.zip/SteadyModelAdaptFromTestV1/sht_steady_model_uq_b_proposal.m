function varargout = sht_steady_model_uq_b_proposal(action,varargin)
%SHT_STEADY_MODEL_UQ_B_PROPOSAL 方法B的先验潜空间防御混合提议。
%
% 提议在独立标准正态先验潜变量z中定义。全局分量严格等于N(0,I)；
% 局部分量只沿局部雅可比识别出的信息方向移动均值并缩小方差，局部
% 弱信息方向和结构无关方向仍保持N(0,1)。所有样本通过既有先验映射
% 转回物理参数，重要性权重中的变量变换Jacobian自动相消。

switch lower(char(action))
    case 'build'
        varargout{1} = local_build(varargin{:});
    case 'sample'
        [varargout{1:nargout}] = local_sample(varargin{:});
    case 'logdensity'
        varargout{1} = local_log_density(varargin{:});
    case 'logpriorlatent'
        varargout{1} = local_standard_normal_log_density(varargin{:});
    case 'selftest'
        varargout{1} = local_self_test(varargin{:});
    otherwise
        error('SHT:SteadyUQB:UnknownLatentProposalAction', ...
            '未知方法B潜空间提议动作：%s。',action);
end
end

function proposal = local_build(prior,step5,user)
if nargin < 3 || isempty(user), user = struct(); end
activeIndex = step5.activeParameterIndex(:);
priorOnlyIndex = step5.structuralPriorOnlyParameterIndex(:);
if numel(activeIndex)+numel(priorOnlyIndex) ~= prior.dimension || ...
        ~isempty(intersect(activeIndex,priorOnlyIndex))
    error('SHT:SteadyUQB:LatentProposalPartition', ...
        '活动方向与解析先验方向没有构成完整且互斥的参数划分。');
end
basis = step5.activeLatentPcnBasis;
rankValue = step5.activeLatentInformedRank;
singularValue = step5.activeLatentSingularValues(:);
if numel(singularValue) < rankValue
    error('SHT:SteadyUQB:LatentProposalSingularValues', ...
        '活动潜空间奇异值数量小于信息秩。');
end

% 全局先验分量必须略高于SMC默认的50% ESS门限。这样既能保留全局
% 覆盖，又可用近一半样本主动播种局部高概率区；全部样本仍通过p/q
% 重要性权重恢复为原始先验，局部参考点不会被偷换成贝叶斯先验。
priorWeight = local_option(user,'priorWeight',0.55);
% 1.50倍尺度在本问题42个信息方向上过宽，有限样本仍无法到达已知
% 高后验区。0.75倍局部曲率尺度经独立精确DLL预审可将参考差值压到
% 门限内，同时保留55%的原先验分量负责全局和潜在多峰覆盖。
inflation = local_option(user,'informedScaleInflation',0.75);
minimumScale = local_option(user,'minimumInformedScale',0.02);
if priorWeight <= 0 || priorWeight >= 1 || inflation <= 0 || ...
        minimumScale <= 0 || minimumScale > 1
    error('SHT:SteadyUQB:BadLatentProposalConfiguration', ...
        '潜空间提议权重、尺度膨胀或最小尺度配置无效。');
end

localLatent = sht_steady_model_uq_sampler( ...
    'thetatolatent',prior,step5.thetaLocal);
localCoordinate = basis.'*localLatent(activeIndex);
meanCoordinate = zeros(numel(activeIndex),1);
meanCoordinate(1:rankValue) = localCoordinate(1:rankValue);
scaleCoordinate = ones(numel(activeIndex),1);
laplaceScale = 1./sqrt(1+singularValue(1:rankValue).^2);
scaleCoordinate(1:rankValue) = min(1,max(minimumScale, ...
    inflation*laplaceScale));

proposal = struct( ...
    'schemaVersion','steady_uq_b_prior_latent_defensive_v1', ...
    'prior',prior,'dimension',prior.dimension, ...
    'activeIndex',activeIndex,'priorOnlyIndex',priorOnlyIndex, ...
    'activeBasis',basis,'informedRank',rankValue, ...
    'meanCoordinate',meanCoordinate,'scaleCoordinate',scaleCoordinate, ...
    'priorWeight',priorWeight,'localWeight',1-priorWeight, ...
    'informedScaleInflation',inflation, ...
    'minimumInformedScale',minimumScale,'componentCount',2, ...
    'modeCount',1,'createdAt',datestr(now,30));
end

function [theta,latent,component] = local_sample(proposal,count,seed)
if nargin >= 3 && ~isempty(seed), rng(seed,'twister'); end
if count < 1 || count ~= floor(count)
    error('SHT:SteadyUQB:BadLatentProposalSampleCount', ...
        '潜空间提议样本数必须为正整数。');
end
d = proposal.dimension;
latent = randn(d,count);
component = ones(1,count);
useLocal = rand(1,count) > proposal.priorWeight;
component(useLocal) = 2;
if any(useLocal)
    nLocal = nnz(useLocal);
    coordinate = proposal.meanCoordinate + ...
        proposal.scaleCoordinate.*randn(numel(proposal.activeIndex),nLocal);
    latent(proposal.activeIndex,useLocal) = proposal.activeBasis*coordinate;
    % priorOnlyIndex对应的局部分量与全局先验完全相同，保留初始randn。
end
theta = sht_steady_model_uq_sampler( ...
    'latenttotheta',proposal.prior,latent);
end

function value = local_log_density(proposal,latent)
if size(latent,1) ~= proposal.dimension
    error('SHT:SteadyUQB:LatentProposalDimension', ...
        '潜变量矩阵必须为%d行。',proposal.dimension);
end
logPrior = local_standard_normal_log_density(latent);
coordinate = proposal.activeBasis.'*latent(proposal.activeIndex,:);
standardized = (coordinate-proposal.meanCoordinate) ./ ...
    proposal.scaleCoordinate;
logLocalActive = -0.5*sum(standardized.^2,1) - ...
    sum(log(proposal.scaleCoordinate)) - ...
    0.5*numel(proposal.activeIndex)*log(2*pi);
if isempty(proposal.priorOnlyIndex)
    logLocalPriorOnly = zeros(1,size(latent,2));
else
    zPriorOnly = latent(proposal.priorOnlyIndex,:);
    logLocalPriorOnly = -0.5*sum(zPriorOnly.^2,1) - ...
        0.5*numel(proposal.priorOnlyIndex)*log(2*pi);
end
logLocal = logLocalActive+logLocalPriorOnly;
value = local_logsumexp([log(proposal.priorWeight)+logPrior; ...
    log(proposal.localWeight)+logLocal],1);
end

function value = local_standard_normal_log_density(latent)
value = -0.5*sum(latent.^2,1)-0.5*size(latent,1)*log(2*pi);
end

function audit = local_self_test(proposal,count,seed)
if nargin < 2 || isempty(count), count = 3000; end
if nargin < 3 || isempty(seed), seed = 20260822; end
[theta,latent,component] = local_sample(proposal,count,seed);
logQ = local_log_density(proposal,latent);
logPrior = local_standard_normal_log_density(latent);
logWeight = logPrior-logQ;
[weight,logMeanWeight] = local_normalize_log_weight(logWeight);
inside = all(theta>proposal.prior.lower & theta<proposal.prior.upper,1);
audit = struct('sampleCount',count,'allInsideBounds',all(inside), ...
    'allFinite',all(isfinite(theta(:))) && all(isfinite(logQ)), ...
    'priorComponentCount',nnz(component==1), ...
    'localComponentCount',nnz(component==2), ...
    'initialImportanceEss',1/sum(weight.^2), ...
    'initialImportanceEssFraction',1/(sum(weight.^2)*count), ...
    'logMeanPriorToProposalWeight',logMeanWeight, ...
    'passed',all(inside) && all(isfinite(logQ)) && ...
    nnz(component==1)>0 && nnz(component==2)>0);
end

function [weight,logMeanWeight] = local_normalize_log_weight(logWeight)
maximum = max(logWeight);
raw = exp(logWeight-maximum);
weight = raw/sum(raw);
logMeanWeight = maximum+log(sum(raw))-log(numel(raw));
end

function value = local_logsumexp(input,dimension)
maximum = max(input,[],dimension);
value = maximum+log(sum(exp(input-maximum),dimension));
end

function value = local_option(options,name,defaultValue)
if isstruct(options) && isfield(options,name) && ~isempty(options.(name))
    value = options.(name);
else
    value = defaultValue;
end
end
