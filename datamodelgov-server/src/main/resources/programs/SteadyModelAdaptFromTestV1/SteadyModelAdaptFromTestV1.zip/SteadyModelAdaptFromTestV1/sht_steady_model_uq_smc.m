function result = sht_steady_model_uq_smc( ...
        contract, prior, likelihood, guidedProposal, userOptions)
%SHT_STEADY_MODEL_UQ_SMC 相关先验坐标下的精确自适应SMC。
%
% 目标分布按 beta 从先验连续过渡到后验：
%   pi_beta(theta) proportional p(theta)*L(theta)^beta。
% 中间阶段按ESS自适应选取beta并重采样。pCN移动在独立标准正态
% 先验坐标中进行，对先验严格可逆；防御性独立提议用于引入阶段D附近
% 和远端区域，但MH接受率包含完整先验、似然和提议密度，不改变后验。

if nargin < 5 || isempty(userOptions), userOptions = struct(); end
options = local_options(userOptions);
rng(options.randomSeed,'twister');
n = options.particleCount;
d = contract.parameterCount;
if isempty(options.latentBasis)
    options.latentBasis = eye(d);
end
if options.informedRank == 0
    options.informedRank = d;
end
if any(size(options.latentBasis) ~= d) || ...
        norm(options.latentBasis.'*options.latentBasis-eye(d),'fro') > 1e-8
    error('SHT:SteadyUQ:BadSmcLatentBasis', ...
        'SMC潜变量基必须为%d维正交矩阵。',d);
end
if options.informedRank < 0 || options.informedRank > d || ...
        options.informedRank ~= floor(options.informedRank)
    error('SHT:SteadyUQ:BadSmcInformedRank', ...
        'SMC受数据约束子空间维数必须为0至%d的整数。',d);
end

theta = sht_steady_model_uq_sampler( ...
    'sampleprior',prior,n,options.randomSeed+1);
latent = sht_steady_model_uq_sampler('thetatolatent',prior,theta);
exact = sht_steady_model_uq_common('evaluate',contract,theta, ...
    contract.trainingData,struct('useCache',options.useCache));
logLikelihood = sht_steady_model_uq_likelihood( ...
    'evaluate',likelihood,exact.residual,exact.valid);
logPrior = sht_steady_model_uq_sampler('logprior',prior,theta);
if nnz(isfinite(logLikelihood)) < max(20,ceil(0.20*n))
    error('SHT:SteadyUQ:SmcInitialValidity', ...
        'SMC先验粒子只有%d/%d个具有有效精确似然。', ...
        nnz(isfinite(logLikelihood)),n);
end

weights = ones(1,n)/n;
ancestor = 1:n;
beta = 0;
rho = options.initialPcnScale;
logEvidence = 0;
dllEvaluationCount = exact.dllEvaluationCount;
dllRuntime = exact.dllRuntime_s;
stage = repmat(local_empty_stage(),options.maximumStageCount,1);

for stageIndex = 1:options.maximumStageCount
    betaNext = local_next_beta(beta,logLikelihood,weights, ...
        options.targetEssFraction,options.minimumBetaIncrement);
    deltaBeta = betaNext-beta;
    [newWeights,logIncrement] = local_tempered_weights( ...
        weights,logLikelihood,deltaBeta);
    logEvidence = logEvidence+logIncrement;
    essBeforeResample = 1/sum(newWeights.^2);
    beta = betaNext;

    if beta < 1-options.betaTolerance
        index = local_systematic_index(newWeights,n);
        theta = theta(:,index);
        latent = latent(:,index);
        logLikelihood = logLikelihood(index);
        logPrior = logPrior(index);
        exact.residual = exact.residual(:,index);
        exact.valid = exact.valid(index);
        ancestor = ancestor(index);
        weights = ones(1,n)/n;
        resampled = true;
        sweepCount = options.moveSweeps;
    else
        beta = 1;
        weights = newWeights;
        resampled = false;
        sweepCount = options.finalMoveSweeps;
    end

    pcnAccepted = 0;
    pcnAttempted = 0;
    guidedAccepted = 0;
    guidedAttempted = 0;
    for sweep = 1:sweepCount
        proposalLatent = local_anisotropic_pcn(latent,rho,options);
        proposalTheta = sht_steady_model_uq_sampler( ...
            'latenttotheta',prior,proposalLatent);
        proposalExact = sht_steady_model_uq_common('evaluate', ...
            contract,proposalTheta,contract.trainingData, ...
            struct('useCache',options.useCache));
        proposalLogLikelihood = sht_steady_model_uq_likelihood( ...
            'evaluate',likelihood,proposalExact.residual,proposalExact.valid);
        logAlpha = beta*(proposalLogLikelihood-logLikelihood);
        accept = log(rand(1,n)) < min(0,logAlpha);
        [theta,latent,logLikelihood,exact] = local_accept_pcn( ...
            accept,theta,latent,logLikelihood,exact,proposalTheta, ...
            proposalLatent,proposalLogLikelihood,proposalExact);
        logPrior = sht_steady_model_uq_sampler('logprior',prior,theta);
        pcnAccepted = pcnAccepted+nnz(accept);
        pcnAttempted = pcnAttempted+n;
        dllEvaluationCount = dllEvaluationCount+proposalExact.dllEvaluationCount;
        dllRuntime = dllRuntime+proposalExact.dllRuntime_s;
        % 每次精确移动后立即适配受数据约束方向步长。特别是在最后一次
        % beta跃迁较大时，不能用整个末级固定步长反复产生低接受候选。
        sweepAcceptance = nnz(accept)/n;
        rho = min(options.maximumInformedPcnScale, ...
            max(options.minimumPcnScale,rho*exp( ...
            options.pcnAdaptGain*(sweepAcceptance-options.targetPcnAcceptance))));

        % 低温阶段用于全局播种；中高温阶段隔层调用，使局部精确高概率
        % 候选能在下一次升温重采样中扩散。末级只保留有限次数，避免
        % 在已经冻结的目标分布上反复调用低接受率宽提议。
        earlyGuided = beta <= options.guidedMaximumBeta;
        lateTemperedGuided = beta < 1-options.betaTolerance && ...
            beta >= options.guidedLateMinimumBeta && ...
            mod(stageIndex,options.guidedLateStageInterval)==0;
        finalGuided = beta >= 1-options.betaTolerance && ...
            sweep <= options.finalGuidedSweeps;
        if options.guidedSweepEnabled && ...
                (earlyGuided || lateTemperedGuided || finalGuided)
            proposalTheta = sht_steady_model_uq_sampler( ...
                'sampleproposal',guidedProposal,n, ...
                options.randomSeed+100000*stageIndex+100*sweep);
            proposalExact = sht_steady_model_uq_common('evaluate', ...
                contract,proposalTheta,contract.trainingData, ...
                struct('useCache',options.useCache));
            proposalLogLikelihood = sht_steady_model_uq_likelihood( ...
                'evaluate',likelihood,proposalExact.residual,proposalExact.valid);
            proposalLogPrior = sht_steady_model_uq_sampler( ...
                'logprior',prior,proposalTheta);
            proposalLogQ = sht_steady_model_uq_sampler( ...
                'logproposal',guidedProposal,proposalTheta);
            currentLogQ = sht_steady_model_uq_sampler( ...
                'logproposal',guidedProposal,theta);
            logAlpha = proposalLogPrior+beta*proposalLogLikelihood-proposalLogQ ...
                -(logPrior+beta*logLikelihood-currentLogQ);
            accept = log(rand(1,n)) < min(0,logAlpha);
            [theta,latent,logLikelihood,logPrior,exact] = ...
                local_accept_guided(accept,theta,latent,logLikelihood, ...
                logPrior,exact,proposalTheta,proposalLogLikelihood, ...
                proposalLogPrior,proposalExact,prior);
            guidedAccepted = guidedAccepted+nnz(accept);
            guidedAttempted = guidedAttempted+n;
            dllEvaluationCount = dllEvaluationCount+proposalExact.dllEvaluationCount;
            dllRuntime = dllRuntime+proposalExact.dllRuntime_s;
        end
    end

    pcnAcceptance = pcnAccepted/max(pcnAttempted,1);
    guidedAcceptance = guidedAccepted/max(guidedAttempted,1);
    stage(stageIndex) = struct('index',stageIndex,'beta',beta, ...
        'delta_beta',deltaBeta,'ess_before_resample',essBeforeResample, ...
        'resampled',resampled,'pcn_scale_after_adaptation',rho, ...
        'null_pcn_scale_after_adaptation',min(options.maximumPcnScale, ...
            options.nullScaleMultiplier*rho), ...
        'pcn_acceptance',pcnAcceptance, ...
        'guided_acceptance',guidedAcceptance, ...
        'valid_fraction',mean(isfinite(logLikelihood)), ...
        'unique_ancestor_count',numel(unique(ancestor)), ...
        'move_sweeps',sweepCount);
    if options.verbose
        fprintf(['  SMC stage=%2d beta=%.6f dBeta=%.3g ESS=%.1f ' ...
            'pCN=%.1f%% guided=%.1f%% rho=%.3f ancestors=%d\n'], ...
            stageIndex,beta,deltaBeta,essBeforeResample, ...
            100*pcnAcceptance,100*guidedAcceptance,rho,numel(unique(ancestor)));
    end
    if beta >= 1-options.betaTolerance
        beta = 1;
        break;
    end
end

if beta < 1-options.betaTolerance
    error('SHT:SteadyUQ:SmcMaximumStages', ...
        'SMC在%d个阶段后beta仅达到%.6f。',options.maximumStageCount,beta);
end
stage = stage(1:stageIndex);
weights = weights/sum(weights);
exact.theta = theta;
exact.valid = isfinite(logLikelihood);
exact.insideBounds = true(1,n);
exact.candidateCount = n;
diagnostic = sht_steady_model_uq_sampler( ...
    'diagnostics',theta,weights,log(max(weights,realmin)),prior);
result = struct('schemaVersion','steady_model_uq_exact_smc_v1', ...
    'theta',theta,'weights',weights,'logLikelihood',logLikelihood, ...
    'logPrior',logPrior,'exact',exact,'stage',stage, ...
    'stageCount',stageIndex,'finalBeta',beta,'finalPcnScale',rho, ...
    'diagnostic',diagnostic,'logEvidenceEstimate',logEvidence, ...
    'uniqueAncestorCount',numel(unique(ancestor)), ...
    'ancestorId',ancestor,'dllEvaluationCount',dllEvaluationCount, ...
    'dllRuntime_s',dllRuntime,'options',options);
end

function options = local_options(user)
options = struct();
options.particleCount = local_option(user,'particleCount',384);
options.randomSeed = local_option(user,'randomSeed',20260821);
options.targetEssFraction = local_option(user,'targetEssFraction',0.75);
options.minimumBetaIncrement = local_option(user,'minimumBetaIncrement',1e-4);
options.betaTolerance = local_option(user,'betaTolerance',1e-10);
options.maximumStageCount = local_option(user,'maximumStageCount',60);
options.moveSweeps = local_option(user,'moveSweeps',2);
options.finalMoveSweeps = local_option(user,'finalMoveSweeps',4);
options.initialPcnScale = local_option(user,'initialPcnScale',0.12);
options.minimumPcnScale = local_option(user,'minimumPcnScale',0.015);
options.maximumInformedPcnScale = local_option( ...
    user,'maximumInformedPcnScale',0.20);
options.maximumPcnScale = local_option(user,'maximumPcnScale',0.55);
options.targetPcnAcceptance = local_option(user,'targetPcnAcceptance',0.25);
options.pcnAdaptGain = local_option(user,'pcnAdaptGain',1.00);
options.guidedSweepEnabled = logical(local_option(user,'guidedSweepEnabled',true));
options.guidedMaximumBeta = local_option(user,'guidedMaximumBeta',0.85);
options.guidedLateMinimumBeta = local_option(user,'guidedLateMinimumBeta',0.05);
options.guidedLateStageInterval = local_option(user,'guidedLateStageInterval',2);
options.finalGuidedSweeps = local_option(user,'finalGuidedSweeps',2);
options.latentBasis = local_option(user,'latentBasis',[]);
options.informedRank = local_option(user,'informedRank',0);
options.nullScaleMultiplier = local_option(user,'nullScaleMultiplier',4.0);
options.useCache = logical(local_option(user,'useCache',true));
options.verbose = logical(local_option(user,'verbose',true));
if options.particleCount < 32 || options.particleCount ~= floor(options.particleCount)
    error('SHT:SteadyUQ:BadSmcParticleCount','SMC粒子数必须为不小于32的整数。');
end
if options.targetEssFraction <= 0 || options.targetEssFraction >= 1
    error('SHT:SteadyUQ:BadSmcEssTarget','SMC目标ESS比例必须位于(0,1)。');
end
if options.maximumInformedPcnScale < options.minimumPcnScale || ...
        options.maximumInformedPcnScale > options.maximumPcnScale
    error('SHT:SteadyUQ:BadSmcPcnScale', ...
        '受约束方向pCN上限必须位于总pCN范围内。');
end
if options.guidedLateStageInterval < 1 || ...
        options.guidedLateStageInterval ~= floor(options.guidedLateStageInterval) || ...
        options.finalGuidedSweeps < 0 || ...
        options.finalGuidedSweeps ~= floor(options.finalGuidedSweeps)
    error('SHT:SteadyUQ:BadSmcGuidedSchedule', ...
        '引导提议的隔层间距和末级次数必须为有效整数。');
end
end

function betaNext = local_next_beta(beta,logLikelihood,weights,targetFraction,minIncrement)
if beta >= 1
    betaNext = 1;
    return;
end
target = targetFraction*numel(weights);
essAtOne = local_incremental_ess(weights,logLikelihood,1-beta);
if essAtOne >= target
    betaNext = 1;
    return;
end
lower = beta;
upper = 1;
for i = 1:60
    middle = 0.5*(lower+upper);
    essValue = local_incremental_ess(weights,logLikelihood,middle-beta);
    if essValue < target
        upper = middle;
    else
        lower = middle;
    end
end
betaNext = max(lower,min(1,beta+minIncrement));
end

function essValue = local_incremental_ess(weights,logLikelihood,deltaBeta)
[newWeights,~] = local_tempered_weights(weights,logLikelihood,deltaBeta);
essValue = 1/sum(newWeights.^2);
end

function [weights,logIncrement] = local_tempered_weights(weights,logLikelihood,deltaBeta)
logValue = log(max(weights,realmin))+deltaBeta*logLikelihood;
maximum = max(logValue);
if ~isfinite(maximum)
    error('SHT:SteadyUQ:SmcAllWeightsInvalid', ...
        '当前升温步后全部粒子权重无效。');
end
scaled = exp(logValue-maximum);
normalizer = sum(scaled);
weights = scaled/normalizer;
logIncrement = maximum+log(normalizer);
end

function index = local_systematic_index(weights,count)
weights = weights(:)/sum(weights);
cumulative = cumsum(weights);
cumulative(end) = 1;
position = ((0:count-1).'+rand)/count;
index = zeros(count,1);
j = 1;
for i = 1:count
    while position(i) > cumulative(j), j = j+1; end
    index(i) = j;
end
index = index.';
end

function proposal = local_anisotropic_pcn(latent,informedScale,options)
% 在局部信息SVD基中，对受数据约束方向采用小步长，对先验主导方向
% 采用较大步长。各方向仍满足一维pCN关系，故整体保持N(0,I)先验。
d = size(latent,1);
scale = informedScale*ones(d,1);
if options.informedRank < d
    scale(options.informedRank+1:end) = min(options.maximumPcnScale, ...
        options.nullScaleMultiplier*informedScale);
end
scale = min(max(scale,options.minimumPcnScale),options.maximumPcnScale);
coordinate = options.latentBasis.'*latent;
proposalCoordinate = sqrt(1-scale.^2).*coordinate+ ...
    scale.*randn(size(coordinate));
proposal = options.latentBasis*proposalCoordinate;
end

function [theta,latent,logLikelihood,exact] = local_accept_pcn( ...
        accept,theta,latent,logLikelihood,exact,proposalTheta, ...
        proposalLatent,proposalLogLikelihood,proposalExact)
theta(:,accept) = proposalTheta(:,accept);
latent(:,accept) = proposalLatent(:,accept);
logLikelihood(accept) = proposalLogLikelihood(accept);
exact.residual(:,accept) = proposalExact.residual(:,accept);
exact.valid(accept) = proposalExact.valid(accept);
end

function [theta,latent,logLikelihood,logPrior,exact] = ...
        local_accept_guided(accept,theta,latent,logLikelihood,logPrior, ...
        exact,proposalTheta,proposalLogLikelihood,proposalLogPrior, ...
        proposalExact,prior)
theta(:,accept) = proposalTheta(:,accept);
logLikelihood(accept) = proposalLogLikelihood(accept);
logPrior(accept) = proposalLogPrior(accept);
exact.residual(:,accept) = proposalExact.residual(:,accept);
exact.valid(accept) = proposalExact.valid(accept);
if any(accept)
    latent(:,accept) = sht_steady_model_uq_sampler( ...
        'thetatolatent',prior,theta(:,accept));
end
end

function record = local_empty_stage()
record = struct('index',0,'beta',NaN,'delta_beta',NaN, ...
    'ess_before_resample',NaN,'resampled',false, ...
    'pcn_scale_after_adaptation',NaN, ...
    'null_pcn_scale_after_adaptation',NaN,'pcn_acceptance',NaN, ...
    'guided_acceptance',NaN,'valid_fraction',NaN, ...
    'unique_ancestor_count',0,'move_sweeps',0);
end

function value = local_option(options,name,defaultValue)
if isstruct(options) && isfield(options,name) && ~isempty(options.(name))
    value = options.(name);
else
    value = defaultValue;
end
end
