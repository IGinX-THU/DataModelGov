function result = Start_SteadyModelUQ_00_RunAll(userCfg)
%START_STEADYMODELUQ_00_RUNALL 顺序执行2.4稳态参数UQ全部十个步骤。
%
% 默认路线为transient_instant：每个稳态工况只执行一个瞬态时刻代数
% 模型，不积分瞬态时间历程。常用可调字段包括：
%   pilotSampleCount               每组精确SMC先导粒子数，默认64；
%   pilotReplicateCount            独立先导随机种子数，默认3；
%   formalSampleCount              正式精确SMC粒子数，默认256；
%   posteriorPredictiveSampleCount 后验预测样本数，默认256；
%   figureVisible                  'off'或'on'，默认'off'。
%
% 精确DLL缓存按问题合同哈希复用；新数据、参数范围、模型文件或误差合同
% 改变后哈希随之改变，不会误用旧缓存。

if nargin < 1, userCfg = struct(); end
timer = tic;
fprintf('\n=== 2.4稳态修正参数贝叶斯不确定性量化：完整执行 ===\n');
step = cell(10,1);
step{1} = Start_SteadyModelUQ_01_ProblemContract(userCfg);
runCfg = userCfg;
runCfg.runId = step{1}.manifest.runId;
step{2} = Start_SteadyModelUQ_02_ExactStaticReplayAndCache(runCfg);
step{3} = Start_SteadyModelUQ_03_ObservationVector(runCfg);
step{4} = Start_SteadyModelUQ_04_AnalyticMeasurementUncertainty(runCfg);
step{5} = Start_SteadyModelUQ_05_ExactLikelihoodVerification(runCfg);
step{6} = Start_SteadyModelUQ_06_GlobalExactPilot(runCfg);
step{7} = Start_SteadyModelUQ_07_DefensiveProposalAdaptation(runCfg);
step{8} = Start_SteadyModelUQ_08_UnifiedExactPosteriorSampling(runCfg);
step{9} = Start_SteadyModelUQ_09_PosteriorDiagnostics(runCfg);
step{10} = Start_SteadyModelUQ_10_PosteriorPredictiveValidation(runCfg);

manifest = step{10}.manifest;
result = struct('runId',manifest.runId,'manifest',manifest, ...
    'steps',{step},'posterior',step{8}.formal, ...
    'posteriorDiagnostic',step{9},'validation',step{10}, ...
    'assessmentReportFile',step{10}.assessmentReportFile, ...
    'runtime_s',toc(timer),'passed',step{10}.passed);
fprintf('=== 2.4 UQ完整执行结束：run=%s，总耗时%.2f s，状态=%s ===\n\n', ...
    result.runId,result.runtime_s,manifest.status);
fprintf('最终评估结果文件：%s\n',result.assessmentReportFile);
fprintf('全部图表与CSV目录：%s\n\n',manifest.reportDir);
end
