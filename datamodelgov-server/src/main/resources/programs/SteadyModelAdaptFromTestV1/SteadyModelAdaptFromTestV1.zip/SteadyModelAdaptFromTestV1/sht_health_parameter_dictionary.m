function dictionary = sht_health_parameter_dictionary(modelMode)
%SHT_HEALTH_PARAMETER_DICTIONARY 返回DLL修正系数的模式相关显式字典。
%
% dictionary = sht_health_parameter_dictionary(0) 返回三部件模式字典；
% dictionary = sht_health_parameter_dictionary(1) 返回六部件模式字典。
%
% C端使用0基h编号，统一占用stepIn[40:198]；MATLAB使用1基下标，
% 因而对应stepIn(41:199)。同一位置在两种模式下允许具有不同含义，
% 但任何未定义位置都明确标记为reserved，不能依靠隐式猜测使用。

arguments
    modelMode (1,1) double {mustBeMember(modelMode, [0, 1])}
end

count = 159;
cIndex = (0:count-1).';
matlabHealthIndex = cIndex + 1;
matlabStepInIndex = cIndex + 41;
name = repmat("reserved", count, 1);
scope = repmat("reserved", count, 1);
law = repmat("unused", count, 1);
active = false(count, 1);

% 两种模式共享的总体部件、燃烧室、管道和喷口修正。
commonName = [ ...
    "Inlet_K_dP"; "HPC_K_W"; "HPC_K_eta"; "HPC_K_PR"; ...
    "Burner_K_Wf"; "Burner_K_eta"; "Burner_K_dP"; ...
    "GT_K_W"; "GT_K_eta"; "GT_K_PR"; "GT_PT_Duct_K_dP"; ...
    "PT_K_W"; "PT_K_eta"; "PT_K_PR"; ...
    "PT_Nozzle_Duct_K_dP"; "Nozzle_K_A8"];
name(1:16) = commonName;
scope(1:16) = "aggregate/common";
law(1:16) = "original component law";
active(1:16) = true;

if modelMode == 0
    branch = compose("legacy_bleed_%02d", (1:14).');
    name(17:30) = branch + "_K_PRec";
    name(31:44) = branch + "_K_Wfrac";
    name(45:58) = branch + "_K_hExtract";
    scope(17:58) = "legacy 14-branch bleed";
    law(17:30) = "additive pressure-recovery correction";
    law(31:44) = "additive inlet-flow-fraction correction";
    law(45:58) = "additive enthalpy-extraction-position correction";
    active(17:58) = true;

    transientName = ["K_Jg"; "K_Jp"; "K_tau_HPC"; ...
        "K_tau_Burner"; "K_tau_GT"; "K_tau_PT"; ...
        "K_kW_HPC"; "K_keta_HPC"; "K_keta_GT"; ...
        "K_keta_PT"; "K_tau_d_HPC"; "K_tau_d_GT"; ...
        "K_tau_d_PT"];
    name(59:71) = transientName;
    scope(59:71) = "three-component transient";
    law(59:71) = "transient model correction";
    active(59:71) = true;
else
    physicalBranch = compose("physical_bleed_%02d", (1:10).');
    name(17:26) = physicalBranch + "_K_PRec";
    name(31:40) = physicalBranch + "_K_Wfrac";
    name(45:54) = physicalBranch + "_K_Tt";
    scope([17:26, 31:40, 45:54]) = "split 10-branch bleed";
    law(17:26) = "additive pressure-recovery correction";
    law(31:40) = "additive overall-HPC-inlet-flow fraction";
    law(45:54) = "multiplicative total-temperature correction (1+K)";
    active([17:26, 31:40, 45:54]) = true;

    componentName = ["AC"; "CC"; "GT1"; "GT2"; "PT1"; "PT2"];
    cursor = 72;
    for k = 1:numel(componentName)
        rows = cursor:(cursor + 2);
        name(rows) = componentName(k) + ["_K_W"; "_K_eta"; "_K_PR"];
        scope(rows) = "split local component";
        law(rows) = "(1+K_aggregate)*(1+K_local)-1";
        active(rows) = true;
        cursor = cursor + 3;
    end
    % h58:h70和h89:h158为六部件后续瞬态模型预留；当前不得启用。
    scope(59:71) = "split transient reserved";
    scope(90:159) = "split transient reserved";
end

dictionary = table(cIndex, matlabHealthIndex, matlabStepInIndex, ...
    repmat(modelMode, count, 1), name, scope, law, active, ...
    'VariableNames', {'c_index', 'matlab_health_index', ...
    'matlab_step_in_index', 'model_mode', 'name', 'scope', ...
    'correction_law', 'active'});
end
