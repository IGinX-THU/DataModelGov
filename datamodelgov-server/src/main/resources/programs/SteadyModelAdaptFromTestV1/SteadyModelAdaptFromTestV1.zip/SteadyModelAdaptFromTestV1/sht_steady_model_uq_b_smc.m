function result = sht_steady_model_uq_b_smc( ...
        contract, prior, likelihood, guidedProposal, userOptions)
%SHT_STEADY_MODEL_UQ_B_SMC 方法B的93维分块精确自适应SMC。
%
% 三个物理参数块分别为总体参数、局部六部件参数和十路引气参数。每轮
% 先随机扫描一个物理块，再对全部活动参数执行一次跨块各向异性pCN：
% 局部受数据约束方向采用小步长，局部弱信息方向采用大步长。两类移动
% 均在独立标准正态先验潜变量中执行。初始化允许从防御混合分布采样，
% 但用p(z)/q(z)严格恢复原先验；分块pCN接受率只含精确DLL似然比，
% 防御独立移动则使用完整的先验、似然和提议密度比。

if nargin < 5 || isempty(userOptions), userOptions = struct(); end
options = local_options(contract,userOptions);
rng(options.randomSeed,'twister');
n = options.particleCount;
usesLatentDefensiveProposal = local_is_latent_defensive_proposal( ...
    guidedProposal);
if usesLatentDefensiveProposal
    [theta,latent,initialProposalComponent] = ...
        sht_steady_model_uq_b_proposal('sample',guidedProposal,n, ...
        options.randomSeed+1);
    initialLogProposal = sht_steady_model_uq_b_proposal( ...
        'logdensity',guidedProposal,latent);
    initialLogPriorLatent = sht_steady_model_uq_b_proposal( ...
        'logpriorlatent',latent);
    [weights,initialLogNormalization] = local_normalize_log_weights( ...
        initialLogPriorLatent-initialLogProposal);
else
    theta = sht_steady_model_uq_sampler( ...
        'sampleprior',prior,n,options.randomSeed+1);
    latent = sht_steady_model_uq_sampler('thetatolatent',prior,theta);
    weights = ones(1,n)/n;
    initialLogNormalization = 0;
    initialProposalComponent = ones(1,n);
end
initialImportanceEss = 1/sum(weights.^2);
exact = sht_steady_model_uq_b_common('evaluate',contract,theta, ...
    contract.trainingData,struct('useCache',options.useCache));
logLikelihood = sht_steady_model_uq_likelihood( ...
    'evaluate',likelihood,exact.residual,exact.valid);
logPrior = sht_steady_model_uq_sampler('logprior',prior,theta);
minimumValid = max(12,ceil(0.20*n));
if nnz(isfinite(logLikelihood)) < minimumValid
    error('SHT:SteadyUQB:SmcInitialValidity', ...
        'SMC先验粒子只有%d/%d个具有有效精确似然，最低要求%d个。', ...
        nnz(isfinite(logLikelihood)),n,minimumValid);
end

ancestor = 1:n;
beta = 0;
rho = options.initialBlockScale;
logEvidence = initialLogNormalization;
dllEvaluationCount = exact.dllEvaluationCount;
dllRuntime = exact.dllRuntime_s;
stage = repmat(local_empty_stage(),options.maximumStageCount,1);
totalAttempted = zeros(1,4);
totalAccepted = zeros(1,4);
guidedAttemptedTotal = 0;
guidedAcceptedTotal = 0;
priorOnlyRefreshCount = 0;

for stageIndex = 1:options.maximumStageCount
    betaNext = local_next_beta(beta,logLikelihood,weights, ...
        options.targetEssFraction,options.minimumBetaIncrement);
    deltaBeta = betaNext-beta;
    [newWeights,logIncrement] = local_tempered_weights( ...
        weights,logLikelihood,deltaBeta);
    logEvidence = logEvidence+logIncrement;
    essBeforeResample = 1/sum(newWeights.^2);
    beta = betaNext;
    if beta < 1-options.betaTolerance
        index = local_systematic_index(newWeights,n);
        theta = theta(:,index);
        latent = latent(:,index);
        logLikelihood = logLikelihood(index);
        exact.residual = exact.residual(:,index);
        exact.valid = exact.valid(index);
        ancestor = ancestor(index);
        [theta,latent] = local_refresh_prior_only( ...
            theta,latent,prior,options.priorOnlyIndex);
        priorOnlyRefreshCount = priorOnlyRefreshCount + ...
            ~isempty(options.priorOnlyIndex);
        logPrior = sht_steady_model_uq_sampler('logprior',prior,theta);
        weights = ones(1,n)/n;
        resampled = true;
        sweepCount = options.moveSweeps;
    else
        beta = 1;
        weights = newWeights;
        resampled = false;
        sweepCount = options.finalMoveSweeps;
    end

    attempted = zeros(1,4);
    accepted = zeros(1,4);
    guidedAttempted = 0;
    guidedAccepted = 0;
    for sweep = 1:sweepCount
        % 末级前三次强制覆盖三个物理块；其他阶段按冻结概率随机扫描。
        if beta >= 1-options.betaTolerance && sweep <= 3
            physicalKernel = sweep;
        else
            physicalKernel = local_categorical(options.physicalKernelWeights);
        end
        [theta,latent,logLikelihood,exact,acceptedCount,dllCount, ...
            moveRuntime] = local_exact_pcn_move(contract,prior,likelihood, ...
            beta,theta,latent,logLikelihood,exact,options, ...
            physicalKernel,rho(physicalKernel));
        attempted(physicalKernel) = attempted(physicalKernel)+n;
        accepted(physicalKernel) = accepted(physicalKernel)+acceptedCount;
        totalAttempted(physicalKernel) = totalAttempted(physicalKernel)+n;
        totalAccepted(physicalKernel) = totalAccepted(physicalKernel)+acceptedCount;
        dllEvaluationCount = dllEvaluationCount+dllCount;
        dllRuntime = dllRuntime+moveRuntime;
        rho(physicalKernel) = local_adapt_scale(rho(physicalKernel), ...
            acceptedCount/n,physicalKernel,options);

        % 跨块核每轮必做。其局部弱信息方向采用更大pCN步长，专门恢复
        % 重采样损失的宽度；不能再依赖低概率随机抽中联合核。
        crossKernel = 4;
        [theta,latent,logLikelihood,exact,acceptedCount,dllCount, ...
            moveRuntime] = local_exact_pcn_move(contract,prior,likelihood, ...
            beta,theta,latent,logLikelihood,exact,options, ...
            crossKernel,rho(crossKernel));
        attempted(crossKernel) = attempted(crossKernel)+n;
        accepted(crossKernel) = accepted(crossKernel)+acceptedCount;
        totalAttempted(crossKernel) = totalAttempted(crossKernel)+n;
        totalAccepted(crossKernel) = totalAccepted(crossKernel)+acceptedCount;
        dllEvaluationCount = dllEvaluationCount+dllCount;
        dllRuntime = dllRuntime+moveRuntime;
        rho(crossKernel) = local_adapt_scale(rho(crossKernel), ...
            acceptedCount/n,crossKernel,options);
        logPrior = sht_steady_model_uq_sampler('logprior',prior,theta);

        earlyGuided = beta <= options.guidedMaximumBeta;
        temperedGuided = beta < 1-options.betaTolerance && ...
            beta >= options.guidedLateMinimumBeta && ...
            mod(stageIndex,options.guidedLateStageInterval)==0;
        finalGuided = beta >= 1-options.betaTolerance && ...
            sweep <= options.finalGuidedSweeps;
        if options.guidedSweepEnabled && ...
                (earlyGuided || temperedGuided || finalGuided)
            if usesLatentDefensiveProposal
                [proposalTheta,proposalLatent] = ...
                    sht_steady_model_uq_b_proposal( ...
                    'sample',guidedProposal,n);
            else
                proposalTheta = sht_steady_model_uq_sampler( ...
                    'sampleproposal',guidedProposal,n, ...
                    options.randomSeed+100000*stageIndex+100*sweep);
                proposalLatent = sht_steady_model_uq_sampler( ...
                    'thetatolatent',prior,proposalTheta);
            end
            proposalExact = sht_steady_model_uq_b_common('evaluate', ...
                contract,proposalTheta,contract.trainingData, ...
                struct('useCache',options.useCache));
            proposalLogLikelihood = sht_steady_model_uq_likelihood( ...
                'evaluate',likelihood,proposalExact.residual,proposalExact.valid);
            proposalLogPrior = sht_steady_model_uq_sampler( ...
                'logprior',prior,proposalTheta);
            if usesLatentDefensiveProposal
                proposalLogPriorTarget = sht_steady_model_uq_b_proposal( ...
                    'logpriorlatent',proposalLatent);
                currentLogPriorTarget = sht_steady_model_uq_b_proposal( ...
                    'logpriorlatent',latent);
                proposalLogQ = sht_steady_model_uq_b_proposal( ...
                    'logdensity',guidedProposal,proposalLatent);
                currentLogQ = sht_steady_model_uq_b_proposal( ...
                    'logdensity',guidedProposal,latent);
            else
                proposalLogPriorTarget = proposalLogPrior;
                currentLogPriorTarget = logPrior;
                proposalLogQ = sht_steady_model_uq_sampler( ...
                    'logproposal',guidedProposal,proposalTheta);
                currentLogQ = sht_steady_model_uq_sampler( ...
                    'logproposal',guidedProposal,theta);
            end
            logAlpha = proposalLogPriorTarget+ ...
                beta*proposalLogLikelihood-proposalLogQ - ...
                (currentLogPriorTarget+beta*logLikelihood-currentLogQ);
            accept = log(rand(1,n)) < min(0,logAlpha);
            [theta,latent,logLikelihood,logPrior,exact] = ...
                local_accept_guided(accept,theta,latent,logLikelihood, ...
                logPrior,exact,proposalTheta,proposalLogLikelihood, ...
                proposalLogPrior,proposalExact,proposalLatent);
            guidedAttempted = guidedAttempted+n;
            guidedAccepted = guidedAccepted+nnz(accept);
            guidedAttemptedTotal = guidedAttemptedTotal+n;
            guidedAcceptedTotal = guidedAcceptedTotal+nnz(accept);
            dllEvaluationCount = dllEvaluationCount+proposalExact.dllEvaluationCount;
            dllRuntime = dllRuntime+proposalExact.dllRuntime_s;
        end
    end

    kernelAcceptance = accepted./max(attempted,1);
    stage(stageIndex) = struct('index',stageIndex,'beta',beta, ...
        'delta_beta',deltaBeta,'ess_before_resample',essBeforeResample, ...
        'resampled',resampled,'block_scale_after_adaptation',rho, ...
        'block_attempted',attempted,'block_accepted',accepted, ...
        'block_acceptance',kernelAcceptance, ...
        'cross_null_scale_after_adaptation', ...
        local_cross_null_scale(rho(4),options), ...
        'guided_acceptance',guidedAccepted/max(guidedAttempted,1), ...
        'valid_fraction',mean(isfinite(logLikelihood)), ...
        'unique_ancestor_count',numel(unique(ancestor)), ...
        'move_sweeps',sweepCount);
    if options.verbose
        fprintf(['  B-SMC stage=%2d beta=%.6f dBeta=%.3g ESS=%.1f ' ...
            'acc=[%.1f %.1f %.1f %.1f]%% rho=[%.3f %.3f %.3f %.3f] ' ...
            'rhoNull=%.3f ancestors=%d\n'],stageIndex,beta,deltaBeta, ...
            essBeforeResample,100*kernelAcceptance,rho, ...
            local_cross_null_scale(rho(4),options),numel(unique(ancestor)));
    end
    if beta >= 1-options.betaTolerance
        beta = 1;
        break;
    end
end
if beta < 1-options.betaTolerance
    error('SHT:SteadyUQB:SmcMaximumStages', ...
        '方法B SMC在%d层后beta仅达到%.6f。', ...
        options.maximumStageCount,beta);
end
stage = stage(1:stageIndex);
weights = weights/sum(weights);
% 似然严格无关的方向在末级再作一次精确先验刷新，消除有限粒子
% 重采样造成的假收缩；该Gibbs步不改变似然和权重。
[theta,~] = local_refresh_prior_only( ...
    theta,latent,prior,options.priorOnlyIndex);
priorOnlyRefreshCount = priorOnlyRefreshCount + ...
    ~isempty(options.priorOnlyIndex);
logPrior = sht_steady_model_uq_sampler('logprior',prior,theta);
exact.theta = theta;
exact.valid = isfinite(logLikelihood);
exact.insideBounds = true(1,n);
exact.candidateCount = n;
diagnostic = sht_steady_model_uq_sampler( ...
    'diagnostics',theta,weights,log(max(weights,realmin)),prior);
result = struct('schemaVersion','steady_model_uq_method_b_block_smc_v2', ...
    'theta',theta,'weights',weights,'logLikelihood',logLikelihood, ...
    'logPrior',logPrior,'exact',exact,'stage',stage, ...
    'stageCount',stageIndex,'finalBeta',beta,'finalBlockScale',rho, ...
    'blockAttempted',totalAttempted,'blockAccepted',totalAccepted, ...
    'blockAcceptance',totalAccepted./max(totalAttempted,1), ...
    'blockNames',{{'aggregate','local','bleed','cross'}}, ...
    'guidedAttempted',guidedAttemptedTotal, ...
    'guidedAccepted',guidedAcceptedTotal, ...
    'guidedAcceptance',guidedAcceptedTotal/max(guidedAttemptedTotal,1), ...
    'usesLatentDefensiveProposal',usesLatentDefensiveProposal, ...
    'initialImportanceEss',initialImportanceEss, ...
    'initialProposalComponent',initialProposalComponent, ...
    'initialLogPriorNormalizationEstimate',initialLogNormalization, ...
    'diagnostic',diagnostic,'logEvidenceEstimate',logEvidence, ...
    'uniqueAncestorCount',numel(unique(ancestor)), ...
    'ancestorId',ancestor,'dllEvaluationCount',dllEvaluationCount, ...
    'dllRuntime_s',dllRuntime,'priorOnlyParameterIndex', ...
    options.priorOnlyIndex,'priorOnlyRefreshCount',priorOnlyRefreshCount, ...
    'finalCrossNullScale',local_cross_null_scale(rho(4),options), ...
    'options',options);
end

function options = local_options(contract,user)
options = struct();
options.particleCount = local_option(user,'particleCount', ...
    contract.config.formalSampleCount);
options.randomSeed = local_option(user,'randomSeed',20260822);
options.targetEssFraction = local_option(user,'targetEssFraction',0.50);
options.minimumBetaIncrement = local_option(user,'minimumBetaIncrement',1e-4);
options.betaTolerance = local_option(user,'betaTolerance',1e-10);
options.maximumStageCount = local_option(user,'maximumStageCount',70);
options.moveSweeps = local_option(user,'moveSweeps',1);
options.finalMoveSweeps = local_option(user,'finalMoveSweeps',4);
options.initialBlockScale = local_option(user,'initialBlockScale', ...
    contract.config.blockInitialPcnScale);
options.minimumBlockScale = local_option(user,'minimumBlockScale', ...
    [0.010,0.015,0.015,0.005]);
options.maximumBlockScale = local_option(user,'maximumBlockScale', ...
    [0.22,0.50,0.50,0.18]);
options.targetBlockAcceptance = local_option(user,'targetBlockAcceptance', ...
    [0.20,0.28,0.28,0.18]);
options.pcnAdaptGain = local_option(user,'pcnAdaptGain',1.0);
options.kernelWeights = local_option(user,'kernelWeights', ...
    contract.config.blockKernelWeights);
options.blockIndex = local_option(user,'blockIndex', ...
    contract.parameterBlockIndex);
options.priorOnlyIndex = local_option(user,'priorOnlyIndex',zeros(0,1));
options.priorOnlyIndex = unique(options.priorOnlyIndex(:),'stable');
if any(options.priorOnlyIndex < 1) || ...
        any(options.priorOnlyIndex > contract.parameterCount)
    error('SHT:SteadyUQB:BadPriorOnlyIndex', ...
        '精确先验保留参数下标超出方法B合同。');
end
if ~isempty(options.priorOnlyIndex)
    other = setdiff((1:contract.parameterCount).', ...
        options.priorOnlyIndex,'stable');
    crossCorrelation = contract.priorCorrelation( ...
        options.priorOnlyIndex,other);
    if any(abs(crossCorrelation(:)) > 1e-14)
        error('SHT:SteadyUQB:CorrelatedPriorOnlyParameter', ...
            ['精确先验保留方向与其余参数存在先验相关，不能使用' ...
            '独立刷新。']);
    end
    for k = 1:numel(options.blockIndex)
        options.blockIndex{k} = setdiff(options.blockIndex{k}(:), ...
            options.priorOnlyIndex,'stable');
    end
end
options.guidedSweepEnabled = logical(local_option( ...
    user,'guidedSweepEnabled',true));
options.guidedMaximumBeta = local_option(user,'guidedMaximumBeta',0.01);
options.guidedLateMinimumBeta = local_option(user,'guidedLateMinimumBeta',0.05);
options.guidedLateStageInterval = local_option(user,'guidedLateStageInterval',3);
options.finalGuidedSweeps = local_option(user,'finalGuidedSweeps',1);
options.useCache = logical(local_option(user,'useCache',true));
options.verbose = logical(local_option(user,'verbose',true));
if options.particleCount < 24 || ...
        options.particleCount ~= floor(options.particleCount)
    error('SHT:SteadyUQB:BadSmcParticleCount', ...
        '方法B SMC粒子数必须为不小于24的整数。');
end

if options.targetEssFraction <= 0 || options.targetEssFraction >= 1
    error('SHT:SteadyUQB:BadSmcEssTarget', ...
        '方法B SMC目标ESS比例必须位于(0,1)。');
end
fields = {'initialBlockScale','minimumBlockScale', ...
    'maximumBlockScale','targetBlockAcceptance','kernelWeights'};
for i = 1:numel(fields)
    options.(fields{i}) = options.(fields{i})(:).';
    if numel(options.(fields{i})) ~= 4 || ...
            any(~isfinite(options.(fields{i})))
        error('SHT:SteadyUQB:BadBlockOption', ...
            '%s必须包含四个有限值。',fields{i});
    end
end
if any(options.minimumBlockScale <= 0) || ...
        any(options.maximumBlockScale >= 1) || ...
        any(options.minimumBlockScale > options.initialBlockScale) || ...
        any(options.initialBlockScale > options.maximumBlockScale)
    error('SHT:SteadyUQB:BadBlockScale', ...
        '方法B分块pCN最小、初始和最大步长顺序错误。');
end
options.kernelWeights = options.kernelWeights/sum(options.kernelWeights);
if numel(options.blockIndex) ~= 4 || ...
        any(cellfun(@isempty,options.blockIndex))
    error('SHT:SteadyUQB:BadBlockIndex', ...
        '方法B必须配置四个非空参数块。');
end
activeIndex = setdiff((1:contract.parameterCount).', ...
    options.priorOnlyIndex,'stable');
if ~isequal(sort(options.blockIndex{4}(:)),activeIndex)
    error('SHT:SteadyUQB:BadCrossBlock', ...
        '跨块联合核必须覆盖全部%d个非解析边缘化参数。', ...
        numel(activeIndex));
end
options.physicalKernelWeights = options.kernelWeights(1:3) / ...
    sum(options.kernelWeights(1:3));
options.crossLatentBasis = local_option(user,'crossLatentBasis', ...
    eye(numel(activeIndex)));
options.crossInformedRank = local_option(user,'crossInformedRank', ...
    numel(activeIndex));
options.crossNullScaleMultiplier = local_option( ...
    user,'crossNullScaleMultiplier',4.0);
options.maximumCrossNullScale = local_option( ...
    user,'maximumCrossNullScale',0.55);
if ~isequal(size(options.crossLatentBasis), ...
        [numel(activeIndex),numel(activeIndex)]) || ...
        norm(options.crossLatentBasis.'*options.crossLatentBasis- ...
        eye(numel(activeIndex)),'fro') > 1e-8
    error('SHT:SteadyUQB:BadCrossLatentBasis', ...
        '跨块活动潜空间基必须为%d维正交矩阵。',numel(activeIndex));
end
if options.crossInformedRank < 0 || ...
        options.crossInformedRank > numel(activeIndex) || ...
        options.crossInformedRank ~= floor(options.crossInformedRank)
    error('SHT:SteadyUQB:BadCrossInformedRank', ...
        '跨块受数据约束方向数必须为0至%d的整数。',numel(activeIndex));
end
if options.crossNullScaleMultiplier < 1 || ...
        options.maximumCrossNullScale <= 0 || ...
        options.maximumCrossNullScale >= 1
    error('SHT:SteadyUQB:BadCrossNullScale', ...
        '跨块弱信息方向步长倍率必须不小于1，步长上限必须位于(0,1)。');
end
options.activeIndex = activeIndex;
end

function [theta,latent] = local_refresh_prior_only( ...
        theta,latent,prior,index)
if isempty(index), return; end
latent(index,:) = randn(numel(index),size(latent,2));
theta = sht_steady_model_uq_sampler('latenttotheta',prior,latent);
end

function proposal = local_block_pcn(latent,index,rho)
proposal = latent;
proposal(index,:) = sqrt(1-rho^2).*latent(index,:) + ...
    rho.*randn(numel(index),size(latent,2));
end

function proposal = local_cross_anisotropic_pcn(latent,options,rho)
% 在活动潜空间SVD基中分别移动受约束方向和弱信息方向。逐方向pCN均
% 保持标准正态先验，因此无需在Metropolis比中附加提议密度修正。
index = options.activeIndex;
coordinate = options.crossLatentBasis.'*latent(index,:);
scale = rho*ones(numel(index),1);
if options.crossInformedRank < numel(index)
    scale(options.crossInformedRank+1:end) = ...
        local_cross_null_scale(rho,options);
end
scale = min(max(scale,options.minimumBlockScale(4)), ...
    options.maximumCrossNullScale);
proposalCoordinate = sqrt(1-scale.^2).*coordinate + ...
    scale.*randn(size(coordinate));
proposal = latent;
proposal(index,:) = options.crossLatentBasis*proposalCoordinate;
end

function value = local_cross_null_scale(rho,options)
value = min(options.maximumCrossNullScale, ...
    options.crossNullScaleMultiplier*rho);
value = max(value,options.minimumBlockScale(4));
end

function value = local_adapt_scale(value,acceptance,kernel,options)
value = min(options.maximumBlockScale(kernel), ...
    max(options.minimumBlockScale(kernel),value*exp( ...
    options.pcnAdaptGain*(acceptance- ...
    options.targetBlockAcceptance(kernel)))));
end

function [theta,latent,logLikelihood,exact,acceptedCount, ...
        dllCount,dllRuntime] = local_exact_pcn_move( ...
        contract,prior,likelihood,beta,theta,latent,logLikelihood, ...
        exact,options,kernel,rho)
if kernel == 4
    proposalLatent = local_cross_anisotropic_pcn(latent,options,rho);
else
    proposalLatent = local_block_pcn( ...
        latent,options.blockIndex{kernel},rho);
end
proposalTheta = sht_steady_model_uq_sampler( ...
    'latenttotheta',prior,proposalLatent);
proposalExact = sht_steady_model_uq_b_common('evaluate', ...
    contract,proposalTheta,contract.trainingData, ...
    struct('useCache',options.useCache));
proposalLogLikelihood = sht_steady_model_uq_likelihood( ...
    'evaluate',likelihood,proposalExact.residual,proposalExact.valid);
logAlpha = beta*(proposalLogLikelihood-logLikelihood);
accept = log(rand(1,size(theta,2))) < min(0,logAlpha);
[theta,latent,logLikelihood,exact] = local_accept_pcn( ...
    accept,theta,latent,logLikelihood,exact,proposalTheta, ...
    proposalLatent,proposalLogLikelihood,proposalExact);
acceptedCount = nnz(accept);
dllCount = proposalExact.dllEvaluationCount;
dllRuntime = proposalExact.dllRuntime_s;
end

function kernel = local_categorical(weight)
u = rand;
kernel = find(u <= cumsum(weight),1);
if isempty(kernel), kernel = numel(weight); end
end

function betaNext = local_next_beta( ...
        beta,logLikelihood,weights,targetFraction,minIncrement)
if beta >= 1, betaNext = 1; return; end
target = targetFraction*numel(weights);
% 防御混合初始化后的p/q权重可能尚未达到常规N比例门限。首个升温步
% 此时以当前ESS的95%为上限，避免把“已有加权样本数”误当成N，同时
% 后续重采样为等权粒子后自动恢复常规targetFraction*N规则。
target = min(target,0.95/sum(weights.^2));
if local_incremental_ess(weights,logLikelihood,1-beta) >= target
    betaNext = 1;
    return;
end
lower = beta; upper = 1;
for i = 1:60
    middle = 0.5*(lower+upper);
    if local_incremental_ess(weights,logLikelihood,middle-beta) < target
        upper = middle;
    else
        lower = middle;
    end
end
betaNext = max(lower,min(1,beta+minIncrement));
end

function value = local_incremental_ess(weights,logLikelihood,deltaBeta)
[newWeights,~] = local_tempered_weights(weights,logLikelihood,deltaBeta);
value = 1/sum(newWeights.^2);
end

function [weights,logIncrement] = local_tempered_weights( ...
        weights,logLikelihood,deltaBeta)
logValue = log(max(weights,realmin))+deltaBeta*logLikelihood;
maximum = max(logValue);
if ~isfinite(maximum)
    error('SHT:SteadyUQB:SmcAllWeightsInvalid', ...
        '方法B当前升温步后全部粒子权重无效。');
end
scaled = exp(logValue-maximum);
normalizer = sum(scaled);
weights = scaled/normalizer;
logIncrement = maximum+log(normalizer);
end

function index = local_systematic_index(weights,count)
weights = weights(:)/sum(weights);
cumulative = cumsum(weights); cumulative(end) = 1;
position = ((0:count-1).'+rand)/count;
index = zeros(count,1); j = 1;
for i = 1:count
    while position(i) > cumulative(j), j = j+1; end
    index(i) = j;
end
index = index.';
end

function [theta,latent,logLikelihood,exact] = local_accept_pcn( ...
        accept,theta,latent,logLikelihood,exact,proposalTheta, ...
        proposalLatent,proposalLogLikelihood,proposalExact)
theta(:,accept) = proposalTheta(:,accept);
latent(:,accept) = proposalLatent(:,accept);
logLikelihood(accept) = proposalLogLikelihood(accept);
exact.residual(:,accept) = proposalExact.residual(:,accept);
exact.valid(accept) = proposalExact.valid(accept);
end

function [theta,latent,logLikelihood,logPrior,exact] = ...
        local_accept_guided(accept,theta,latent,logLikelihood,logPrior, ...
        exact,proposalTheta,proposalLogLikelihood,proposalLogPrior, ...
        proposalExact,proposalLatent)
theta(:,accept) = proposalTheta(:,accept);
logLikelihood(accept) = proposalLogLikelihood(accept);
logPrior(accept) = proposalLogPrior(accept);
exact.residual(:,accept) = proposalExact.residual(:,accept);
exact.valid(accept) = proposalExact.valid(accept);
latent(:,accept) = proposalLatent(:,accept);
end

function yes = local_is_latent_defensive_proposal(proposal)
yes = isstruct(proposal) && isfield(proposal,'schemaVersion') && ...
    strcmp(proposal.schemaVersion,'steady_uq_b_prior_latent_defensive_v1');
end

function [weights,logMeanWeight] = local_normalize_log_weights(logWeight)
maximum = max(logWeight);
raw = exp(logWeight-maximum);
weights = raw/sum(raw);
logMeanWeight = maximum+log(sum(raw))-log(numel(raw));
end

function record = local_empty_stage()
record = struct('index',0,'beta',NaN,'delta_beta',NaN, ...
    'ess_before_resample',NaN,'resampled',false, ...
    'block_scale_after_adaptation',nan(1,4), ...
    'block_attempted',zeros(1,4),'block_accepted',zeros(1,4), ...
    'block_acceptance',nan(1,4), ...
    'cross_null_scale_after_adaptation',NaN,'guided_acceptance',NaN, ...
    'valid_fraction',NaN,'unique_ancestor_count',0,'move_sweeps',0);
end

function value = local_option(options,name,defaultValue)
if isstruct(options) && isfield(options,name) && ~isempty(options.(name))
    value = options.(name);
else
    value = defaultValue;
end
end
