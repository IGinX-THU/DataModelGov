function result = Start_SteadyModelUQ_04_AnalyticMeasurementUncertainty(userCfg)
%START_STEADYMODELUQ_04_ANALYTICMEASUREMENTUNCERTAINTY 构造冻结误差协方差。
if nargin < 1, userCfg = struct(); end
timer = tic;
manifest = sht_steady_model_uq_io('resolve', userCfg);
step1 = sht_steady_model_uq_io('loadstep', manifest, 1);
contract = step1.contract;
inputUncertainty = sht_steady_model_uq_common('inputcovariance', contract);
measurement = sht_steady_model_uq_common( ...
    'measurementcovariance', contract, inputUncertainty);
selected = measurement.selected;
relativeSymmetryError = norm(selected.covariance-selected.covariance.','fro') / ...
    max(norm(selected.covariance,'fro'),eps);
passed = relativeSymmetryError < 1e-12 && ...
    all(diag(selected.covariance) > 0) && selected.jitter < 1e-6*mean(diag(selected.covariance));
if ~passed
    error('SHT:SteadyUQ:MeasurementCovarianceAcceptanceFailed', ...
        '测量协方差验收失败：symmetry=%.3e, jitter=%.3e。', ...
        relativeSymmetryError, selected.jitter);
end
result = struct('inputUncertainty', inputUncertainty, ...
    'measurement', measurement, 'relativeSymmetryError', ...
    relativeSymmetryError, 'passed', passed, 'truthRead', false, ...
    'testDataRead', false);
runtime = toc(timer);
[manifest, file] = sht_steady_model_uq_io( ...
    'savestep', manifest, 4, 'analytic_measurement_uncertainty', result, runtime);

standardDeviation = sqrt(diag(selected.covariance));
step3 = sht_steady_model_uq_io('loadstep', manifest, 3);
uncertaintyTable = table(step3.label, step3.unit, standardDeviation, ...
    'VariableNames', {'label','unit','total_standard_deviation'});
writetable(uncertaintyTable, sht_steady_model_uq_io( ...
    'reportfile', manifest, 'UQ04_observation_standard_deviation.csv'));
figureHandle = figure('Visible', contract.config.figureVisible, ...
    'Name', '2.4 UQ covariance correlation');
scale = sqrt(diag(selected.covariance));
correlation = selected.covariance ./ max(scale*scale.', eps);
imagesc(correlation, [-1,1]); axis image; colorbar;
title('2.4 UQ冻结误差相关矩阵'); xlabel('观测序号'); ylabel('观测序号');
saveas(figureHandle, sht_steady_model_uq_io( ...
    'reportfile', manifest, 'UQ04_measurement_correlation.png'));
close(figureHandle);
fprintf('[2.4UQ.4] 协方差完成：输入差分变体=%d，情景=%s，jitter=%.3e。\n', ...
    inputUncertainty.variantCount, measurement.selectedName, selected.jitter);
fprintf('[2.4UQ.4] 产物：%s\n', file);
result.manifest = manifest;
end

