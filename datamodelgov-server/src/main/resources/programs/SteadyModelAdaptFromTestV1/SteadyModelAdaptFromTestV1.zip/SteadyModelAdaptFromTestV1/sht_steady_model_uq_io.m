function varargout = sht_steady_model_uq_io(action, varargin)
%SHT_STEADY_MODEL_UQ_IO 2.4稳态参数不确定性量化的独立结果管理。
%
% 所有中间产物写入 MiddleData/steady_model_uq_v2/<runId>，图表和文本
% 写入外层 report_outputs/steady_model_uq_v2/<runId>。该命名空间与
% flight_model_uq_v2完全隔离。

switch lower(char(action))
    case 'paths'
        varargout{1} = local_paths();
    case 'createrun'
        varargout{1} = local_create_run(varargin{:});
    case 'resolve'
        varargout{1} = local_resolve(varargin{:});
    case 'savestep'
        [varargout{1:nargout}] = local_save_step(varargin{:});
    case 'loadstep'
        varargout{1} = local_load_step(varargin{:});
    case 'savemanifest'
        local_save_manifest(varargin{:});
    case 'reportfile'
        varargout{1} = local_report_file(varargin{:});
    case 'writetext'
        local_write_text(varargin{:});
    otherwise
        error('SHT:SteadyUQ:UnknownIoAction', '未知UQ IO动作：%s。', action);
end
end

function paths = local_paths()
programRoot = fileparts(mfilename('fullpath'));
projectRoot = fileparts(programRoot);
paths = struct();
paths.programRoot = programRoot;
paths.projectRoot = projectRoot;
paths.middleRoot = fullfile(programRoot, 'MiddleData', 'steady_model_uq_v2');
paths.reportRoot = fullfile(projectRoot, 'report_outputs', 'steady_model_uq_v2');
paths.latestFile = fullfile(paths.middleRoot, 'latest_manifest.mat');
local_mkdir(paths.middleRoot);
local_mkdir(paths.reportRoot);
end

function manifest = local_create_run(userCfg)
if nargin < 1 || isempty(userCfg)
    userCfg = struct();
end
paths = local_paths();
if isfield(userCfg, 'runId') && ~isempty(userCfg.runId)
    runId = char(userCfg.runId);
else
    runId = ['steady_uq_' datestr(now, 'yyyymmdd_HHMMSS')];
end
runDir = fullfile(paths.middleRoot, runId);
reportDir = fullfile(paths.reportRoot, runId);
if exist(runDir, 'dir') == 7
    error('SHT:SteadyUQ:RunExists', '运行目录已存在：%s。', runDir);
end
local_mkdir(runDir);
local_mkdir(reportDir);

manifest = struct();
manifest.schemaVersion = 'steady_model_uq_v2';
manifest.runId = runId;
manifest.createdAt = datestr(now, 30);
manifest.updatedAt = manifest.createdAt;
manifest.programRoot = paths.programRoot;
manifest.runDir = runDir;
manifest.reportDir = reportDir;
manifest.status = 'created';
manifest.completedStep = 0;
manifest.stepFiles = cell(10, 1);
manifest.stepNames = cell(10, 1);
manifest.stepRuntime_s = nan(10, 1);
manifest.randomSeed = local_option(userCfg, 'randomSeed', 20260821);
manifest.route = char(local_option(userCfg, 'route', 'transient_instant'));
local_save_manifest(manifest);
end

function manifest = local_resolve(userCfg)
if nargin < 1 || isempty(userCfg)
    userCfg = struct();
end
paths = local_paths();
if isfield(userCfg, 'runId') && ~isempty(userCfg.runId)
    file = fullfile(paths.middleRoot, char(userCfg.runId), 'manifest.mat');
else
    file = paths.latestFile;
end
if exist(file, 'file') ~= 2
    error('SHT:SteadyUQ:ManifestMissing', ...
        '未找到UQ运行清单：%s。请先运行步骤1或总入口。', file);
end
s = load(file, 'manifest');
manifest = s.manifest;
end

function [manifest, file] = local_save_step(manifest, step, name, payload, runtime_s)
if step < 1 || step > 10 || step ~= floor(step)
    error('SHT:SteadyUQ:BadStep', '步骤号必须为1至10的整数。');
end
if nargin < 5 || isempty(runtime_s)
    runtime_s = NaN;
end
safeName = regexprep(char(name), '[^A-Za-z0-9_]', '_');
file = fullfile(manifest.runDir, sprintf('step%02d_%s.mat', step, safeName));
save(file, 'payload', '-v7.3');
manifest.stepFiles{step} = file;
manifest.stepNames{step} = char(name);
manifest.stepRuntime_s(step) = runtime_s;
manifest.completedStep = max(manifest.completedStep, step);
manifest.updatedAt = datestr(now, 30);
manifest.status = sprintf('step_%02d_complete', step);
if step == 10
    manifest.status = 'complete';
end
local_save_manifest(manifest);
end

function payload = local_load_step(manifest, step)
if step < 1 || step > numel(manifest.stepFiles) || ...
        isempty(manifest.stepFiles{step})
    error('SHT:SteadyUQ:StepMissing', '运行%s尚无步骤%d产物。', ...
        manifest.runId, step);
end
file = manifest.stepFiles{step};
if exist(file, 'file') ~= 2
    error('SHT:SteadyUQ:StepFileMissing', '步骤文件不存在：%s。', file);
end
s = load(file, 'payload');
payload = s.payload;
end

function local_save_manifest(manifest)
local_mkdir(manifest.runDir);
file = fullfile(manifest.runDir, 'manifest.mat');
save(file, 'manifest');
paths = local_paths();
save(paths.latestFile, 'manifest');
end

function file = local_report_file(manifest, name)
local_mkdir(manifest.reportDir);
file = fullfile(manifest.reportDir, char(name));
end

function local_write_text(file, content)
[folder, ~, ~] = fileparts(file);
local_mkdir(folder);
fid = fopen(file, 'w', 'n', 'UTF-8');
if fid < 0
    error('SHT:SteadyUQ:TextOpenFailed', '无法写入文本文件：%s。', file);
end
cleanupObject = onCleanup(@() fclose(fid));
fprintf(fid, '%s', char(content));
clear cleanupObject;
end

function local_mkdir(folder)
if exist(folder, 'dir') ~= 7
    [ok, message] = mkdir(folder);
    if ~ok
        error('SHT:SteadyUQ:MkdirFailed', '无法创建目录%s：%s。', folder, message);
    end
end
end

function value = local_option(options, name, defaultValue)
if isstruct(options) && isfield(options, name) && ~isempty(options.(name))
    value = options.(name);
else
    value = defaultValue;
end
end
