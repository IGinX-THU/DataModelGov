function sht_engine_close(engine)
% 阅读说明：
%   本文件负责卸载 GTESS.dll。
%   若库未加载或句柄为空，函数直接返回，便于异常退出时清理。
%SHT_ENGINE_CLOSE Release GTESS DLL resources.
% 释放 GTESS.dll。
%
% 与 SFunc_EngModel.Terminate 对应：先调用 DLL_SHT_Free，再 unloadlibrary。

if isempty(engine) || ~isfield(engine, 'libraryName')
    libraryName = 'GTESS';
else
    libraryName = engine.libraryName;
end

if libisloaded(libraryName)
    try
        calllib(libraryName, 'DLL_SHT_Free');
    catch
    end
    % 异常退出路径可能在DLL资源释放期间触发外层卸载。再次检查别名
    % 状态，避免对已经卸载的库重复调用unloadlibrary。
    if libisloaded(libraryName)
        unloadlibrary(libraryName);
    end
end
end
