# 2.4阶段交付程序与界面调用说明

## 1. 文档用途

本文件面向后续界面开发人员，说明 `SteadyModelAdaptFromTestV1` 程序包的业务边界、目录结构、数据合同、正式入口、输出结构和调用约束。界面开发环境不需要依赖原项目对话，也不应通过解析 MATLAB 命令行文字来获取业务结果；界面应调用本文件列出的正式入口，并读取返回结构体、MAT 文件或结构化表格。

本程序包对应“稳态试车工况点模型自适应修正”功能。它以六部件涡轴发动机模型为对象，完成：

1. 真实稳态试车均值数据导入与合同检查；
2. 稳态模型路径和瞬态时刻路径的独立参数辨识；
3. 基准模型与辨识后模型的工程可辨识性分析；
4. 关键修正系数评估与全修正系数评估；
5. 未参与辨识的测试集稳态验证；
6. 任意单工况的确定性预测和后验95%置信区间预测；
7. UQ 完整运行前的轻量耗时预估。

## 2. 交付边界

### 2.1 实际交付功能

- “真实试车辨识与测试验证”属于正式交付功能；
- “无测量数据的新工况预测”属于正式交付功能；
- 参数真值仅用于研发阶段另行验证，不是本交付包正式入口的输入；
- 测试数据若不存在，参数辨识仍可运行，测试验证入口应返回“安全跳过”；
- 稳态模型路径与瞬态时刻路径彼此独立，不互相覆盖辨识结果。

### 2.2 发动机模型程序包

交付目录内的 `GTESS.dll` 是当前发动机仿真 C 程序编译得到的运行库，`GTESS.h`、`blockAndFunctions.h` 和 `types_TMATS.H` 是接口依赖。当前同步版本已包含最新进口边界模式、六部件修正系数调度和共同工作求解改动。

本目录不保存 C 源程序工程。界面部署时使用已编译 DLL；后续如重新编译 C 程序，必须同时替换根目录和运行时副本中的 DLL/头文件，并重新执行：

```matlab
runtime = sht_prepare_control_model_runtime(pwd);
```

该函数会在 `MiddleData/control_model_runtime/mode1` 重建六部件模型运行副本，避免设计配置与闭环/稳态回放配置相互污染。

## 3. 目录结构

```text
SteadyModelAdaptFromTestV1/
├─ TestData/                         训练集和可选测试集Excel
├─ MiddleData/                       正式中间结果与latest结果
│  └─ control_model_runtime/mode1/   六部件DLL独立运行副本
├─ GTESS.dll / GTESS.h               发动机模型运行库与接口
├─ Turboshaft-TS-Split.mdl           六部件设计配置
├─ *.MAP                             六部件模型引用的特性图
├─ Start_*.m                         面向用户或界面的正式入口
├─ sht_*.m                           共享算法、数据和DLL适配函数
└─ README_2.4阶段交付程序与界面调用说明.md
```

运行产生的图片、Excel 和 Markdown 摘要不写入程序目录，而写入上一级功能目录下的：

```text
../report_outputs/steady_model_adapt_v2/
../report_outputs/steady_model_uq_v2/
../report_outputs/steady_model_uq_method_b/
```

## 4. 运行环境与启动方式

### 4.1 基本要求

- Windows 64 位；
- MATLAB R2020a；
- MATLAB 当前目录切换到本程序包根目录；
- DLL、头文件、MDL、MAP 和 `MiddleData/RunModelSHT_V2_design_state.mat` 完整；
- 不要求并行计算；
- 长时间 UQ 应由界面后台任务执行，不能阻塞按钮回调。

### 4.2 初始化检查

界面创建项目后建议依次执行：

```matlab
addpath(programRoot);
runtime = sht_prepare_control_model_runtime(programRoot);
cfg = sht_default_config(struct('engine', struct('modelMode', 1)));
```

初始化成功后，应保存程序根目录、DLL 哈希、运行时目录、训练/测试数据路径和当前配置指纹。任一关键输入变化时，原辨识、UQ 和验证结果均应标记为“需要复核”。

## 5. 试车数据合同

训练集和测试集均为 Excel，每行对应一个稳态工况点的稳态窗口时间历程平均值。正式字段如下：

| 字段 | 含义 | 单位 | 角色 |
|---|---|---:|---|
| `point_id` | 工况编号 | - | 主键 |
| `Np_mean` | PT轴转速 | rpm | 测量 |
| `Ng_mean` | GT轴转速 | rpm | 测量 |
| `Wf_mean` | 燃油流量 | kg/s | 测量输入 |
| `Mkp_mean` | PT负载/输出轴传递扭矩 | N·m | 模型输入 |
| `Mkg_mean` | GT外部附件负载扭矩 | N·m | 模型输入 |
| `Pt2_mean` | 压气机入口总压 | Pa | 模式4模型输入 |
| `Tt1_mean` | 进口总温测量 | K | 模式4模型输入 |
| `Pt3_mean` | 压气机出口总压 | Pa | 拟合输出 |
| `Tt3_mean` | 压气机出口总温 | K | 拟合输出 |
| `Tt45_mean` | 45截面总温 | K | 拟合输出 |
| `Pt45_mean` | 45截面总压 | Pa | 拟合输出 |
| `Pamb_mean` | 环境静压 | Pa | 环境输入 |
| `Tamb_mean` | 环境静温 | K | 环境输入 |
| `Altitude_mean` | 高度 | m | 记录/预测模式输入 |
| `Mach_mean` | 马赫数 | - | 环境输入 |

正式参数辨识默认使用进口边界模式4。该模式由 DLL 根据环境边界重构未测量的 `Pt1`，使用测量 `Tt1` 和测量 `Pt2`，并将 `Pt2` 直接作为 AC 进口压力。`Pt2` 不再同时进入拟合残差，进气道附加压损由 `Pt1/Pt2` 逐工况直接反算。

## 6. 进口边界模式

`sht_apply_inlet_boundary_stepin.m` 是 MATLAB 与 DLL 的唯一命名入口适配器。模式含义如下：

| 模式 | 输入 | 用途 |
|---:|---|---|
| 0 | 初始化时的高度、Mach、非标准温差 | 历史锁存环境模式；当前2.4正式入口不使用 |
| 1 | `Pt1/Tt1/Pamb` | 历史外部Pt1接口回归，不作为当前默认辨识模式 |
| 2 | `Pamb/Tamb/Mach` | DLL重构`Pt1/Tt1`，用于替代试车数据生成和直接环境预测 |
| 3 | `Altitude/Tamb/Mach` | DLL按标准大气计算`Pamb`并重构入口总参数，用于高度环境预测 |
| 4 | `Pamb/Tamb/Mach/Tt1/Pt2` | 当前稳态修正系数辨识与测试回放 |

界面不能直接写 `stepIn` 数组。所有模式相关输入必须先构造命名结构体，再调用 MATLAB 适配函数。

## 7. 参数辨识方法与结果结构

### 7.1 两条独立路线

稳态模型路线入口：

```matlab
result = Start_SteadyModelAdapt_V2_02_SteadyModelParameterEstimation(trainingDataFile);
```

瞬态时刻路线入口：

```matlab
result = Start_SteadyModelAdapt_V2_03_TransientInstantEstimation(trainingDataFile);
```

界面默认选择瞬态时刻路线。当前两条路线的默认正则化配置为：

| 阶段 | 瞬态时刻路线 | 稳态模型路线 |
|---|---|---|
| A | 无阻尼 TSVD，保留 `r=6` | 无阻尼 TSVD，保留 `r=4` |
| B | Tikhonov，尺度 `s=0.75` | Tikhonov，尺度 `s=0.50` |
| C | 调度节点组装，无独立正则化配置 | 同左 |
| D | Tikhonov，尺度 `s=1.00` | Tikhonov，尺度 `s=1.00` |

界面可为 A、B、D 选择 TSVD 或 Tikhonov，并按方法显示保留奇异值个数或正则化尺度。当前程序不使用阻尼 TSVD。

`trainingDataFile` 可省略；省略时读取 `TestData/steady_bench_2p4_training_means.xlsx`。两条路线都执行：

1. 阶段A：全部训练工况的常值估计；
2. 阶段B：按 AC 相对换算转速分组的组内估计；
3. 阶段C：将调度参数形成节点曲线，将非调度参数组间合并；
4. 阶段D：在全部训练工况上联合微调最终调度函数。

正式估计对象为10个发动机修正参数和1个燃油偏置。`Wf_bias` 使用 kg/s，不能与无量纲参数混合计算参数RMSE。

### 7.2 结果读取

界面优先读取函数返回的 `result`，关键字段为：

| 字段 | 内容 |
|---|---|
| `result.groups` | AC相对换算转速分组及工况归属 |
| `result.parameterTable` | 设计点参数结果 |
| `result.groupEstimateTable` | 分组常值估计 |
| `result.scheduleNodeTable` | 调度节点坐标与节点值 |
| `result.finalSchedule` | 稳态辨识模型的完整调度函数 |
| `result.predictionTrainingTable` | 训练集逐工况输出对比 |
| `result.predictionTestTable` | 若启用测试集时的输出对比 |
| `result.final.trainingMetrics` | 训练集输出误差统计 |
| `result.acceptance` | 正式验收状态与停止原因 |
| `result.output` | MAT、Excel、图和摘要文件路径 |

界面参数曲线不得从命令行复制数值。调度参数应从 `scheduleNodeTable` 或 `finalSchedule` 绘制；设计点结果应使用最终调度函数在设计点求值。

## 8. 工程可辨识性

正式入口：

```matlab
result = Start_SteadyModelAdapt_V2_16_EngineeringIdentifiabilityAnalysis();
```

该程序在基准模型和D阶段辨识结果处分别进行局部线性分析，区分：

- 当前局部范围内可辨识；
- 参数自身低敏感；
- 依赖其他参数补偿。

主界面应显示工程分类、原始信息质量、正则化后状态和证据入口。奇异值、标准化信息矩阵条件数及补偿方向是证据，不应替代工程结论。

## 9. 不确定性评估

### 9.1 关键修正系数评估

```matlab
manifest = Start_SteadyModelUQ_00_RunAll(userCfg);
```

面向辨识阶段使用的总体调度参数、常值参数和燃油偏置。结果目录由 `sht_steady_model_uq_io.m` 管理。

### 9.2 全修正系数评估

```matlab
manifest = Start_SteadyModelUQ_B_00_RunAll(userCfg);
```

在关键修正系数之外纳入六部件局部常值修正和物理引气不确定性。两种方法并列独立运行，不把方法A后验直接当作方法B先验。

### 9.3 界面显示

界面统一使用“95%置信区间”作为名称，并至少区分：

- 参数95%置信区间；
- 模型输出95%置信区间；
- 可观测量95%置信区间。

其中模型输出区间只传播参数不确定性；可观测量区间还叠加测量误差合同。界面绘图应读取程序输出表中的下限、中心和上限，不能直接嵌入某次静态 PNG 作为正式结果。

### 9.4 运行时间轻量预估

```matlab
estimateA = sht_estimate_steady_uq_runtime('A', userCfg);
estimateB = sht_estimate_steady_uq_runtime('B', userCfg);
```

该函数只建立概率合同并执行少量 DLL 试算，不运行完整 SMC。界面读取：

- `estimatedRangeText`：预计耗时范围；
- `estimatedCenterText`：中心估计；
- `source`：估算依据；
- `probe`：少量试算信息；
- `fullUqExecuted=false`：确认没有误启动完整 UQ。

## 10. 测试集验证

```matlab
result = Start_SteadyModelAdapt_V2_05_TestDataValidation( ...
    testDataFile, estimationResultFile);
```

两个参数均可省略。测试集不存在时，程序返回：

```text
performed = false
status = 'skipped_no_test_data'
```

而不是报错。测试验证不更新参数，不读取真值。界面测试验证页应提供两个分页：

1. 六个稳态输出的零修正模型、稳态辨识模型与测量值对比；
2. 六个输出的误差标准差对比。

固定测试集的正式后验传播能力仍由下述入口保留，供不确定性评估、专项分析或结果中心调用，但不在测试验证主页面展示。

方法B固定测试集稳态后验传播入口为：

```matlab
result = Start_SteadyModelUQ_B_12_AdditionalSteadyPrediction(userCfg);
```

## 11. 任意单工况预测

正式入口：

```matlab
result = Start_SteadyModelPredict_01_InputDrivenPrediction( ...
    modelInput, estimationResultFile, posteriorOptions);
```

### 11.1 直接环境边界

```matlab
modelInput = struct( ...
    'point_id', "CUSTOM_POINT", ...
    'inletBoundaryMode', 2, ...
    'Pamb', Pamb, 'Tamb', Tamb, 'Mach', Mach, ...
    'Wf_model', Wf_model, 'Mkp', Mkp, 'Mkg', Mkg);
```

### 11.2 高度环境边界

```matlab
modelInput = struct( ...
    'point_id', "CUSTOM_POINT", ...
    'inletBoundaryMode', 3, ...
    'Altitude', Altitude, 'Tamb', Tamb, 'Mach', Mach, ...
    'Wf_model', Wf_model, 'Mkp', Mkp, 'Mkg', Mkg);
```

### 11.3 确定性预测

```matlab
result = Start_SteadyModelPredict_01_InputDrivenPrediction( ...
    modelInput, estimationResultFile);
```

### 11.4 后验95%置信区间预测

```matlab
posteriorOptions = struct('method', 'A', 'runId', 'latest');
result = Start_SteadyModelPredict_01_InputDrivenPrediction( ...
    modelInput, estimationResultFile, posteriorOptions);
```

`method` 可取 `A` 或 `B`。返回结果中的：

```text
result.posteriorPrediction.intervalTable
```

包含各输出的模型下限、模型中心、模型上限、可观测下限、可观测中心、可观测上限和稳态辨识模型输出。界面应在同一子图中错位绘制四类对象，避免相互遮挡。

## 12. UI后台任务适配原则

1. MATLAB 入口必须在后台进程或后台任务中运行；
2. 进度显示读取结构化状态和结果文件，不解析控制台中文；
3. 项目创建时保存训练数据、测试数据、DLL、配置和算法文件指纹；
4. 长任务取消应等待当前 DLL 调用结束，并保存已有检查点；
5. `latest.mat` 用于默认引用，带时间戳文件用于追溯；
6. 只有通过验收且未读取真值的结果才允许发布为稳态辨识模型；
7. 后验、稳态辨识模型和输入数据合同不兼容时，区间功能必须禁用并给出原因；
8. 界面统一显示“95%置信区间”，但内部仍按程序输出的后验分位数读取下限和上限。

## 13. 当前独立目录回归状态

本次同步后已在独立目录完成：

- 六部件运行时副本重建；
- 根目录与运行时 `GTESS.dll/GTESS.h` 哈希一致性检查；
- 默认设计点单工况确定性预测；
- 3个测试工况的稳态测试集验证；
- 方法A、方法B运行时间轻量试算；
- 中文目录且不包含飞参UQ程序时的空指纹哈希兼容性检查。

界面开发人员可以直接以本目录作为算法后端，不需要回到原开发目录补文件。
