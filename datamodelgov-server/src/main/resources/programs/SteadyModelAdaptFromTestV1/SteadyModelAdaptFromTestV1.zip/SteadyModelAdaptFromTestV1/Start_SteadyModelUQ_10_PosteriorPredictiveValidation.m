function result = Start_SteadyModelUQ_10_PosteriorPredictiveValidation(userCfg)
%START_STEADYMODELUQ_10_POSTERIORPREDICTIVEVALIDATION 后验预测与隔离真值验证。
%
% 本步骤是2.4 UQ唯一允许读取测试集和替代数据隐藏真值的阶段。执行顺序
% 固定为：冻结后验样本 -> 训练/测试精确预测 -> 冻结预测区间 -> 打开隐藏
% 真值作事后验证。隐藏真值不参与提议调节、协方差校准或验收门限设置。

if nargin < 1, userCfg = struct(); end
timer = tic;
manifest = sht_steady_model_uq_io('resolve',userCfg);
step1 = sht_steady_model_uq_io('loadstep',manifest,1);
step4 = sht_steady_model_uq_io('loadstep',manifest,4);
step8 = sht_steady_model_uq_io('loadstep',manifest,8);
step9 = sht_steady_model_uq_io('loadstep',manifest,9);
if ~(step8.passed && step9.passed)
    error('SHT:SteadyUQ:PosteriorNotFrozen', ...
        '步骤8和步骤9必须先通过，才能执行独立预测验证。');
end
contract = step1.contract;
formal = step8.formal;

%% 1. 在测试域审计全部正式粒子，并冻结可用于预测的后验支持集
sampleCount = local_option(userCfg,'posteriorPredictiveSampleCount', ...
    contract.config.posteriorPredictiveSampleCount);
minimumTestValidPosteriorMass = local_option(userCfg, ...
    'minimumTestValidPosteriorMass',0.95);
testData = sht_steady_model_uq_common('loaddata',contract,'test');
[testObservation,testLabels,testUnits] = ...
    sht_steady_model_uq_common('observation',contract,testData);
[uniqueTheta,~,inverseFormal] = unique(formal.theta.','rows');
uniqueTheta = uniqueTheta.';
testCacheFile = fullfile(manifest.runDir, ...
    ['exact_test_cache_' contract.contractHash '.mat']);
testExactUnique = sht_steady_model_uq_common('evaluate',contract,uniqueTheta, ...
    testData,struct('useCache',true,'cacheFile',testCacheFile));
formalValid = testExactUnique.valid(inverseFormal);
validPosteriorMass = sum(formal.weights(formalValid));
invalidPosteriorMass = 1-validPosteriorMass;
testReplayValidityPassed = validPosteriorMass>=minimumTestValidPosteriorMass;
if validPosteriorMass<=0
    error('SHT:SteadyUQ:NoValidTestPosteriorSupport', ...
        '正式后验在独立测试域没有任何可回放的概率质量。');
end
predictiveWeight = formal.weights(:).';
predictiveWeight(~formalValid) = 0;
predictiveWeight = predictiveWeight/sum(predictiveWeight);
sampleIndex = local_systematic_resample_index(predictiveWeight,sampleCount, ...
    contract.config.randomSeed+10001);
thetaPredictive = formal.theta(:,sampleIndex);

%% 2. 在训练集上复用已完成的精确DLL结果
[trainingObservation,trainingLabels,trainingUnits] = ...
    sht_steady_model_uq_common('observation',contract,contract.trainingData);
trainingPrediction = trainingObservation + formal.exact.residual(:,sampleIndex);
trainingMeasurement = step4.measurement;
[trainingModelInterval,trainingObservableInterval] = ...
    local_prediction_intervals(trainingPrediction, ...
    trainingMeasurement.selected.cholLower,contract.config.randomSeed+10002);
trainingTable = local_prediction_table(contract.trainingData,contract, ...
    trainingObservation,trainingLabels,trainingUnits, ...
    trainingModelInterval,trainingObservableInterval);

%% 3. 使用测试域有效支持集形成独立工况预测
testResidualFormal = testExactUnique.residual(:,inverseFormal);
testPrediction = testObservation + testResidualFormal(:,sampleIndex);

% 测试集测量协方差必须按三个测试工况重新传播，不能复用训练集42维矩阵。
testInputUncertainty = sht_steady_model_uq_common( ...
    'inputcovariance',contract,testData);
testMeasurement = sht_steady_model_uq_common( ...
    'measurementcovariance',contract,testInputUncertainty,testData);
[testModelInterval,testObservableInterval] = ...
    local_prediction_intervals(testPrediction, ...
    testMeasurement.selected.cholLower,contract.config.randomSeed+10003);
testTable = local_prediction_table(testData,contract,testObservation, ...
    testLabels,testUnits,testModelInterval,testObservableInterval);

%% 4. 单独形成进气道压损直接反算的不确定性结果
% 该结果在隐藏真值打开前即冻结；Inlet_K_dP不进入61维联合后验。
deterministic = load(contract.deterministicResultFile,'result');
inletTable = local_inlet_uncertainty_table( ...
    deterministic.result,contract);

% 到此后验及全部预测区间已经冻结。以下代码才允许访问合成数据真值。
%% 5. 匹配隔离真值并执行事后覆盖诊断
[truthAvailable,truthFile,truthMetadata,truthTableSource] = ...
    local_find_matching_truth(testData);
parameterTable = step9.summaryTable;
parameterTable.posterior_mean_minus_deterministic = ...
    parameterTable.posterior_mean-parameterTable.deterministic_estimate;
parameterTable.deterministic_inside_95 = ...
    parameterTable.deterministic_estimate>=parameterTable.q025 & ...
    parameterTable.deterministic_estimate<=parameterTable.q975;
parameterTable.truth_value = nan(height(parameterTable),1);
parameterTable.posterior_mean_minus_truth = nan(height(parameterTable),1);
parameterTable.truth_inside_95 = false(height(parameterTable),1);
if truthAvailable
    parameterTruth = local_parameter_truth( ...
        contract,truthMetadata,truthTableSource);
    parameterTable.truth_value = parameterTruth;
    parameterTable.posterior_mean_minus_truth = ...
        parameterTable.posterior_mean-parameterTruth;
    parameterTable.truth_inside_95 = parameterTruth>=parameterTable.q025 & ...
        parameterTruth<=parameterTable.q975;
    trainingTruth = local_output_truth(contract,truthTableSource, ...
        contract.trainingData.point_id);
    testTruth = local_output_truth(contract,truthTableSource,testData.point_id);
    trainingTable = local_attach_truth(trainingTable,trainingTruth);
    testTable = local_attach_truth(testTable,testTruth);
    inletTable = local_attach_inlet_truth(inletTable,truthMetadata);
else
    trainingTable = local_attach_truth(trainingTable, ...
        nan(height(trainingTable),1));
    testTable = local_attach_truth(testTable,nan(height(testTable),1));
    inletTable.truth_value = nan(height(inletTable),1);
    inletTable.truth_inside_95 = false(height(inletTable),1);
end

trainingSummary = local_channel_summary(trainingTable,truthAvailable);
testSummary = local_channel_summary(testTable,truthAvailable);
parameterDiagnostic = local_parameter_diagnostic( ...
    parameterTable,truthAvailable,contract);

%% 6. 验收、基线隔离检查和产物保存
flightFingerprintAfter = sht_steady_model_uq_common('flightuqfingerprint');
flightUqUnchanged = strcmp(contract.flightUqFingerprintBefore.aggregateHash, ...
    flightFingerprintAfter.aggregateHash);
passed = testReplayValidityPassed && all(isfinite(testPrediction(:))) && ...
    all(testTable.model_q025<=testTable.model_q975) && ...
    all(testTable.observable_q025<=testTable.observable_q975) && ...
    flightUqUnchanged;

result = struct();
result.schemaVersion = 'steady_model_uq_v2_node_step10';
result.sampleCount = sampleCount;
result.sampleIndex = sampleIndex;
result.thetaPredictive = thetaPredictive;
result.trainingPrediction = trainingPrediction;
result.testPrediction = testPrediction;
result.trainingTable = trainingTable;
result.testTable = testTable;
result.trainingSummary = trainingSummary;
result.testSummary = testSummary;
result.parameterTable = parameterTable;
result.scheduleNodeTruthTable = parameterTable;
result.parameterDiagnostic = parameterDiagnostic;
result.inletPressureLossTable = inletTable;
result.testInputUncertainty = testInputUncertainty;
result.testMeasurement = testMeasurement;
result.testExactDiagnostic = struct( ...
    'formalParticleCount',size(formal.theta,2), ...
    'uniquePosteriorPointCount',size(uniqueTheta,2), ...
    'validFormalParticleCount',nnz(formalValid), ...
    'invalidFormalParticleCount',nnz(~formalValid), ...
    'validPosteriorMass',validPosteriorMass, ...
    'invalidPosteriorMass',invalidPosteriorMass, ...
    'minimumValidPosteriorMass',minimumTestValidPosteriorMass, ...
    'testReplayValidityPassed',testReplayValidityPassed, ...
    'predictiveDistributionConditionedOnValidTestSupport',true, ...
    'dllEvaluationCount',testExactUnique.dllEvaluationCount, ...
    'cacheHitCount',testExactUnique.cacheHitCount, ...
    'dllRuntime_s',testExactUnique.dllRuntime_s,'cacheFile',testCacheFile);
result.truthAvailable = truthAvailable;
result.truthRead = truthAvailable;
result.truthFile = truthFile;
result.testDataRead = true;
result.flightUqFingerprintBefore = contract.flightUqFingerprintBefore;
result.flightUqFingerprintAfter = flightFingerprintAfter;
result.flightUqUnchanged = flightUqUnchanged;
result.acceptance = struct( ...
    'minimumTestValidPosteriorMass',minimumTestValidPosteriorMass, ...
    'validTestPosteriorMass',validPosteriorMass, ...
    'testReplayValidityPassed',testReplayValidityPassed, ...
    'testReplayFinite',all(isfinite(testPrediction(:))), ...
    'predictionIntervalsOrdered',all(testTable.model_q025<=testTable.model_q975) && ...
        all(testTable.observable_q025<=testTable.observable_q975), ...
    'flightUqUnchanged',flightUqUnchanged,'truthNotUsedAsGate',true, ...
    'passed',passed);
result.passed = passed;
result.assessmentReportFile = sht_steady_model_uq_io( ...
    'reportfile',manifest,'UQ10_execution_summary.md');
runtime = toc(timer);
[manifest,file] = sht_steady_model_uq_io('savestep',manifest,10, ...
    'posterior_predictive_validation',result,runtime);

writetable(parameterTable,sht_steady_model_uq_io( ...
    'reportfile',manifest,'UQ10_schedule_node_truth_comparison.csv'));
writetable(trainingTable,sht_steady_model_uq_io( ...
    'reportfile',manifest,'UQ10_training_predictive_intervals.csv'));
writetable(testTable,sht_steady_model_uq_io( ...
    'reportfile',manifest,'UQ10_test_predictive_intervals.csv'));
writetable(trainingSummary,sht_steady_model_uq_io( ...
    'reportfile',manifest,'UQ10_training_channel_summary.csv'));
writetable(testSummary,sht_steady_model_uq_io( ...
    'reportfile',manifest,'UQ10_test_channel_summary.csv'));
writetable(inletTable,sht_steady_model_uq_io( ...
    'reportfile',manifest,'UQ10_inlet_pressure_loss_uncertainty.csv'));
local_plot_parameter_truth(parameterTable,contract,manifest,truthAvailable);
local_plot_predictive(testTable,manifest,'test');
local_plot_predictive(trainingTable,manifest,'training');
local_plot_predictive_deviation(testTable,manifest,'test');
local_plot_predictive_deviation(trainingTable,manifest,'training');
local_write_summary(result,step8,step9,manifest,runtime);
fprintf('[2.4UQ.10] 步骤数据文件：%s\n',file);
fprintf(['[2.4UQ.10] 测试域有效后验质量=%.2f%%（门限%.2f%%），' ...
    '无效粒子=%d/%d。\n'],100*validPosteriorMass, ...
    100*minimumTestValidPosteriorMass,nnz(~formalValid),numel(formalValid));
fprintf('[2.4UQ.10] 评估结果文件：%s\n',result.assessmentReportFile);
fprintf('[2.4UQ.10] 图表与明细目录：%s\n',manifest.reportDir);
result.manifest = manifest;
if ~passed
    error('SHT:SteadyUQ:PosteriorPredictiveAcceptanceFailed', ...
        ['后验预测验收未通过；测试域有效后验质量=%.3f，门限=%.3f，' ...
        '检查点已保存：%s。'],validPosteriorMass, ...
        minimumTestValidPosteriorMass,file);
end
end

function index = local_systematic_resample_index(weights,count,seed)
rng(seed,'twister');
weights = weights(:)/sum(weights);
edge = cumsum(weights); edge(end) = 1;
u = (rand/count)+(0:count-1)/count;
index = zeros(1,count); j = 1;
for i = 1:count
    while u(i)>edge(j), j = j+1; end
    index(i) = j;
end
end

function [modelInterval,observableInterval] = ...
        local_prediction_intervals(prediction,cholLower,seed)
modelInterval = quantile(prediction,[0.025,0.5,0.975],2);
rng(seed,'twister');
drawPerParameter = 4;
base = repelem(prediction,1,drawPerParameter);
noise = cholLower*randn(size(prediction,1),size(base,2));
observable = base+noise;
observableInterval = quantile(observable,[0.025,0.5,0.975],2);
end

function tableOut = local_prediction_table(data,contract,observation,labels,units, ...
        modelInterval,observableInterval)
n = height(data);
name = repmat(string(contract.residualOrder(:)),n,1);
pointId = repelem(string(data.point_id),contract.residualPerPoint,1);
tableOut = table(pointId,name,units(:),labels(:),observation(:), ...
    modelInterval(:,1),modelInterval(:,2),modelInterval(:,3), ...
    observableInterval(:,1),observableInterval(:,2),observableInterval(:,3), ...
    'VariableNames',{'point_id','output','unit','label','measured_value', ...
    'model_q025','model_median','model_q975','observable_q025', ...
    'observable_median','observable_q975'});
tableOut.model_width_95 = tableOut.model_q975-tableOut.model_q025;
tableOut.observable_width_95 = ...
    tableOut.observable_q975-tableOut.observable_q025;
tableOut.measured_inside_model_95 = ...
    tableOut.measured_value>=tableOut.model_q025 & ...
    tableOut.measured_value<=tableOut.model_q975;
tableOut.measured_inside_observable_95 = ...
    tableOut.measured_value>=tableOut.observable_q025 & ...
    tableOut.measured_value<=tableOut.observable_q975;
end

function tableOut = local_attach_truth(tableOut,truth)
tableOut.truth_value = truth(:);
tableOut.truth_inside_model_95 = truth(:)>=tableOut.model_q025 & ...
    truth(:)<=tableOut.model_q975;
tableOut.truth_inside_observable_95 = truth(:)>=tableOut.observable_q025 & ...
    truth(:)<=tableOut.observable_q975;
end

function summary = local_channel_summary(detail,truthAvailable)
names = unique(detail.output,'stable');
n = numel(names);
meanModelWidth = nan(n,1); meanObservableWidth = nan(n,1);
measuredModelCoverage = nan(n,1); measuredObservableCoverage = nan(n,1);
truthModelCoverage = nan(n,1); truthObservableCoverage = nan(n,1);
unit = strings(n,1);
for i = 1:n
    use = detail.output==names(i);
    unit(i) = detail.unit(find(use,1));
    meanModelWidth(i) = mean(detail.model_width_95(use));
    meanObservableWidth(i) = mean(detail.observable_width_95(use));
    measuredModelCoverage(i) = mean(detail.measured_inside_model_95(use));
    measuredObservableCoverage(i) = mean(detail.measured_inside_observable_95(use));
    if truthAvailable
        truthModelCoverage(i) = mean(detail.truth_inside_model_95(use));
        truthObservableCoverage(i) = mean(detail.truth_inside_observable_95(use));
    end
end
summary = table(names,unit,meanModelWidth,meanObservableWidth, ...
    measuredModelCoverage,measuredObservableCoverage, ...
    truthModelCoverage,truthObservableCoverage, ...
    'VariableNames',{'output','unit','mean_model_width_95', ...
    'mean_observable_width_95','measured_model_coverage', ...
    'measured_observable_coverage','truth_model_coverage', ...
    'truth_observable_coverage'});
end

function diagnostic = local_parameter_diagnostic( ...
        tableValue,truthAvailable,contract)
deterministicInsideCount = nnz(tableValue.deterministic_inside_95);
deterministicParameterCount = height(tableValue);
if truthAvailable
    dimensionless = tableValue.unit=="1";
    fuel = tableValue.unit=="kg/s";
    dimensionlessError = tableValue.posterior_mean_minus_truth(dimensionless);
    fuelError = tableValue.posterior_mean_minus_truth(fuel);
    group = unique(contract.parameterTable.group_index,'stable');
    fullyCoveredGroupCount = 0;
    for k = 1:numel(group)
        rows = contract.parameterTable.group_index==group(k);
        fullyCoveredGroupCount = fullyCoveredGroupCount+ ...
            all(tableValue.truth_inside_95(rows));
    end
    diagnostic = struct( ...
        'coveredCount',nnz(tableValue.truth_inside_95), ...
        'parameterCount',height(tableValue), ...
        'deterministicInside95Count',deterministicInsideCount, ...
        'deterministicParameterCount',deterministicParameterCount, ...
        'fullyCoveredGroupCount',fullyCoveredGroupCount, ...
        'groupCount',numel(group), ...
        'dimensionlessCoveredCount',nnz(tableValue.truth_inside_95(dimensionless)), ...
        'dimensionlessParameterCount',nnz(dimensionless), ...
        'dimensionlessRmse',sqrt(mean(dimensionlessError.^2)), ...
        'wfBiasCoveredCount',nnz(tableValue.truth_inside_95(fuel)), ...
        'wfBiasParameterCount',nnz(fuel), ...
        'wfBiasRmse_kgps',sqrt(mean(fuelError.^2)), ...
        'wfBiasMaximumAbsoluteError_kgps',max(abs(fuelError)), ...
        'wfBiasRmsePctDesign',100*sqrt(mean(fuelError.^2))/ ...
            0.151914044493225);
else
    diagnostic = struct('coveredCount',NaN,'parameterCount',height(tableValue), ...
        'deterministicInside95Count',deterministicInsideCount, ...
        'deterministicParameterCount',deterministicParameterCount, ...
        'fullyCoveredGroupCount',NaN,'groupCount', ...
            height(contract.parameterGroupTable), ...
        'dimensionlessCoveredCount',NaN,'dimensionlessParameterCount', ...
            nnz(tableValue.unit=="1"), ...
        'dimensionlessRmse',NaN,'wfBiasCoveredCount',NaN, ...
        'wfBiasParameterCount',nnz(tableValue.unit=="kg/s"), ...
        'wfBiasRmse_kgps',NaN,'wfBiasMaximumAbsoluteError_kgps',NaN, ...
        'wfBiasRmsePctDesign',NaN);
end
end

function tableOut = local_inlet_uncertainty_table(deterministicResult,contract)
direct = deterministicResult.inletPressureLossDirect;
detail = direct.trainingTable;
sensor = sht_measurement_bias_generator('channelConfig',{'Pt2','Pamb'});
sigma = sqrt((sensor.totalBiasHalfWidth(:)/sqrt(3)).^2 + ...
    (sensor.noiseStd(:)/sqrt(contract.steadyWindowSampleCount)).^2);
Pt1 = detail.Pt1_internal_Pa;
Pt2 = detail.Pt2_measured_Pa;
stdValue = sqrt((sigma(1)./Pt1).^2 + ...
    (Pt2.*sigma(2)./(Pt1.^2)).^2);
q025 = detail.direct_K_dP-1.959963984540054*stdValue;
q975 = detail.direct_K_dP+1.959963984540054*stdValue;
tableOut = table(detail.point_id,detail.inlet_corrected_mass_flow, ...
    detail.direct_K_dP,stdValue,q025,q975, ...
    'VariableNames',{'point_id','inlet_corrected_mass_flow', ...
    'direct_estimate','standard_deviation','q025','q975'});
end

function [available,file,metadata,dataTable] = ...
        local_find_matching_truth(testData)
available = false; file = ''; metadata = struct(); dataTable = table();
folder = fullfile(fileparts(mfilename('fullpath')),'TestData', ...
    'test_data_generation');
listing = dir(fullfile(folder,'steady_bench_substitute_*.mat'));
if isempty(listing), return; end
[~,order] = sort([listing.datenum],'descend');
listing = listing(order);
for i = 1:numel(listing)
    candidate = fullfile(listing(i).folder,listing(i).name);
    s = load(candidate,'metadata','dataTable');
    if ~isfield(s,'metadata') || ~isfield(s,'dataTable'), continue; end
    if local_truth_table_matches(s.dataTable,testData)
        available = true; file = candidate;
        metadata = s.metadata; dataTable = s.dataTable;
        return;
    end
end
end

function matched = local_truth_table_matches(source,testData)
matched = true;
id = string(source.point_id);
for i = 1:height(testData)
    row = find(id==string(testData.point_id(i)),1);
    if isempty(row), matched = false; return; end
    names = {'Np','Ng','Wf','Pt2','Tt1','Pt3','Tt3','Tt45','Pt45'};
    for j = 1:numel(names)
        excelName = [names{j} '_mean'];
        if ~ismember(names{j},source.Properties.VariableNames) || ...
                ~ismember(excelName,testData.Properties.VariableNames)
            matched = false; return;
        end
        a = source.(names{j})(row); b = testData.(excelName)(i);
        if abs(a-b)>1e-9*max([1,abs(a),abs(b)])
            matched = false; return;
        end
    end
end
end

function truth = local_parameter_truth(contract,metadata,dataTable)
truth = nan(contract.parameterCount,1);
parameter = metadata.truthHealthScheduleProfile.parameters;
tbl = contract.parameterTable;
wfDesign = contract.scheduleTemplate.fuelBias.wfDesign;
fuelX = dataTable.Wf/wfDesign;
fuelBias = dataTable.Wf-dataTable.Wf_true;
[fuelX,order] = sort(fuelX(:));
fuelBias = fuelBias(order);
[fuelX,~,group] = unique(fuelX);
fuelBias = accumarray(group,fuelBias,[],@mean);
for j = 1:contract.parameterCount
    kind = tbl.group_kind(j);
    if kind=="health_schedule"
        baseName = char(tbl.base_name(j));
        index = find(strcmp({parameter.name},baseName),1);
        if isempty(index)
            error('SHT:SteadyUQ:MissingParameterTruth', ...
                '隐藏真值缺少%s。',baseName);
        end
        entry = parameter(index);
        query = min(max(tbl.coordinate(j),min(entry.xNodes)),max(entry.xNodes));
        truth(j) = interp1(entry.xNodes,entry.kNodes,query,'linear');
    elseif kind=="fuel_bias"
        query = min(max(tbl.coordinate(j),min(fuelX)),max(fuelX));
        truth(j) = interp1(fuelX,fuelBias,query,'linear');
    elseif kind=="constant"
        baseName = char(tbl.base_name(j));
        index = find(strcmp({parameter.name},baseName),1);
        if isempty(index)
            error('SHT:SteadyUQ:MissingParameterTruth', ...
                '隐藏真值缺少%s。',baseName);
        end
        truth(j) = parameter(index).designValue;
    else
        error('SHT:SteadyUQ:UnknownTruthGroupKind', ...
            '未知真值节点组类型%s。',kind);
    end
end
end

function vector = local_output_truth(contract,source,pointIds)
names = contract.residualOrder;
vector = nan(numel(pointIds)*numel(names),1);
sourceId = string(source.point_id);
cursor = 0;
for i = 1:numel(pointIds)
    row = find(sourceId==string(pointIds(i)),1);
    if isempty(row)
        error('SHT:SteadyUQ:MissingOutputTruth','隐藏真值缺少工况%s。', ...
            char(string(pointIds(i))));
    end
    for j = 1:numel(names)
        cursor = cursor+1;
        switch names{j}
            case 'Pt3', vector(cursor) = source.Pt3_true(row);
            case 'Tt3', vector(cursor) = source.Tt3_true(row);
            case 'Tt45', vector(cursor) = source.Tt45_true(row);
            case 'Pt45', vector(cursor) = source.Pt45_true(row);
            case {'dNp_dt','dNg_dt'}, vector(cursor) = 0;
            otherwise
                error('SHT:SteadyUQ:UnsupportedTruthOutput', ...
                    '隐藏真值输出%s尚未配置。',names{j});
        end
    end
end
end

function tableOut = local_attach_inlet_truth(tableOut,metadata)
parameter = metadata.truthHealthScheduleProfile.parameters;
index = find(strcmp({parameter.name},'Inlet_K_dP'),1);
if isempty(index)
    tableOut.truth_value = nan(height(tableOut),1);
else
    entry = parameter(index);
    tableOut.truth_value = interp1(entry.xNodes,entry.kNodes, ...
        min(max(tableOut.inlet_corrected_mass_flow,min(entry.xNodes)), ...
        max(entry.xNodes)),'linear');
end
tableOut.truth_inside_95 = tableOut.truth_value>=tableOut.q025 & ...
    tableOut.truth_value<=tableOut.q975;
end

function local_plot_parameter_truth(tableValue,contract,manifest,truthAvailable)
tbl = contract.parameterTable;
groups = unique(tbl.group_index,'stable');
f = figure('Visible',contract.config.figureVisible,'Position',[60,40,1450,950]);
for g = 1:numel(groups)
    subplot(4,3,g);
    rows = find(tbl.group_index==groups(g));
    x = tbl.coordinate(rows);
    t = tableValue(rows,:);
    if numel(x)==1
        hold on;
        hBand = plot([x,x],[t.q025,t.q975],'-', ...
            'Color',[0.55,0.75,0.92],'LineWidth',8);
        cap = 0.08;
        plot(x+[-cap,cap],[t.q025,t.q025],'-', ...
            'Color',[0.35,0.62,0.84],'LineWidth',1.2);
        plot(x+[-cap,cap],[t.q975,t.q975],'-', ...
            'Color',[0.35,0.62,0.84],'LineWidth',1.2);
    else
        hBand = fill([x;flipud(x)],[t.q025;flipud(t.q975)], ...
            [0.75,0.86,0.96],'EdgeColor','none');
        hold on;
    end
    hMean = plot(x,t.posterior_mean,'b-o','LineWidth',1.2,'MarkerSize',4);
    hDet = plot(x,t.deterministic_estimate,'--ks','MarkerSize',3);
    if truthAvailable
        hTruth = plot(x,t.truth_value,'r-p','LineWidth',1.1,'MarkerSize',5);
    else
        hTruth = plot(nan,nan,'r-p','LineWidth',1.1,'MarkerSize',5);
    end
    if g==1
        legend([hBand,hMean,hDet,hTruth],{'95%后验可信区间', ...
            '后验均值','2.4确定性辨识结果','隔离真值'}, ...
            'Location','best','FontSize',7);
    end
    title(strrep(char(tbl.base_name(rows(1))),'_','\_'));
    xlabel(strrep(char(tbl.axis_name(rows(1))),'_','\_'));
    ylabel(char(tbl.unit(rows(1)))); grid on;
end
sgtitle('2.4调度节点正式后验与隔离真值事后对比');
saveas(f,sht_steady_model_uq_io('reportfile',manifest, ...
    'UQ10_schedule_node_truth_comparison.png'));
close(f);
end

function local_plot_predictive(tableValue,manifest,tag)
names = unique(tableValue.output,'stable');
f = figure('Visible','off','Position',[60,40,1400,850]);
for j = 1:numel(names)
    subplot(2,3,j); use = tableValue.output==names(j);
    t = tableValue(use,:); x = 1:height(t);
    hObservable = fill([x,fliplr(x)], ...
        [t.observable_q025.',fliplr(t.observable_q975.')], ...
        [0.88,0.92,0.96],'EdgeColor','none'); hold on;
    hModel = fill([x,fliplr(x)],[t.model_q025.',fliplr(t.model_q975.')], ...
        [0.62,0.78,0.92],'EdgeColor','none');
    hMedian = plot(x,t.model_median,'b-o','LineWidth',1.2,'MarkerSize',4);
    hMeasured = plot(x,t.measured_value,'ks','MarkerFaceColor','w');
    if all(isfinite(t.truth_value))
        hTruth = plot(x,t.truth_value,'rp','MarkerFaceColor','r','MarkerSize',6);
    else
        hTruth = plot(nan,nan,'rp','MarkerFaceColor','r','MarkerSize',6);
    end
    if j==1
        legend([hObservable,hModel,hMedian,hMeasured,hTruth], ...
            {'可观测预测95%区间','参数模型95%区间','模型后验中位数', ...
            '测量值','隔离真值'},'Location','best','FontSize',7);
    end
    title(strrep(char(names(j)),'_','\_'));
    set(gca,'XTick',x,'XTickLabel',cellstr(t.point_id), ...
        'XTickLabelRotation',30); ylabel(char(t.unit(1))); grid on;
end
sgtitle(sprintf('2.4UQ %s：模型可信区间与重复观测预测区间',tag));
saveas(f,sht_steady_model_uq_io('reportfile',manifest, ...
    sprintf('UQ10_%s_predictive_intervals.png',tag)));
close(f);
end

function local_plot_predictive_deviation(tableValue,manifest,tag)
% 绝对量跨工况变化远大于可信区间时，阴影在原图中会被视觉压缩。
% 本图统一减去各工况测量值，只改变显示基准，不改变任何后验数值。
names = unique(tableValue.output,'stable');
f = figure('Visible','off','Position',[60,40,1400,850]);
for j = 1:numel(names)
    subplot(2,3,j); use = tableValue.output==names(j);
    t = tableValue(use,:); x = 1:height(t);
    reference = t.measured_value;
    observableLower = t.observable_q025-reference;
    observableUpper = t.observable_q975-reference;
    modelLower = t.model_q025-reference;
    modelUpper = t.model_q975-reference;
    modelMedian = t.model_median-reference;
    hObservable = fill([x,fliplr(x)], ...
        [observableLower.',fliplr(observableUpper.')], ...
        [0.88,0.92,0.96],'EdgeColor','none'); hold on;
    hModel = fill([x,fliplr(x)],[modelLower.',fliplr(modelUpper.')], ...
        [0.62,0.78,0.92],'EdgeColor','none');
    hMedian = plot(x,modelMedian,'b-o','LineWidth',1.2,'MarkerSize',4);
    hMeasured = plot(x,zeros(size(x)),'ks','MarkerFaceColor','w');
    if all(isfinite(t.truth_value))
        hTruth = plot(x,t.truth_value-reference,'rp', ...
            'MarkerFaceColor','r','MarkerSize',6);
    else
        hTruth = plot(nan,nan,'rp','MarkerFaceColor','r','MarkerSize',6);
    end
    plot([x(1),x(end)],[0,0],'k:','LineWidth',0.7);
    if j==1
        legend([hObservable,hModel,hMedian,hMeasured,hTruth], ...
            {'可观测预测95%区间','参数模型95%区间','模型后验中位数', ...
            '测量值（零基准）','隔离真值'},'Location','best','FontSize',7);
    end
    title(strrep(char(names(j)),'_','\_'));
    set(gca,'XTick',x,'XTickLabel',cellstr(t.point_id), ...
        'XTickLabelRotation',30);
    ylabel(sprintf('相对测量值偏差 / %s',char(t.unit(1)))); grid on;
end
sgtitle(sprintf('2.4UQ %s：以测量值为零基准的预测区间',tag));
saveas(f,sht_steady_model_uq_io('reportfile',manifest, ...
    sprintf('UQ10_%s_predictive_deviation_intervals.png',tag)));
close(f);
end

function local_write_summary(result,step8,step9,manifest,runtime)
% 文件和命令行使用同一组文本，避免两套结果口径随维护发生漂移。
formalDiagnostic = step8.formal.diagnostic;
trainingPointCount = numel(unique(result.trainingTable.point_id));
testPointCount = numel(unique(result.testTable.point_id));
line = {};
line{end+1} = '# 2.4稳态修正参数贝叶斯UQ评估结果';
line{end+1} = '';
line{end+1} = '## 总体验收';
line{end+1} = '';
line{end+1} = sprintf('- 运行编号：`%s`',manifest.runId);
line{end+1} = sprintf('- 路线：`%s`；训练工况：%d；独立测试工况：%d', ...
    manifest.route,trainingPointCount,testPointCount);
line{end+1} = sprintf('- 正式后验验收：%s；后验预测验收：%s', ...
    local_pass_text(step8.passed),local_pass_text(result.passed));
line{end+1} = sprintf('- 3.4阶段程序指纹保持不变：%s', ...
    local_pass_text(result.flightUqUnchanged));
line{end+1} = sprintf('- 步骤10运行时间：%.2f s',runtime);

line{end+1} = '';
line{end+1} = '## 精确后验采样质量';
line{end+1} = '';
line{end+1} = sprintf(['- 正式SMC粒子：%d；升温阶段：%d；ESS：%.1f（%.2f%%）；' ...
    '最大归一化权重：%.4f'],formalDiagnostic.sampleCount, ...
    step8.formal.stageCount,formalDiagnostic.effectiveSampleSize, ...
    100*formalDiagnostic.effectiveSampleFraction, ...
    formalDiagnostic.maximumNormalizedWeight);
line{end+1} = sprintf(['- 末级pCN接受率：%.2f%%；不同粒子比例：%.2f%%；' ...
    '候选模态数：%d'],100*step8.formal.finalPcnAcceptance, ...
    100*step8.formal.distinctParticleFraction,formalDiagnostic.modeCount);
line{end+1} = sprintf('- 工程量级补偿：%d/%d个弱奇异方向通过精确路径检验', ...
    step9.engineeringCompensation.supportedDirectionCount, ...
    height(step9.engineeringCompensationTable));
line{end+1} = sprintf(['- 似然尺度校准：%s；有效参数自由度=%.3f；' ...
    '有效残差自由度=%.3f；后验Mahalanobis^2中位数=%.3f'], ...
    local_pass_text(step9.likelihoodCalibration.passed), ...
    step9.likelihoodCalibration.effectiveParameterCount, ...
    step9.likelihoodCalibration.effectiveResidualDegreesOfFreedom, ...
    step9.likelihoodCalibration.posteriorMedianMahalanobisSquared);

line{end+1} = '';
line{end+1} = '## 61个调度节点随机变量的后验评估';
line{end+1} = '';
if result.truthAvailable
    line{end+1} = '| 参数 | 单位 | 后验均值 | 95%可信区间 | 隔离真值 | 覆盖 |';
    line{end+1} = '|---|---:|---:|---:|---:|:---:|';
else
    line{end+1} = '| 参数 | 单位 | 后验均值 | 95%可信区间 |';
    line{end+1} = '|---|---:|---:|---:|';
end
for i = 1:height(result.parameterTable)
    row = result.parameterTable(i,:);
    name = char(string(row.name));
    unit = char(string(row.unit));
    if result.truthAvailable
        line{end+1} = sprintf('| `%s` | `%s` | %.8g | [%.8g, %.8g] | %.8g | %s |', ...
            name,unit,row.posterior_mean,row.q025,row.q975,row.truth_value, ...
            local_yes_no(row.truth_inside_95));
    else
        line{end+1} = sprintf('| `%s` | `%s` | %.8g | [%.8g, %.8g] |', ...
            name,unit,row.posterior_mean,row.q025,row.q975);
    end
end
if result.truthAvailable
    line{end+1} = '';
    line{end+1} = sprintf('- 全部节点真值的边际95%%覆盖：%d/%d', ...
        result.parameterDiagnostic.coveredCount, ...
        result.parameterDiagnostic.parameterCount);
    line{end+1} = sprintf('- 整条曲线全部节点均覆盖：%d/%d组', ...
        result.parameterDiagnostic.fullyCoveredGroupCount, ...
        result.parameterDiagnostic.groupCount);
    line{end+1} = sprintf('- %d个无量纲节点后验均值RMSE：%.6g', ...
        result.parameterDiagnostic.dimensionlessParameterCount, ...
        result.parameterDiagnostic.dimensionlessRmse);
    line{end+1} = sprintf(['- %d个`Wf_bias`节点均值RMSE：%.6g kg/s' ...
        '（设计燃油流量的%.4f%%）；最大绝对误差：%.6g kg/s'], ...
        result.parameterDiagnostic.wfBiasParameterCount, ...
        result.parameterDiagnostic.wfBiasRmse_kgps, ...
        result.parameterDiagnostic.wfBiasRmsePctDesign, ...
        result.parameterDiagnostic.wfBiasMaximumAbsoluteError_kgps);
end
line{end+1} = sprintf(['- 2.4确定性辨识值落入后验95%%可信区间：' ...
    '%d/%d；该结果仅作同批数据下的求解口径对照，不作为先验'], ...
    result.parameterDiagnostic.deterministicInside95Count, ...
    result.parameterDiagnostic.deterministicParameterCount);

line{end+1} = '';
line{end+1} = '## 后验预测评估';
line{end+1} = '';
line{end+1} = sprintf(['- 后验预测代表样本：%d；测试集唯一后验点：%d；' ...
    '本次DLL新算：%d；缓存命中：%d'],result.sampleCount, ...
    result.testExactDiagnostic.uniquePosteriorPointCount, ...
    result.testExactDiagnostic.dllEvaluationCount, ...
    result.testExactDiagnostic.cacheHitCount);
line{end+1} = sprintf(['- 独立测试域有效后验质量：%.2f%%（门限%.2f%%）；' ...
    '无效正式粒子：%d/%d；预测区间在有效支持集上重新归一化'], ...
    100*result.testExactDiagnostic.validPosteriorMass, ...
    100*result.testExactDiagnostic.minimumValidPosteriorMass, ...
    result.testExactDiagnostic.invalidFormalParticleCount, ...
    result.testExactDiagnostic.formalParticleCount);
if result.truthAvailable
    line{end+1} = sprintf('- 测试集模型95%%区间覆盖：%d/%d', ...
        nnz(result.testTable.truth_inside_model_95),height(result.testTable));
    line{end+1} = sprintf('- 测试集重复观测95%%区间覆盖：%d/%d', ...
        nnz(result.testTable.truth_inside_observable_95),height(result.testTable));
end
line{end+1} = '';
line{end+1} = '| 输出 | 单位 | 模型95%平均宽度 | 重复观测95%平均宽度 |';
line{end+1} = '|---|---:|---:|---:|';
for i = 1:height(result.testSummary)
    row = result.testSummary(i,:);
    line{end+1} = sprintf('| `%s` | `%s` | %.8g | %.8g |', ...
        char(string(row.output)),char(string(row.unit)), ...
        row.mean_model_width_95,row.mean_observable_width_95);
end

line{end+1} = '';
line{end+1} = '## 独立进气道压损评估';
line{end+1} = '';
if result.truthAvailable
    line{end+1} = sprintf('- `Inlet_K_dP`调度节点真值的95%%覆盖：%d/%d', ...
        nnz(result.inletPressureLossTable.truth_inside_95), ...
        height(result.inletPressureLossTable));
else
    line{end+1} = '- `Inlet_K_dP`已独立完成测量误差传播，不并入61维联合后验。';
end

line{end+1} = '';
line{end+1} = '## 结果文件';
line{end+1} = '';
line{end+1} = sprintf('- 评估摘要：`%s`',result.assessmentReportFile);
line{end+1} = sprintf('- 图表与CSV明细目录：`%s`',manifest.reportDir);
if result.truthAvailable
    line{end+1} = sprintf('- 隔离真值文件：`%s`',result.truthFile);
end
line{end+1} = '';
line{end+1} = ['说明：真值覆盖仅用于合成数据的事后方法诊断，未参与采样、' ...
    '协方差调整或正式后验验收。'];

summaryText = strjoin(line,newline);
sht_steady_model_uq_io('writetext',result.assessmentReportFile,summaryText);
fprintf('\n%s\n',repmat('=',1,78));
fprintf('%s\n',summaryText);
fprintf('%s\n',repmat('=',1,78));
end

function text = local_pass_text(flag)
if flag
    text = '通过';
else
    text = '未通过';
end
end

function text = local_yes_no(flag)
if flag
    text = '是';
else
    text = '否';
end
end

function value = local_option(options,name,defaultValue)
if isstruct(options) && isfield(options,name) && ~isempty(options.(name))
    value = options.(name);
else
    value = defaultValue;
end
end
