function diagnostics = sht_load_engine_library(libraryName, headerName, varargin)
%SHT_LOAD_ENGINE_LIBRARY 无解析噪声地加载GTESS公共接口。
%
% MATLAB R2020a的loadlibrary解析器会递归展开新版Windows SDK的stdio.h，
% 并把两个仅供UCRT内部使用的指针类型误报为未知类型。此外，当前MATLAB
% 自带Perl不支持C.UTF-8区域设置。本函数通过专用不透明FILE声明和临时C
% locale消除两个根因，同时保留notfound和解析文本的严格检查。

if nargin < 2 || isempty(libraryName) || isempty(headerName)
    error('SHT:LoadLibrary:BadInput', '必须给出DLL名称和公共头文件。');
end

thisDir = fileparts(mfilename('fullpath'));
parserIncludeDir = fullfile(thisDir, 'matlab_loadlibrary_include');
assert(isfolder(parserIncludeDir) && ...
    isfile(fullfile(parserIncludeDir, 'stdio.h')), ...
    'loadlibrary专用stdio.h不存在：%s', parserIncludeDir);

localeNames = {'LC_ALL', 'LC_CTYPE', 'LANG'};
oldLocale = cellfun(@getenv, localeNames, 'UniformOutput', false);
restoreLocale = onCleanup(@() local_restore_locale(localeNames, oldLocale));
for i = 1:numel(localeNames)
    setenv(localeNames{i}, 'C');
end

[notFound, parserOutput] = loadlibrary(libraryName, headerName, varargin{:}, ...
    'includepath', parserIncludeDir);

if ~isempty(notFound)
    error('SHT:LoadLibrary:MissingDeclarations', ...
        'GTESS公共接口存在无法加载的声明：%s', strjoin(notFound, ', '));
end

problemPattern = ['(?im)(perl:\s*warning|type\s+''[^'']+''\s+was\s+' ...
    'not\s+found|\berror\s*:|fatal\s+error)'];
problem = regexp(parserOutput, problemPattern, 'match');
if ~isempty(problem)
    error('SHT:LoadLibrary:ParserFailure', ...
        'GTESS公共接口解析仍存在问题：\n%s', strtrim(parserOutput));
end

diagnostics = struct('notFound', {notFound}, ...
    'parserOutput', parserOutput, ...
    'parserIncludeDir', parserIncludeDir, ...
    'localeDuringParse', 'C');
clear restoreLocale;
end

function local_restore_locale(names, values)
for i = 1:numel(names)
    setenv(names{i}, values{i});
end
end
