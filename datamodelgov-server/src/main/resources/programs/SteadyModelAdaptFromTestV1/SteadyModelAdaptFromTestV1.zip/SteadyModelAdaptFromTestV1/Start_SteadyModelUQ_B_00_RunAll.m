function result = Start_SteadyModelUQ_B_00_RunAll(userCfg)
%START_STEADYMODELUQ_B_00_RUNALL 执行2.4稳态UQ方法B正式流程。
%
% 默认使用瞬态时刻模型，93维参数包括方法A的61维参数、12个局部
% 六部件常值和20个物理引气常值。方法B不读取方法A后验，只有B10在
% 本方法后验冻结后读取方法A结果进行并列对比。
% 默认在十个贝叶斯步骤之后执行B12分支约束稳态后验预测。
% B10保留为直接测试回放诊断；总验收以正式后验通过且B12工程稳态
% 预测通过为准。可用runAdditionalSteadyPrediction=false关闭B12。

if nargin < 1, userCfg = struct(); end
timer = tic;
fprintf('\n=== 2.4稳态修正参数贝叶斯UQ方法B：完整执行 ===\n');
step = cell(10,1);
step{1} = Start_SteadyModelUQ_B_01_ProblemContract(userCfg);
runCfg = userCfg;
runCfg.runId = step{1}.manifest.runId;
step{2} = Start_SteadyModelUQ_B_02_ExactStaticReplayAndCache(runCfg);
step{3} = Start_SteadyModelUQ_B_03_ObservationVector(runCfg);
step{4} = Start_SteadyModelUQ_B_04_AnalyticMeasurementUncertainty(runCfg);
step{5} = Start_SteadyModelUQ_B_05_ExactLikelihoodVerification(runCfg);
step{6} = Start_SteadyModelUQ_B_06_GlobalExactPilot(runCfg);
step{7} = Start_SteadyModelUQ_B_07_DefensiveProposalAdaptation(runCfg);
step{8} = Start_SteadyModelUQ_B_08_BlockExactPosteriorSampling(runCfg);
step{9} = Start_SteadyModelUQ_B_09_PosteriorDiagnostics(runCfg);
step{10} = Start_SteadyModelUQ_B_10_PosteriorPredictiveAndMethodComparison(runCfg);
manifest = step{10}.manifest;
runAdditionalSteadyPrediction = local_option( ...
    userCfg,'runAdditionalSteadyPrediction',true);
additionalSteadyPrediction = [];
if runAdditionalSteadyPrediction
    additionalSteadyPrediction = ...
        Start_SteadyModelUQ_B_12_AdditionalSteadyPrediction(runCfg);
    formalPosteriorPassed = ...
        step{10}.acceptance.formalPosteriorPassed;
    overallPassed = formalPosteriorPassed && ...
        additionalSteadyPrediction.passed;
else
    formalPosteriorPassed = ...
        step{10}.acceptance.formalPosteriorPassed;
    overallPassed = step{10}.passed;
end
result = struct('runId',manifest.runId,'manifest',manifest, ...
    'steps',{step},'posterior',step{8}.formal, ...
    'posteriorDiagnostic',step{9},'validation',step{10}, ...
    'additionalSteadyPrediction',additionalSteadyPrediction, ...
    'formalPosteriorPassed',formalPosteriorPassed, ...
    'directTestReplayPassed',step{10}.passed, ...
    'assessmentReportFile',step{10}.assessmentReportFile, ...
    'runtime_s',toc(timer),'passed',overallPassed);
fprintf('=== 方法B执行结束：run=%s，总耗时%.2f s，pass=%d ===\n', ...
    result.runId,result.runtime_s,result.passed);
fprintf('正式后验=%d，B10直接测试回放=%d，B12工程稳态验收=%d。\n', ...
    result.formalPosteriorPassed,result.directTestReplayPassed, ...
    ~isempty(additionalSteadyPrediction) && ...
    additionalSteadyPrediction.passed);
fprintf('最终评估报告：%s\n',result.assessmentReportFile);
fprintf('图表和CSV目录：%s\n\n',manifest.reportDir);
end

function value = local_option(options,name,defaultValue)
value = defaultValue;
if isstruct(options) && isfield(options,name) && ...
        ~isempty(options.(name))
    value = options.(name);
end
if strcmp(name,'runAdditionalSteadyPrediction') && ...
        (~isscalar(value) || (~islogical(value) && ...
        ~(isnumeric(value) && ismember(value,[0,1]))))
    error('SHT:SteadyUQB:BadRunAdditionalSteadyPrediction', ...
        'runAdditionalSteadyPrediction必须为逻辑标量。');
end
value = logical(value);
end
