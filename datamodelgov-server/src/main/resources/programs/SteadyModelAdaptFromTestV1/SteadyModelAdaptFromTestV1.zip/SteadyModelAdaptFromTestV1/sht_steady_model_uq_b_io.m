function varargout = sht_steady_model_uq_b_io(action, varargin)
%SHT_STEADY_MODEL_UQ_B_IO 方法B的独立运行清单和结果目录管理。
%
% 方法B所有中间量写入MiddleData/steady_model_uq_method_b，图表和文本
% 写入外层report_outputs/steady_model_uq_method_b。该命名空间与方法A
% 完全隔离，防止缓存、步骤文件和latest清单相互覆盖。

switch lower(char(action))
    case 'paths'
        varargout{1} = local_paths();
    case 'createrun'
        varargout{1} = local_create_run(varargin{:});
    case 'resolve'
        varargout{1} = local_resolve(varargin{:});
    case 'savestep'
        [varargout{1:nargout}] = local_save_step(varargin{:});
    case 'loadstep'
        varargout{1} = local_load_step(varargin{:});
    case 'savemanifest'
        local_save_manifest(varargin{:});
    case 'reportfile'
        varargout{1} = local_report_file(varargin{:});
    case 'writetext'
        local_write_text(varargin{:});
    otherwise
        error('SHT:SteadyUQB:UnknownIoAction', ...
            '未知方法B UQ IO动作：%s。', action);
end
end

function paths = local_paths()
programRoot = fileparts(mfilename('fullpath'));
projectRoot = fileparts(programRoot);
paths = struct();
paths.programRoot = programRoot;
paths.projectRoot = projectRoot;
paths.middleRoot = fullfile(programRoot, 'MiddleData', ...
    'steady_model_uq_method_b');
paths.reportRoot = fullfile(projectRoot, 'report_outputs', ...
    'steady_model_uq_method_b');
paths.latestFile = fullfile(paths.middleRoot, 'latest_manifest.mat');
local_mkdir(paths.middleRoot);
local_mkdir(paths.reportRoot);
end

function manifest = local_create_run(userCfg)
if nargin < 1 || isempty(userCfg), userCfg = struct(); end
paths = local_paths();
if isfield(userCfg, 'runId') && ~isempty(userCfg.runId)
    runId = char(userCfg.runId);
else
    runId = ['steady_uq_b_' datestr(now, 'yyyymmdd_HHMMSS')];
end
runDir = fullfile(paths.middleRoot, runId);
reportDir = fullfile(paths.reportRoot, runId);
if exist(runDir, 'dir') == 7
    error('SHT:SteadyUQB:RunExists', '方法B运行目录已存在：%s。', runDir);
end
local_mkdir(runDir);
local_mkdir(reportDir);

manifest = struct();
manifest.schemaVersion = 'steady_model_uq_method_b_v1';
manifest.runId = runId;
manifest.createdAt = datestr(now, 30);
manifest.updatedAt = manifest.createdAt;
manifest.programRoot = paths.programRoot;
manifest.runDir = runDir;
manifest.reportDir = reportDir;
manifest.status = 'created';
manifest.completedStep = 0;
manifest.stepFiles = cell(10, 1);
manifest.stepNames = cell(10, 1);
manifest.stepRuntime_s = nan(10, 1);
manifest.randomSeed = local_option(userCfg, 'randomSeed', 20260822);
manifest.route = char(local_option(userCfg, 'route', 'transient_instant'));
local_save_manifest(manifest);
end

function manifest = local_resolve(userCfg)
if nargin < 1 || isempty(userCfg), userCfg = struct(); end
paths = local_paths();
if isfield(userCfg, 'runId') && ~isempty(userCfg.runId)
    file = fullfile(paths.middleRoot, char(userCfg.runId), 'manifest.mat');
else
    file = paths.latestFile;
end
if exist(file, 'file') ~= 2
    error('SHT:SteadyUQB:ManifestMissing', ...
        '未找到方法B运行清单：%s。请先运行B01或总入口。', file);
end
s = load(file, 'manifest');
manifest = s.manifest;
end

function [manifest, file] = local_save_step( ...
        manifest, step, name, payload, runtime_s)
if step < 1 || step > 10 || step ~= floor(step)
    error('SHT:SteadyUQB:BadStep', '步骤号必须为1至10的整数。');
end
if nargin < 5 || isempty(runtime_s), runtime_s = NaN; end
safeName = regexprep(char(name), '[^A-Za-z0-9_]', '_');
file = fullfile(manifest.runDir, ...
    sprintf('step%02d_%s.mat', step, safeName));
save(file, 'payload', '-v7.3');
manifest.stepFiles{step} = file;
manifest.stepNames{step} = char(name);
manifest.stepRuntime_s(step) = runtime_s;
manifest.completedStep = max(manifest.completedStep, step);
manifest.updatedAt = datestr(now, 30);
manifest.status = sprintf('step_%02d_complete', step);
if step == 10, manifest.status = 'complete'; end
local_save_manifest(manifest);
end

function payload = local_load_step(manifest, step)
if step < 1 || step > numel(manifest.stepFiles) || ...
        isempty(manifest.stepFiles{step})
    error('SHT:SteadyUQB:StepMissing', ...
        '方法B运行%s尚无步骤%d产物。', manifest.runId, step);
end
file = manifest.stepFiles{step};
if exist(file, 'file') ~= 2
    error('SHT:SteadyUQB:StepFileMissing', '步骤文件不存在：%s。', file);
end
s = load(file, 'payload');
payload = s.payload;
end

function local_save_manifest(manifest)
local_mkdir(manifest.runDir);
save(fullfile(manifest.runDir, 'manifest.mat'), 'manifest');
paths = local_paths();
save(paths.latestFile, 'manifest');
end

function file = local_report_file(manifest, name)
local_mkdir(manifest.reportDir);
file = fullfile(manifest.reportDir, char(name));
end

function local_write_text(file, content)
[folder, ~, ~] = fileparts(file);
local_mkdir(folder);
fid = fopen(file, 'w', 'n', 'UTF-8');
if fid < 0
    error('SHT:SteadyUQB:TextOpenFailed', '无法写入文本文件：%s。', file);
end
cleanupObject = onCleanup(@() fclose(fid));
fprintf(fid, '%s', char(content));
clear cleanupObject;
end

function local_mkdir(folder)
if exist(folder, 'dir') ~= 7
    [ok, message] = mkdir(folder);
    if ~ok
        error('SHT:SteadyUQB:MkdirFailed', ...
            '无法创建目录%s：%s。', folder, message);
    end
end
end

function value = local_option(options, name, defaultValue)
if isstruct(options) && isfield(options, name) && ~isempty(options.(name))
    value = options.(name);
else
    value = defaultValue;
end
end
