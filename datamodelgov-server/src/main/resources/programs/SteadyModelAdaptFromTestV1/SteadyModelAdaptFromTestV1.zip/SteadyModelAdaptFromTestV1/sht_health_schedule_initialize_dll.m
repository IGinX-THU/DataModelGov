function info = sht_health_schedule_initialize_dll(engine, profile, designVector)
%SHT_HEALTH_SCHEDULE_INITIALIZE_DLL 将一维健康调度表一次性写入DLL。
%
% stepIn中的h0:h158仍是设计点值k_design。本函数初始化31项Delta(x)
% 的横坐标和增量节点；DLL在每次局部部件求值时计算
% K_eff=k_design+Delta(x)。调度开关由每次模型调用的stepIn(18)给出，
% 本函数不保留跨调用的运行开关状态。初始化失败会立即复位DLL调度
% 系统，避免留下部分表已配置、部分表未配置的不完整状态。
%
% 可选designVector只用于设定初始化时压损表的
% Delta_0=-k_design。参数辨识回放时不需要重新写入整张表：DLL在
% 每次读取stepIn设计点值后，都会再次令四项压损表满足
% Delta_0=-k_design，因而K_eff(0)=0始终成立。其余Delta节点由
% profile显式给出。
assert(isstruct(engine) && isfield(engine, 'libraryName') && ...
    libisloaded(engine.libraryName), '发动机DLL尚未打开。');
assert(isfield(engine, 'modelMode') && engine.modelMode == 1, ...
    '健康调度表只允许初始化到六部件模式。');
assert(isstruct(profile) && isfield(profile, 'parameters') && ...
    isfield(profile, 'scheduledCIndex'), 'profile不是有效健康调度资产。');
if nargin < 3 || isempty(designVector)
    designVector = profile.truthVectorAtDesign;
end
designVector = double(designVector(:));
assert(numel(designVector) == numel(profile.truthVectorAtDesign) && ...
    all(isfinite(designVector)), ...
    'designVector必须是与健康参数字典等长的有限列向量。');

libraryName = engine.libraryName;
status = calllib(libraryName, 'DLL_SHT_HealthScheduleReset');
assert(status == 0, 'DLL健康调度复位失败，状态码=%d。', status);

scheduled = ~strcmp({profile.parameters.mode}, 'constant');
parameters = profile.parameters(scheduled);
try
    for i = 1:numel(parameters)
        parameter = parameters(i);
        axisType = local_axis_type(parameter.axisName);
        xNode = double(parameter.xNodes(:));
        deltaNode = double(parameter.deltaNodes(:));
        if parameter.zeroFlowAnchored
            deltaNode(1) = -designVector(parameter.matlabHealthIndex);
        end
        xPointer = libpointer('doublePtr', xNode);
        deltaPointer = libpointer('doublePtr', deltaNode);
        status = calllib(libraryName, ...
            'DLL_SHT_HealthScheduleConfigureTable', ...
            int32(parameter.cIndex), int32(axisType), ...
            int32(numel(xNode)), xPointer, deltaPointer);
        if status ~= 0
            error('SHT:HealthSchedule:DLLTableInitialization', ...
                'h%d %s调度表初始化失败，状态码=%d。', ...
                parameter.cIndex, parameter.name, status);
        end
    end

    configuredCount = calllib(libraryName, ...
        'DLL_SHT_HealthScheduleGetConfiguredCount');
    assert(configuredCount == numel(parameters) && configuredCount == 31, ...
        'DLL调度表数量为%d，预期为31。', configuredCount);
    % 初始化结束后保持常值语义。每次RunOnePoint/RunOneStep调用都会
    % 用stepIn(18)覆盖该内部状态，因此不会继承前一次模型调用的开关。
    status = calllib(libraryName, ...
        'DLL_SHT_HealthScheduleSetEnabled', int32(0));
    assert(status == 0, 'DLL健康调度初始化状态设置失败，状态码=%d。', status);
catch exception
    calllib(libraryName, 'DLL_SHT_HealthScheduleReset');
    rethrow(exception);
end

info = struct();
info.schemaVersion = 'SHT_HEALTH_SCHEDULE_DLL_INIT_V5_ADDITIVE_INCREMENT';
info.runtimeSwitchMatlabIndex = engine.healthScheduleEnableIndex;
info.runtimeSwitchCIndex = engine.healthScheduleEnableIndex - 1;
info.initialEnabledState = false;
info.configuredCount = configuredCount;
info.healthCIndex = [parameters.cIndex].';
info.axisType = arrayfun(@(p) local_axis_type(p.axisName), parameters).';
info.designVector = designVector;
end

function axisType = local_axis_type(axisName)
names = { ...
    'inlet_corrected_mass_flow', ...
    'burner_inlet_corrected_mass_flow', ...
    'gt_pt_duct_corrected_mass_flow', ...
    'pt_nozzle_duct_corrected_mass_flow', ...
    'ac_corrected_speed', ...
    'cc_corrected_speed', ...
    'gt_total_pressure_ratio', ...
    'pt_total_pressure_ratio'};
axisType = find(strcmp(names, axisName), 1);
assert(~isempty(axisType), '未知DLL健康调度坐标：%s。', axisName);
end
